username: yashkarthik
fid: 1600
display name: Yash Karthik
PFP: [https://lh3.googleusercontent.com/W_MM3NN-i9OYxM3XPJjwpb5mkMLjJFZJjnEXsvrhiTwirSFhRjyAa3qTzV63ago6NkX9qeesi20hoK9fHdhiE-SqICH0vPcTm3Dl](https://lh3.googleusercontent.com/W_MM3NN-i9OYxM3XPJjwpb5mkMLjJFZJjnEXsvrhiTwirSFhRjyAa3qTzV63ago6NkX9qeesi20hoK9fHdhiE-SqICH0vPcTm3Dl)
bio: I like building cool stuff on top of Ethereum, Farcaster and GPT (dm for collab)

Currently learning C and exploring low level stuff

nf.td/yashkarthik

<img src="https://lh3.googleusercontent.com/W_MM3NN-i9OYxM3XPJjwpb5mkMLjJFZJjnEXsvrhiTwirSFhRjyAa3qTzV63ago6NkX9qeesi20hoK9fHdhiE-SqICH0vPcTm3Dl" height="100" width="100" alt="Yash Karthik" />
---
0x33cc45d8b0336bfa830fb512b54b02a049277403
