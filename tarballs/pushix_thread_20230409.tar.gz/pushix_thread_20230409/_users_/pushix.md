username: pushix
fid: 359
display name: Nicholas Charriere
PFP: [https://lh3.googleusercontent.com/v58dn3Qon30ikaovcRc_91qg8UdIAuDEcbBPkMxP6DP2eOvdGs96azCsUomVJIbeElIMx9hQdlNFrZf7ujWVE6fZkM8QaEPG8Km6sQ=s120](https://lh3.googleusercontent.com/v58dn3Qon30ikaovcRc_91qg8UdIAuDEcbBPkMxP6DP2eOvdGs96azCsUomVJIbeElIMx9hQdlNFrZf7ujWVE6fZkM8QaEPG8Km6sQ=s120)
bio: Founder https://axflow.dev // creator of the https://blockchainsmokers.xyz // nf.td/nicho

<img src="https://lh3.googleusercontent.com/v58dn3Qon30ikaovcRc_91qg8UdIAuDEcbBPkMxP6DP2eOvdGs96azCsUomVJIbeElIMx9hQdlNFrZf7ujWVE6fZkM8QaEPG8Km6sQ=s120" height="100" width="100" alt="Nicholas Charriere" />
---
0xda46696c9de358a9f17f5d8ad5bea9ac12eef348
0x885f8588bb15a046f71bd5119f5bc3b67ee883d3