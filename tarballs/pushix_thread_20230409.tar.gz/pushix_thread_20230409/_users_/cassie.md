username: cassie
fid: 1325
display name: Cassie Heart
PFP: [https://openseauserdata.com/files/494817402e92be3ce3f419788c8dc737.svg](https://openseauserdata.com/files/494817402e92be3ce3f419788c8dc737.svg)
bio: BDFL of Quilibrium, Eng @ Farcaster, ex-Coinbase, always opinionated, never hydrated

<img src="https://openseauserdata.com/files/494817402e92be3ce3f419788c8dc737.svg" height="100" width="100" alt="Cassie Heart" />
---
0xce4eb76664210426e900c20d4a3741a6b0f64855