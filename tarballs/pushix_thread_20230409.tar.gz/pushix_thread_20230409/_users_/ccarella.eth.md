username: ccarella.eth
fid: 472
display name: ccarella
PFP: [https://i.imgur.com/RO9s06A.jpg](https://i.imgur.com/RO9s06A.jpg)
bio: Techno-Optimist. Hyperpunk. Artist. Purple. Energy. Nouns. Product @CharmVerse.

<img src="https://i.imgur.com/RO9s06A.jpg" height="100" width="100" alt="ccarella" />
---
0x3b60e31cfc48a9074cd5bebb26c9eaa77650a43f