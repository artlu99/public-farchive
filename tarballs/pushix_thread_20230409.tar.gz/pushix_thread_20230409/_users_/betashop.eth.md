username: betashop.eth
fid: 602
display name: Jason Goldberg 
PFP: [https://i.seadn.io/gae/L6orcQneNpLm3BYUN1cDsOAalQdWtWPPEUAMuQzpqNzH1hgQMDom79OBfDC8JI7oPlRoZX_ie_CkBxIqxNeTOo8IiGo0iSwkvUhgIFo?w=500&auto=format](https://i.seadn.io/gae/L6orcQneNpLm3BYUN1cDsOAalQdWtWPPEUAMuQzpqNzH1hgQMDom79OBfDC8JI7oPlRoZX_ie_CkBxIqxNeTOo8IiGo0iSwkvUhgIFo?w=500&auto=format)
bio: Maker of Airstack: the easiest way to build composable blockchain apps | connect with me onchain minglee.io/betashop


<img src="https://i.seadn.io/gae/L6orcQneNpLm3BYUN1cDsOAalQdWtWPPEUAMuQzpqNzH1hgQMDom79OBfDC8JI7oPlRoZX_ie_CkBxIqxNeTOo8IiGo0iSwkvUhgIFo?w=500&auto=format" height="100" width="100" alt="Jason Goldberg " />
---
0xeaf55242a90bb3289db8184772b0b98562053559