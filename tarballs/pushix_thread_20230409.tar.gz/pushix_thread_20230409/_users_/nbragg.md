username: nbragg
fid: 9166
display name: Noah Bragg 🤝
PFP: [https://i.seadn.io/gae/cmydRPJNH5KXm5Go5944N6s4ydkG89YoSYYVUwzWrZrCDXLcYCXHirbgeiXICJW6iJtnVbD2ssas6zvl7ZoE0NWlAc46iW7DUTOw?w=500&auto=format](https://i.seadn.io/gae/cmydRPJNH5KXm5Go5944N6s4ydkG89YoSYYVUwzWrZrCDXLcYCXHirbgeiXICJW6iJtnVbD2ssas6zvl7ZoE0NWlAc46iW7DUTOw?w=500&auto=format)
bio: Building poolfish.xyz. A calculator for LP providers. Built Potion solo to $6k+ MRR and sold for $300k.

<img src="https://i.seadn.io/gae/cmydRPJNH5KXm5Go5944N6s4ydkG89YoSYYVUwzWrZrCDXLcYCXHirbgeiXICJW6iJtnVbD2ssas6zvl7ZoE0NWlAc46iW7DUTOw?w=500&auto=format" height="100" width="100" alt="Noah Bragg 🤝" />
---
0x9fffd1ca952fad6be57b99b61a0e75c192f201c1