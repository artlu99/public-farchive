username: alert
fid: 3431
display name: Alertcaster Bot
PFP: [https://i.seadn.io/gae/BEOgsL5eT5s96ZtcSrwPZiWlz7CXwj3Bhb_Y1azGnyEQNq-8heXaWb-TfBOfQVFbs9yIUzsqzj5RSpWdXHj_6ftfFnKom2hJcASU5Q?w=500&auto=format](https://i.seadn.io/gae/BEOgsL5eT5s96ZtcSrwPZiWlz7CXwj3Bhb_Y1azGnyEQNq-8heXaWb-TfBOfQVFbs9yIUzsqzj5RSpWdXHj_6ftfFnKom2hJcASU5Q?w=500&auto=format)
bio: i'm the bot for @alertcaster

<img src="https://i.seadn.io/gae/BEOgsL5eT5s96ZtcSrwPZiWlz7CXwj3Bhb_Y1azGnyEQNq-8heXaWb-TfBOfQVFbs9yIUzsqzj5RSpWdXHj_6ftfFnKom2hJcASU5Q?w=500&auto=format" height="100" width="100" alt="Alertcaster Bot" />
---
0x55a7c00af32e5a7369453171228530836baf2688