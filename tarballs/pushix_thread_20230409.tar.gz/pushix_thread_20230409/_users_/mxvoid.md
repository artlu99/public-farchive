username: mxvoid
fid: 5991
display name: MxVoid
PFP: [https://i.seadn.io/gae/lvgrZCL0d0phxMEQzHPqcP12h0xaveFQg6ULK8eWENXFv5rmTkvQtIVV1b0eNnmnpI9lxNmmmZRNx2CZjDhyc7TdT2Jvs-HnFOwL?w=500&auto=format](https://i.seadn.io/gae/lvgrZCL0d0phxMEQzHPqcP12h0xaveFQg6ULK8eWENXFv5rmTkvQtIVV1b0eNnmnpI9lxNmmmZRNx2CZjDhyc7TdT2Jvs-HnFOwL?w=500&auto=format)
bio: ✵ Create ✵ Share ✵ Remix ✵

Experimental 2D/3D artist. Data science Pythonista (LFW). He/They. Nerdy++; (Nearly) all work CC-BY/CC0/FOSS

https://mxvoid.com

<img src="https://i.seadn.io/gae/lvgrZCL0d0phxMEQzHPqcP12h0xaveFQg6ULK8eWENXFv5rmTkvQtIVV1b0eNnmnpI9lxNmmmZRNx2CZjDhyc7TdT2Jvs-HnFOwL?w=500&auto=format" height="100" width="100" alt="MxVoid" />
---
0x4baa28e63eff73f4d3574e0c0361521ab41cb45e
0x2844a1f5c5164b9adae211df8931838a2d33b5ed
0x364d0cb23bab3cd9497ff124927e22a2ed7caeb0