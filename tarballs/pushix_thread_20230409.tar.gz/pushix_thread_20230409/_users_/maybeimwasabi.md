username: maybeimwasabi
fid: 3432
display name: Maybe Im Wasabi〽️
PFP: [https://i.seadn.io/gcs/files/56d7bd3c8c301223493e14492d44eb2b.png?w=500&auto=format](https://i.seadn.io/gcs/files/56d7bd3c8c301223493e14492d44eb2b.png?w=500&auto=format)
bio: Artist. Thinker 〽️ nf.td/imwasabi

<img src="https://i.seadn.io/gcs/files/56d7bd3c8c301223493e14492d44eb2b.png?w=500&auto=format" height="100" width="100" alt="Maybe Im Wasabi〽️" />
