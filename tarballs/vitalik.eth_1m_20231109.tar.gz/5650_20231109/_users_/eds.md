username: eds
fid: 188975
display name: Ed
PFP: [https://i.imgur.com/x7stWLe.jpg](https://i.imgur.com/x7stWLe.jpg)
bio: Software developer, PNW

<img src="https://i.imgur.com/x7stWLe.jpg" height="100" width="100" alt="Ed" />
