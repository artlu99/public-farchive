username: vrypan.eth
fid: 280
display name: vrypan.eth
PFP: [https://i.seadn.io/gcs/files/fe0d67c910a8b85e9e4ce4f2d5b1fbd5.png?w=500&auto=format](https://i.seadn.io/gcs/files/fe0d67c910a8b85e9e4ce4f2d5b1fbd5.png?w=500&auto=format)
bio: vrypan.net | niftywalls.xyz | foundation.app/@vrypan | paragraph.xyz/@purplesubmarine | working at @weatherxm

<img src="https://i.seadn.io/gcs/files/fe0d67c910a8b85e9e4ce4f2d5b1fbd5.png?w=500&auto=format" height="100" width="100" alt="vrypan.eth" />
---
0x8b0573d1c80362db589eda39c2e30f5190d7eb51
0x93c620d2af377c6c37e3e3c1d3e065eb04b08ae2