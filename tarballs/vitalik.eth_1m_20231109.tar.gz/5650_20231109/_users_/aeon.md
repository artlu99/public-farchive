username: aeon
fid: 10311
display name: Aeon Miguel
PFP: [https://i.imgur.com/yuTWDSE.jpg](https://i.imgur.com/yuTWDSE.jpg)
bio: Crypto enthusiast with special interest in technology.

<img src="https://i.imgur.com/yuTWDSE.jpg" height="100" width="100" alt="Aeon Miguel" />
---
0xce727050002f2a1398e819328fa501d952a05aac