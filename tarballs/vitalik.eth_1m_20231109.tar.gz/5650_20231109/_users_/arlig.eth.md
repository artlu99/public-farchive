username: arlig.eth
fid: 21850
display name: arlig
PFP: [https://i.imgur.com/cNSYBiC.jpg](https://i.imgur.com/cNSYBiC.jpg)
bio: Software developer, mainly games, but also apps and dabbling with (zk)EVM stuff. Check out avenlabs.com/conclave

Privacy is normal

<img src="https://i.imgur.com/cNSYBiC.jpg" height="100" width="100" alt="arlig" />
---
0xc777ea0bf0a148c5facc0800c4df8aa6539467aa