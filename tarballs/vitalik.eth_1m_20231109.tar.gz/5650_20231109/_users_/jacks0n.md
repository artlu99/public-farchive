username: jacks0n
fid: 1629
display name: Jackson
PFP: [https://i.imgur.com/x4kShBX.gif](https://i.imgur.com/x4kShBX.gif)
bio: Cope dealer 🙏 eng + product  @ axelar.network ⬜️

Building interchain 




<img src="https://i.imgur.com/x4kShBX.gif" height="100" width="100" alt="Jackson" />
