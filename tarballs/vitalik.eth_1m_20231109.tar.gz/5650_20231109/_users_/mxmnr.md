username: mxmnr
fid: 1580
display name: Max Miner
PFP: [https://i.seadn.io/gae/Rc8QayEJ4i-IZqb48gPYc77CiAjc9no4jbxF1YmRkPxJW_CzEoojdsn5279TpyXC1LC0MFFht97MSZ0VWNJCAmczn1zKWzdRiyTB?w=500&auto=format](https://i.seadn.io/gae/Rc8QayEJ4i-IZqb48gPYc77CiAjc9no4jbxF1YmRkPxJW_CzEoojdsn5279TpyXC1LC0MFFht97MSZ0VWNJCAmczn1zKWzdRiyTB?w=500&auto=format)
bio: Husband, Dad, Product & Design Leader @ SkillsEngine. 
Design, art, code, philosophy, econ, systems thinking. 
CO -> CA -> ATX. 

<img src="https://i.seadn.io/gae/Rc8QayEJ4i-IZqb48gPYc77CiAjc9no4jbxF1YmRkPxJW_CzEoojdsn5279TpyXC1LC0MFFht97MSZ0VWNJCAmczn1zKWzdRiyTB?w=500&auto=format" height="100" width="100" alt="Max Miner" />
---
0x15a62f8aa28d45f726453c5fdfdce242135efb76