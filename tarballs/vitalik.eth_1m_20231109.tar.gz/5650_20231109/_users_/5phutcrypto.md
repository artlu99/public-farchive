username: 5phutcrypto
fid: 24176
display name: 5phutcrypto
PFP: [https://i.imgur.com/o1aj5RO.jpg](https://i.imgur.com/o1aj5RO.jpg)
bio: I'm a little teapot who didn't fill out my bio

<img src="https://i.imgur.com/o1aj5RO.jpg" height="100" width="100" alt="5phutcrypto" />
---
0x3f9a5a0267ce4ff6d84c08fd5150acb593e4523c