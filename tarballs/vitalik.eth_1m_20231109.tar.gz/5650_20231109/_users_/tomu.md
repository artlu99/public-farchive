username: tomu
fid: 1668
display name: David Tomu
PFP: [https://openseauserdata.com/files/9643724455bc5c454c44cffe46e3efd2.svg](https://openseauserdata.com/files/9643724455bc5c454c44cffe46e3efd2.svg)
bio: building consumer crypto | founder frameit.io and mintgate.io prev: own.fund nf.td/tomu

<img src="https://openseauserdata.com/files/9643724455bc5c454c44cffe46e3efd2.svg" height="100" width="100" alt="David Tomu" />
---
0x98397a068d413d3c92a506f98c5f25d33a9dac14