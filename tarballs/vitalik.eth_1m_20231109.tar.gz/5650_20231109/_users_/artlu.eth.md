username: artlu.eth
fid: 6546
display name: artlu
PFP: [https://i.seadn.io/gcs/files/7ee04b071edc2c48517d205f63da0129.png?w=500&auto=format](https://i.seadn.io/gcs/files/7ee04b071edc2c48517d205f63da0129.png?w=500&auto=format)
bio: free.byokapp.xyz

first name Moto, last name Moto
here's how you spell it, M-O-T-O M-O-T-O

TG:artlu99 | artlu.xyz | Liquid Art PFP by @chriscocreated

<img src="https://i.seadn.io/gcs/files/7ee04b071edc2c48517d205f63da0129.png?w=500&auto=format" height="100" width="100" alt="artlu" />
---
0x511affbf7afdf2488fb1cba6e5d19508cff2e4a5
0x0b33c1a4ffff852bef231932c8559861ef625427