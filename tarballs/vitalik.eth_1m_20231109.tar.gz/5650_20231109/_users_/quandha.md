username: quandha
fid: 18154
display name: Kun
PFP: [https://i.imgur.com/bRyibIE.jpg](https://i.imgur.com/bRyibIE.jpg)
bio: DeFi Addict 🤑 | NFT Lover 🖼️

<img src="https://i.imgur.com/bRyibIE.jpg" height="100" width="100" alt="Kun" />
---
0x6e2a497a065674ab8b129fd7ddb301c6243c6362