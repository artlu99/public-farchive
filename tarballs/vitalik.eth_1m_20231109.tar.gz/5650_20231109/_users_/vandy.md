username: vandy
fid: 18193
display name: Vandy
PFP: [https://i.imgur.com/IIqUpOj.jpg](https://i.imgur.com/IIqUpOj.jpg)
bio: Web 3 OG |
I like to build cool shit and collect things | feistydoge.art

<img src="https://i.imgur.com/IIqUpOj.jpg" height="100" width="100" alt="Vandy" />
---
0xaaf773699e7e05ee899f2687674ae1b35b9ffc65