username: bull86
fid: 189083
display name: Lukas Nguyen
PFP: [https://i.imgur.com/kCq1Xlj.jpg](https://i.imgur.com/kCq1Xlj.jpg)
bio: Top 30 on DeBank: FantomKing; Co-Founder OnBlock Ventures; CryptoHolic; ALINIEX.com; Mad Lads NFT HODLER

<img src="https://i.imgur.com/kCq1Xlj.jpg" height="100" width="100" alt="Lukas Nguyen" />
---
0x25954b95ea02df586e07688de9543eea5bae31d7