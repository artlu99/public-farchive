username: grunt.eth
fid: 2441
display name: grant
PFP: [https://i.seadn.io/gae/2XpP9azWVsLwYLLQDJQfhOACwi_PLXoeyl60rDQvA0YdrTFqzTJXWZ3qMOgqJm0v0FNQ--TyGbx3jthbOXe_BHxqAzTFOyyPmGO2Yw?w=500&auto=format](https://i.seadn.io/gae/2XpP9azWVsLwYLLQDJQfhOACwi_PLXoeyl60rDQvA0YdrTFqzTJXWZ3qMOgqJm0v0FNQ--TyGbx3jthbOXe_BHxqAzTFOyyPmGO2Yw?w=500&auto=format)
bio: Aspiring mad scientist

<img src="https://i.seadn.io/gae/2XpP9azWVsLwYLLQDJQfhOACwi_PLXoeyl60rDQvA0YdrTFqzTJXWZ3qMOgqJm0v0FNQ--TyGbx3jthbOXe_BHxqAzTFOyyPmGO2Yw?w=500&auto=format" height="100" width="100" alt="grant" />
---
0xea310c966d3ff5e09c65487f1763b21361eb71ef