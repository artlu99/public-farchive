username: vgr
fid: 4606
display name: Venkatesh Rao ☀️
PFP: [https://i.seadn.io/gae/T-nT2JPzx2mx6bLRETolnn8Vc-D8vdUqDz5vrSPZPIcu5xjFMtIC3qmfU2Kqjfj9W0fNDxVSJQ-tggAWEsI38Gxw-Lxmw4H-osi6IA?w=500&auto=format](https://i.seadn.io/gae/T-nT2JPzx2mx6bLRETolnn8Vc-D8vdUqDz5vrSPZPIcu5xjFMtIC3qmfU2Kqjfj9W0fNDxVSJQ-tggAWEsI38Gxw-Lxmw4H-osi6IA?w=500&auto=format)
bio: Blogger at ribbonfarm.com, running summerofprotocols.com ☀️

<img src="https://i.seadn.io/gae/T-nT2JPzx2mx6bLRETolnn8Vc-D8vdUqDz5vrSPZPIcu5xjFMtIC3qmfU2Kqjfj9W0fNDxVSJQ-tggAWEsI38Gxw-Lxmw4H-osi6IA?w=500&auto=format" height="100" width="100" alt="Venkatesh Rao ☀️" />
---
0x2503b70933119084c26df4c8d3e96d282de10743