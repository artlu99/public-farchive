username: ikzo
fid: 18373
display name: ikzo
PFP: [https://i.imgur.com/tS9hKzO.jpg](https://i.imgur.com/tS9hKzO.jpg)
bio: a osawari TRADER

<img src="https://i.imgur.com/tS9hKzO.jpg" height="100" width="100" alt="ikzo" />
