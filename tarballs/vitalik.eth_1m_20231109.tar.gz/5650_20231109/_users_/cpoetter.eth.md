username: cpoetter.eth
fid: 3747
display name: Carsten
PFP: [https://i.seadn.io/gae/A2SJAVH_b3Z__3vq5aB62UCMlhtonSWazjDJDB_lyjAfitaJ-IKncv7ekwo4Hfk9sIzW5k43RFyErT_zoh_U-GV-wlWBye8RWcRGFg?w=500&auto=format](https://i.seadn.io/gae/A2SJAVH_b3Z__3vq5aB62UCMlhtonSWazjDJDB_lyjAfitaJ-IKncv7ekwo4Hfk9sIzW5k43RFyErT_zoh_U-GV-wlWBye8RWcRGFg?w=500&auto=format)
bio: vibing w/Rehash🎙| 
PoolTogether + Pooly fanboy 🌊🏆

nf.td/cpoetter + cpoetter.tumblr.com/

<img src="https://i.seadn.io/gae/A2SJAVH_b3Z__3vq5aB62UCMlhtonSWazjDJDB_lyjAfitaJ-IKncv7ekwo4Hfk9sIzW5k43RFyErT_zoh_U-GV-wlWBye8RWcRGFg?w=500&auto=format" height="100" width="100" alt="Carsten" />
---
0xd26b76e50f6510cdd4bf45d59279705f36946d23