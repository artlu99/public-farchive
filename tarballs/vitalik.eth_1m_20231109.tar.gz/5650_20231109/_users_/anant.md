username: anant
fid: 19329
display name: Anant K.
PFP: [https://i.imgur.com/oSWyKnr.jpg](https://i.imgur.com/oSWyKnr.jpg)
bio: ⭕Trader
⭕Investor
⭕Technical Analyst

<img src="https://i.imgur.com/oSWyKnr.jpg" height="100" width="100" alt="Anant K." />
---
0x63af807ae580bdd9c42dfd1a866286a1002de7df
0x26687bda20b17c402895c4c911e1cad3c83f5434