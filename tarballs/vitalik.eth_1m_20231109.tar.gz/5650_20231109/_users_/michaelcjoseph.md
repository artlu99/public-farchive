username: michaelcjoseph
fid: 4182
display name: michaelcjoseph
PFP: [https://lh3.googleusercontent.com/K3Bpl07pp03XcbkBiAGgpZbJpS1tsp6bd6OadaDJw_ZV2xM-H25W75B-N4LWv5bGsNCyjalLiPLqzjqnVefAiJI9D2zkeJf6wp7rDIA](https://lh3.googleusercontent.com/K3Bpl07pp03XcbkBiAGgpZbJpS1tsp6bd6OadaDJw_ZV2xM-H25W75B-N4LWv5bGsNCyjalLiPLqzjqnVefAiJI9D2zkeJf6wp7rDIA)
bio: Making crypto consumer friendly // product @party

<img src="https://lh3.googleusercontent.com/K3Bpl07pp03XcbkBiAGgpZbJpS1tsp6bd6OadaDJw_ZV2xM-H25W75B-N4LWv5bGsNCyjalLiPLqzjqnVefAiJI9D2zkeJf6wp7rDIA" height="100" width="100" alt="michaelcjoseph" />
---
0x66782e5a061b5a63536f912380a6dcf9481900c7