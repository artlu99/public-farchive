username: menno
fid: 188770
display name: Menno
PFP: [https://i.imgur.com/aOyhRM5.jpg](https://i.imgur.com/aOyhRM5.jpg)
bio: en route to the technocapital singularity (e/acc) 

<img src="https://i.imgur.com/aOyhRM5.jpg" height="100" width="100" alt="Menno" />
