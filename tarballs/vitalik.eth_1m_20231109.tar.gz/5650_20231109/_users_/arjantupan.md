username: arjantupan
fid: 13089
display name: Arjan Tupan  🟣
PFP: [https://i.imgur.com/pXcKZl6.jpg](https://i.imgur.com/pXcKZl6.jpg)
bio: A teller / of stories, that is me. / Curious to learn new ways to see. / Proud dad of two. Now, what / about you? | Builds https://paragraph.xyz/@onchainpoetry

<img src="https://i.imgur.com/pXcKZl6.jpg" height="100" width="100" alt="Arjan Tupan  🟣" />
---
0xb31faa5c1d581c70f4b6ed095c944936cbd2a357