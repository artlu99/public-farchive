username: ekinci.eth
fid: 6227
display name: Emre Ekinci
PFP: [https://i.imgur.com/smbrNPw.jpg](https://i.imgur.com/smbrNPw.jpg)
bio: building @mystate hosting @farconnect in istanbul ☻ ekinci.xyz

<img src="https://i.imgur.com/smbrNPw.jpg" height="100" width="100" alt="Emre Ekinci" />
---
0x5f57c686bdbc03242c8fa723b80f0a6cdea79546