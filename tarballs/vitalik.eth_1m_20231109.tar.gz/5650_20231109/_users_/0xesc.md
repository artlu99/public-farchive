username: 0xesc
fid: 20787
display name: 0xesc
PFP: [https://i.imgur.com/wy3lGuj.png](https://i.imgur.com/wy3lGuj.png)
bio: Pudgy Penguin

<img src="https://i.imgur.com/wy3lGuj.png" height="100" width="100" alt="0xesc" />
---
0x21d79c2be4ab3de2802a60da66f86d497d06102b