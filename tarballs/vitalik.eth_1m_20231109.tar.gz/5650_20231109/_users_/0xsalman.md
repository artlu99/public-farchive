username: 0xsalman
fid: 20099
display name: Salman | Engineer
PFP: [https://i.imgur.com/8fKo60z.png](https://i.imgur.com/8fKo60z.png)
bio: Considering New Roles | Prev 
SushiSwap | Prev Web2 Senior Engineer/Architect | All opinions are my own

<img src="https://i.imgur.com/8fKo60z.png" height="100" width="100" alt="Salman | Engineer" />
