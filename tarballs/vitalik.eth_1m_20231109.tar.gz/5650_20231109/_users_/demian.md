username: demian
fid: 189039
display name: kkdemian
PFP: [https://i.imgur.com/5vwWmKz.jpg](https://i.imgur.com/5vwWmKz.jpg)
bio: Crypto speculators, Web3 #BUIDL. 未来的店主：经营一家特色的加密货币📖和☕️店。

<img src="https://i.imgur.com/5vwWmKz.jpg" height="100" width="100" alt="kkdemian" />
