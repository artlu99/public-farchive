username: piterkrun
fid: 18158
display name: Piter
PFP: [https://i.imgur.com/DiHrfu5.jpg](https://i.imgur.com/DiHrfu5.jpg)
bio: CEO at Homie Capital

<img src="https://i.imgur.com/DiHrfu5.jpg" height="100" width="100" alt="Piter" />
---
0xb13b1333f63618450fd01495f0f80f301bce0124