username: melkovka
fid: 24220
display name: melkovka
PFP: [https://i.seadn.io/s/raw/files/0b5db20dd1c0505e0f9866679ea505f6.png?w=500&auto=format](https://i.seadn.io/s/raw/files/0b5db20dd1c0505e0f9866679ea505f6.png?w=500&auto=format)
bio: American currently living in Russia. Twitter works only via VPN here, my US cards dont work. Chinese electric cars capture market from BMWs. 100% follow-back.

<img src="https://i.seadn.io/s/raw/files/0b5db20dd1c0505e0f9866679ea505f6.png?w=500&auto=format" height="100" width="100" alt="melkovka" />
---
0xfb521552b65cc1caf748778fbcb7929c9a5f2c83