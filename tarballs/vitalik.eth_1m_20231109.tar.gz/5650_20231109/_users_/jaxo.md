username: jaxo
fid: 16821
display name: jaxo
PFP: [https://i.imgur.com/2ID317J.jpg](https://i.imgur.com/2ID317J.jpg)
bio: Digging in crypto

<img src="https://i.imgur.com/2ID317J.jpg" height="100" width="100" alt="jaxo" />
---
0xfa1afc4534fc9f80a552e61dd04cd8a172c821a6