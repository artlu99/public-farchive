username: qj
fid: 8066
display name: QJ
PFP: [https://i.imgur.com/KlM6XAg.jpg](https://i.imgur.com/KlM6XAg.jpg)
bio: Building ecf.network & at Ethereum Community Fund

<img src="https://i.imgur.com/KlM6XAg.jpg" height="100" width="100" alt="QJ" />
