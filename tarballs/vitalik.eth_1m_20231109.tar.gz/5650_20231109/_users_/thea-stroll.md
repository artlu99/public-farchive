username: thea-stroll
fid: 189492
display name: Loopy.thea
PFP: [https://i.imgur.com/HUCb0ku.jpg](https://i.imgur.com/HUCb0ku.jpg)
bio: Welcome to thea.space,
You may find me in:
instagram: aeth.nutri/
X: https://twitter.com/aeth_009
Polyhedron I am..

<img src="https://i.imgur.com/HUCb0ku.jpg" height="100" width="100" alt="Loopy.thea" />
---
0x1b3f0e64c719ad0c38606b007b114f1072919642