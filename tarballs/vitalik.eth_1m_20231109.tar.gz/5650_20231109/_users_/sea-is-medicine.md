username: sea-is-medicine
fid: 14940
display name: Naomi 
PFP: [https://i.imgur.com/q8D5Ei2.jpg](https://i.imgur.com/q8D5Ei2.jpg)
bio: Collage Artist https://www.linktr.ee/theseaismedicine Photographer https://www.linktr.ee/NaomiOlsonPhoto Podcast https://anchor.fm/theseaismedicine

<img src="https://i.imgur.com/q8D5Ei2.jpg" height="100" width="100" alt="Naomi " />
---
0x13e1cc660c7b212bf888334a76e601ad414be4a5