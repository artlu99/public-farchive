username: ds8
fid: 11124
display name: dusan
PFP: [https://i.imgur.com/pK5BjjD.jpg](https://i.imgur.com/pK5BjjD.jpg)
bio: fortune cookie casts

<img src="https://i.imgur.com/pK5BjjD.jpg" height="100" width="100" alt="dusan" />
---
0x000cbf0bec88214aab15bc1fa40d3c30b3ca97a9