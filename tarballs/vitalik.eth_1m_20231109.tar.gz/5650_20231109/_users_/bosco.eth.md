username: bosco.eth
fid: 12074
display name: bosco.eth
PFP: [https://i.seadn.io/gcs/files/05ee1679a9d81c369ca9f943e5ee8576.png?w=500&auto=format](https://i.seadn.io/gcs/files/05ee1679a9d81c369ca9f943e5ee8576.png?w=500&auto=format)
bio: Love Freedom, Ethereum and the Infinite Garden.

<img src="https://i.seadn.io/gcs/files/05ee1679a9d81c369ca9f943e5ee8576.png?w=500&auto=format" height="100" width="100" alt="bosco.eth" />
---
0x92ff9253342bbb80cdc2abd1bf619a6add1852e0
0x30c7f4f7504d6366916f669cd8e731ed4df6c702