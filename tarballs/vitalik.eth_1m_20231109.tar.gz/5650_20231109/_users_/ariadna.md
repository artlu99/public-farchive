username: ariadna
fid: 17395
display name: Ariadna
PFP: [https://i.imgur.com/ru9aIyF.jpg](https://i.imgur.com/ru9aIyF.jpg)
bio: Lover of Bitcoin and Ethereum

<img src="https://i.imgur.com/ru9aIyF.jpg" height="100" width="100" alt="Ariadna" />
