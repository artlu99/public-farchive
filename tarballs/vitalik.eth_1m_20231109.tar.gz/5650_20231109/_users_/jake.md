username: jake
fid: 1020
display name: JAKE
PFP: [https://i.seadn.io/gae/14UfhnG7N4Rz4XUeC51wcL49_EIUCMyK_s10_5bs2hVkKqcOd_A8DC-etr4Uqrvntw09_zm-fK5ZiOJRZPTx7yGaJmx1Mno_SBvFkw?w=500&auto=format](https://i.seadn.io/gae/14UfhnG7N4Rz4XUeC51wcL49_EIUCMyK_s10_5bs2hVkKqcOd_A8DC-etr4Uqrvntw09_zm-fK5ZiOJRZPTx7yGaJmx1Mno_SBvFkw?w=500&auto=format)
bio: podofjake.com | twitter.com/0FJAKE

<img src="https://i.seadn.io/gae/14UfhnG7N4Rz4XUeC51wcL49_EIUCMyK_s10_5bs2hVkKqcOd_A8DC-etr4Uqrvntw09_zm-fK5ZiOJRZPTx7yGaJmx1Mno_SBvFkw?w=500&auto=format" height="100" width="100" alt="JAKE" />
---
0xd91c4283ebbc00af162b73418ec4ab0b3c159900