username: bradbarrish
fid: 16066
display name: Brad Barrish
PFP: [https://i.imgur.com/7FOsSrX.jpg](https://i.imgur.com/7FOsSrX.jpg)
bio: Internet Explorer 🧭 On a break from work, following my intellectual interests and letting curiosity guide me. xSonos xOura

<img src="https://i.imgur.com/7FOsSrX.jpg" height="100" width="100" alt="Brad Barrish" />
---
0x6be2676dddaeb63d4dab83e341d3abaef752a1a4