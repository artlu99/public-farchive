username: mememaster
fid: 22051
display name: Daniel Sterling
PFP: [https://i.imgur.com/4ocjp2y.gif](https://i.imgur.com/4ocjp2y.gif)
bio: Daniel love memes and posts from a forgotten era of the internet.

<img src="https://i.imgur.com/4ocjp2y.gif" height="100" width="100" alt="Daniel Sterling" />
---
0x82b171ccadf43fc453b428b428693be638d62843