username: kenjisrealm
fid: 189212
display name: Kenjisrealm
PFP: [https://i.imgur.com/8F7uOzn.jpg](https://i.imgur.com/8F7uOzn.jpg)
bio: RWA, DeFi Builder. Working on New Trust Layer for Trading Community- BlablaBlock.

<img src="https://i.imgur.com/8F7uOzn.jpg" height="100" width="100" alt="Kenjisrealm" />
