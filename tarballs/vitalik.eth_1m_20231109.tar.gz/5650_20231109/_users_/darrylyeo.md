username: darrylyeo
fid: 3854
display name: Darryl Yeo 🛠️
PFP: [https://lh3.googleusercontent.com/aDoZOILQ0sqiFJOXVsdV2AmuU2cSQibSOa6-EehpX-O6vvY9S0cdNwlVO5H60WXTwNJx978c5vFogC7D1iEF3PM8pStespChorpp](https://lh3.googleusercontent.com/aDoZOILQ0sqiFJOXVsdV2AmuU2cSQibSOa6-EehpX-O6vvY9S0cdNwlVO5H60WXTwNJx978c5vFogC7D1iEF3PM8pStespChorpp)
bio: frontend dev・UI/UX abstractionist・DeFi/web3 builder・building blockhead.info・prev dYdX・darryl__yeo.twitter

<img src="https://lh3.googleusercontent.com/aDoZOILQ0sqiFJOXVsdV2AmuU2cSQibSOa6-EehpX-O6vvY9S0cdNwlVO5H60WXTwNJx978c5vFogC7D1iEF3PM8pStespChorpp" height="100" width="100" alt="Darryl Yeo 🛠️" />
