username: borodutch
fid: 1356
display name: borodutch 👈👈😎
PFP: [https://i.seadn.io/gae/lizxqvPI1NTC-DrZSEbN95B0dUgngbdsZmILXF8YeQq-v1EmuzImHa0HmVMwdsNrGjN2Yn64v3mYv9e7-kqJuOHmO4op5v_zwPKxWWo?w=500&auto=format](https://i.seadn.io/gae/lizxqvPI1NTC-DrZSEbN95B0dUgngbdsZmILXF8YeQq-v1EmuzImHa0HmVMwdsNrGjN2Yn64v3mYv9e7-kqJuOHmO4op5v_zwPKxWWo?w=500&auto=format)
bio: cto @ bwl.gg (ketl.xyz), 80M+ users (bdut.ch) 🙏 built sealcred.xyz, @sealcaster, @remindme, @essay, @mintit, @gpt, @health, farcantasy.xyz, @purpler

<img src="https://i.seadn.io/gae/lizxqvPI1NTC-DrZSEbN95B0dUgngbdsZmILXF8YeQq-v1EmuzImHa0HmVMwdsNrGjN2Yn64v3mYv9e7-kqJuOHmO4op5v_zwPKxWWo?w=500&auto=format" height="100" width="100" alt="borodutch 👈👈😎" />
---
0xbf74483db914192bb0a9577f3d8fb29a6d4c08ee