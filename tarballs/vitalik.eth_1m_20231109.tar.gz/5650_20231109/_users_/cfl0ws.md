username: cfl0ws
fid: 20474
display name: cfl0ws / chainflow
PFP: [https://i.imgur.com/KEQyQ6F.jpg](https://i.imgur.com/KEQyQ6F.jpg)
bio: Building crypto infrastructure for a better future at chainflow.io

<img src="https://i.imgur.com/KEQyQ6F.jpg" height="100" width="100" alt="cfl0ws / chainflow" />
