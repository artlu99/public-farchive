username: entropybender
fid: 13659
display name: kevin j
PFP: [https://i.seadn.io/gcs/files/511314f217d2107e7ce6dc7c58c0d39d.png?w=500&auto=format](https://i.seadn.io/gcs/files/511314f217d2107e7ce6dc7c58c0d39d.png?w=500&auto=format)
bio: founder / cto @ operator.io // building a LLM powered intents layer // former BCI and bioinformatics researcher

<img src="https://i.seadn.io/gcs/files/511314f217d2107e7ce6dc7c58c0d39d.png?w=500&auto=format" height="100" width="100" alt="kevin j" />
---
0xaec8c478446bddc2d022a03c90ca394269342ce2