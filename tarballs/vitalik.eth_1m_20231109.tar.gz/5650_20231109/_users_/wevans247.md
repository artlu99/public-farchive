username: wevans247
fid: 14767
display name: Wev
PFP: [https://i.seadn.io/gcs/files/5f33d9d6b530182df4487b3f9b7cce0a.png?w=500&auto=format](https://i.seadn.io/gcs/files/5f33d9d6b530182df4487b3f9b7cce0a.png?w=500&auto=format)
bio: Art Director, Traveler, Collector

<img src="https://i.seadn.io/gcs/files/5f33d9d6b530182df4487b3f9b7cce0a.png?w=500&auto=format" height="100" width="100" alt="Wev" />
---
0xcd1a900c775c87e4b86822069abfb0a2714a5f61
0xdb64ca612955d75258eae3c1f23ab0a1ffa9e4ed