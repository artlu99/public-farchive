username: philipliao
fid: 8244
display name: Phil Liao
PFP: [https://i.imgur.com/dAjdrie.jpg](https://i.imgur.com/dAjdrie.jpg)
bio: Engineering @ 0x | Interested in walkable cities

<img src="https://i.imgur.com/dAjdrie.jpg" height="100" width="100" alt="Phil Liao" />
---
0xdd0c58a610466d5fa54e27817c3433006257bdb2