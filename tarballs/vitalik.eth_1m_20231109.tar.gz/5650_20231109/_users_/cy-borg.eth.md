username: cy-borg.eth
fid: 11915
display name: Cyrus SwissBorg
PFP: [https://i.imgur.com/vV6bX5O.jpg](https://i.imgur.com/vV6bX5O.jpg)
bio: Financial Freedom fighter, may the $Borg enlighten you. 
Proud Founder of SwissBorg, 6 years anniversary ICO and still loving this game 💚🫵🏽💚🧑🏽‍🚀

<img src="https://i.imgur.com/vV6bX5O.jpg" height="100" width="100" alt="Cyrus SwissBorg" />
---
0x5f5376bb63732533e174d0a06f2cd0b0cc3adb75