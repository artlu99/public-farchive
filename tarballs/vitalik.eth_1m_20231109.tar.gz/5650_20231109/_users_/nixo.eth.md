username: nixo.eth
fid: 4996
display name: nixo
PFP: [https://i.imgur.com/txHf7e5.png](https://i.imgur.com/txHf7e5.png)
bio: executive director @ethstaker // stake responsibly //
be a kind human // nomadic

<img src="https://i.imgur.com/txHf7e5.png" height="100" width="100" alt="nixo" />
---
0x04c0cd38b8c203b14ef2b7b8d736d69b938aff71
0x2a7ee44494e5efe3d31c606c51e030a5adac1011
0x5554672e67ba866b9861701d0e0494ab324ad19a