username: macbudkowski
fid: 1048
display name: Mac Budkowski (🥝)
PFP: [https://i.seadn.io/gae/j9fZd-_CTm_AOL-AsAvwHIW57SyKQdB_amN-kgbD_TH2O1pehgvtLMOvWc9bKq-WgEzhYQ_WDOHnyib1KV9slyIXUGmRrQSInN7fZbw?w=500&auto=format](https://i.seadn.io/gae/j9fZd-_CTm_AOL-AsAvwHIW57SyKQdB_amN-kgbD_TH2O1pehgvtLMOvWc9bKq-WgEzhYQ_WDOHnyib1KV9slyIXUGmRrQSInN7fZbw?w=500&auto=format)
bio: Building @kiwi 
Sharing golds @ goldmine3.xyz
Podcasting @ web3talks.xyz.
Consulting @ macbudkowski.com
Sharing GoerliETH @ goerlinator.xyz

<img src="https://i.seadn.io/gae/j9fZd-_CTm_AOL-AsAvwHIW57SyKQdB_amN-kgbD_TH2O1pehgvtLMOvWc9bKq-WgEzhYQ_WDOHnyib1KV9slyIXUGmRrQSInN7fZbw?w=500&auto=format" height="100" width="100" alt="Mac Budkowski (🥝)" />
---
0x3e6c23cdaa52b1b6621dbb30c367d16ace21f760