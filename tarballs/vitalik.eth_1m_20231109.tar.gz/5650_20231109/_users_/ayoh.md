username: ayoh
fid: 18782
display name: Ayohtunde
PFP: [https://i.imgur.com/q3pMRBv.jpg](https://i.imgur.com/q3pMRBv.jpg)
bio: UI Designer, builder and a contributor.

<img src="https://i.imgur.com/q3pMRBv.jpg" height="100" width="100" alt="Ayohtunde" />
---
0xba8d6600f02cd4abd93ec63eb99463a18ac75004