username: eichenkundiger
fid: 2785
display name: Gegè E.K. 🧃
PFP: [https://i.imgur.com/lZEVca1.png](https://i.imgur.com/lZEVca1.png)
bio: exploring. also doing some uiux for dapps.   
🌤 https://nf.td/onchain 🌪

<img src="https://i.imgur.com/lZEVca1.png" height="100" width="100" alt="Gegè E.K. 🧃" />
---
0x8358fc2dd62c00c1a9cd0fcb577309a4cead2471