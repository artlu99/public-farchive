username: usmfit.eth
fid: 190587
display name: usmfit 
PFP: [https://i.seadn.io/s/raw/files/f06ba9e92fd5ae2393a5d394604ec568.png?w=500&auto=format](https://i.seadn.io/s/raw/files/f06ba9e92fd5ae2393a5d394604ec568.png?w=500&auto=format)
bio: Yoga, Web3, Blockchain

<img src="https://i.seadn.io/s/raw/files/f06ba9e92fd5ae2393a5d394604ec568.png?w=500&auto=format" height="100" width="100" alt="usmfit " />
---
0x1eb2fadbdf69920ded2d6fa87d6ce9a4193a1522