username: n
fid: 274
display name: Nico.cast
PFP: [https://lh3.googleusercontent.com/EYngmyheqv2rtcwSkpvHavxCrkh9G9vlN1llhZaxoJoIThnPOg_dseMCFtcL35K9YG3644cJzYt1Ov1BhTSUiPmpDcgB1Zi9VodouA](https://lh3.googleusercontent.com/EYngmyheqv2rtcwSkpvHavxCrkh9G9vlN1llhZaxoJoIThnPOg_dseMCFtcL35K9YG3644cJzYt1Ov1BhTSUiPmpDcgB1Zi9VodouA)
bio: building @beb, @farquest & investing at miy.com ventures. Previously AI stuff at Square. nf.td/nico

<img src="https://lh3.googleusercontent.com/EYngmyheqv2rtcwSkpvHavxCrkh9G9vlN1llhZaxoJoIThnPOg_dseMCFtcL35K9YG3644cJzYt1Ov1BhTSUiPmpDcgB1Zi9VodouA" height="100" width="100" alt="Nico.cast" />
---
0x673a827c0df98274fa94ef194f7f9d1a8a00bbb9