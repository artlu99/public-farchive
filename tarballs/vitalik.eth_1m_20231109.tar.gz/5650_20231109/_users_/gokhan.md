username: gokhan
fid: 2282
display name: Gökhan @ ZuConnect + Devconnect
PFP: [https://i.imgur.com/87ybQ45.jpg](https://i.imgur.com/87ybQ45.jpg)
bio: tropicokantian primordial smart contractual soup research fellow at the institute of per block time of existence

🌞 avalidurl.com 🌞 

<img src="https://i.imgur.com/87ybQ45.jpg" height="100" width="100" alt="Gökhan @ ZuConnect + Devconnect" />
---
0x36de990133d36d7e3df9a820aa3ede5a2320de71