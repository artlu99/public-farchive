username: crash
fid: 7954
display name: crash
PFP: [https://i.imgur.com/sCLq0gx.png](https://i.imgur.com/sCLq0gx.png)
bio: - bad ideas maxi
- privacy enjoyooor

<img src="https://i.imgur.com/sCLq0gx.png" height="100" width="100" alt="crash" />
