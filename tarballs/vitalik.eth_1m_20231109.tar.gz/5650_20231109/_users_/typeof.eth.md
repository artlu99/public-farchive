username: typeof.eth
fid: 6162
display name: typeof.eth
PFP: [https://i.imgur.com/xJvOwLz.gif](https://i.imgur.com/xJvOwLz.gif)
bio: Dan Cortes
Staff Engineer at Iron Fish
Building Block Socks 🧦

<img src="https://i.imgur.com/xJvOwLz.gif" height="100" width="100" alt="typeof.eth" />
---
0xfa6b3df826636eb76e23c1ee38180db3b8f60a86