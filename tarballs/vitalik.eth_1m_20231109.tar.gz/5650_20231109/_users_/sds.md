username: sds
fid: 17
display name: Shane da Silva
PFP: [https://i.seadn.io/gae/8gYoPP2mTxWhth4f4NZSQjaIBq0WTQWhwpJB3Cl8YvK3dUwoOLDxCSlUMQrkdM-mb3HNRmY_7xmIxARAEEjgxlXIrgj5nFp3ithB?w=500&auto=format](https://i.seadn.io/gae/8gYoPP2mTxWhth4f4NZSQjaIBq0WTQWhwpJB3Cl8YvK3dUwoOLDxCSlUMQrkdM-mb3HNRmY_7xmIxARAEEjgxlXIrgj5nFp3ithB?w=500&auto=format)
bio: Building @warpcast and @farcaster. Previously Coinbase, Brigade, Causes.

<img src="https://i.seadn.io/gae/8gYoPP2mTxWhth4f4NZSQjaIBq0WTQWhwpJB3Cl8YvK3dUwoOLDxCSlUMQrkdM-mb3HNRmY_7xmIxARAEEjgxlXIrgj5nFp3ithB?w=500&auto=format" height="100" width="100" alt="Shane da Silva" />
---
0x9d363fc4bc4d94c135d004f84ca5a44643ffb816
0x73526226a883d78b81ad98981767ae00b629fb48