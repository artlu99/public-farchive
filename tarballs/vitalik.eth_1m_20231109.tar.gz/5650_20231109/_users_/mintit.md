username: mintit
fid: 7068
display name: MintIt
PFP: [https://i.imgur.com/NgmsjmF.png](https://i.imgur.com/NgmsjmF.png)
bio: 🤖 beep boop, I'm a bot, reply to any cast with "@mintit" to mint it as an NFT! Built by @borodutch with ❤️ Open source: bit.ly/3WQRTXH

<img src="https://i.imgur.com/NgmsjmF.png" height="100" width="100" alt="MintIt" />
