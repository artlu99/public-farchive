username: s0tric
fid: 15380
display name: s0tric
PFP: [https://i.imgur.com/UuosAhr.jpg](https://i.imgur.com/UuosAhr.jpg)
bio: ₿ringing Strong People ₮ogether ♟ Founder ⬩WW⬩
https://t.me/wallet_world

<img src="https://i.imgur.com/UuosAhr.jpg" height="100" width="100" alt="s0tric" />
---
0x23631b12402fe1b2404fccfab01557269b0df108