username: zodiac
fid: 188322
display name: zodiac
PFP: [https://i.imgur.com/uPdnIsp.jpg](https://i.imgur.com/uPdnIsp.jpg)
bio: Web3 Speaker l DeFi l NFT l degen.

<img src="https://i.imgur.com/uPdnIsp.jpg" height="100" width="100" alt="zodiac" />
---
0x0247eb3d8e69e8f930ebd634bec77e4c8dad7277