username: jamesyoung
fid: 6087
display name: jamesyoung.eth
PFP: [https://i.seadn.io/gcs/files/f59d6408aef18d4d701fc3443fddeb57.gif?w=500&auto=format](https://i.seadn.io/gcs/files/f59d6408aef18d4d701fc3443fddeb57.gif?w=500&auto=format)
bio: dreaming in Collab.Land 🦾🤖

<img src="https://i.seadn.io/gcs/files/f59d6408aef18d4d701fc3443fddeb57.gif?w=500&auto=format" height="100" width="100" alt="jamesyoung.eth" />
---
0x5bb3e1774923b75ecb804e2559149bbd2a39a414