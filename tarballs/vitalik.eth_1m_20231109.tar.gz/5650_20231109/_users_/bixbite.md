username: bixbite
fid: 20147
display name: Bixbite 
PFP: [https://i.imgur.com/C0CltXU.jpg](https://i.imgur.com/C0CltXU.jpg)
bio: Lil Noun 1673

<img src="https://i.imgur.com/C0CltXU.jpg" height="100" width="100" alt="Bixbite " />
---
0x073f0dc58e9989c827ba5b7b35570b7315652e63