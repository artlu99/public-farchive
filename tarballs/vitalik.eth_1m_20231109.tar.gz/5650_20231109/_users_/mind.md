username: mind
fid: 19644
display name: Em
PFP: [https://i.imgur.com/ahtWhdI.jpg](https://i.imgur.com/ahtWhdI.jpg)
bio: Buffalo buffalo Buffalo buffalo buffalo Buffalo buffalo. More later.

<img src="https://i.imgur.com/ahtWhdI.jpg" height="100" width="100" alt="Em" />
