username: albiverse
fid: 6473
display name: albi
PFP: [https://i.imgur.com/wM5NTdb.jpg](https://i.imgur.com/wM5NTdb.jpg)
bio: writing about web3 social | breathwork, meditation, nervous system nerd

<img src="https://i.imgur.com/wM5NTdb.jpg" height="100" width="100" alt="albi" />
---
0x1fa91e165b2b8da6d8771130b6e923cfaa52ee37
0xbe40dcadb6bf4de1c7810eca3504e5f3bea9cf35