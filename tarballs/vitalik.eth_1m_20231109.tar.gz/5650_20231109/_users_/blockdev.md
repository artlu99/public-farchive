username: blockdev
fid: 14923
display name: blockdev
PFP: [https://i.imgur.com/x3EvGJ0.jpg](https://i.imgur.com/x3EvGJ0.jpg)
bio: Privacy&Scaling Explorations at @ethereum foundation

<img src="https://i.imgur.com/x3EvGJ0.jpg" height="100" width="100" alt="blockdev" />
