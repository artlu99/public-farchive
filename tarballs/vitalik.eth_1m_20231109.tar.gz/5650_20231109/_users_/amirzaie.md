username: amirzaie
fid: 192416
display name: Alborz Mirzaie
PFP: [https://i.imgur.com/RpFVVYU.jpg](https://i.imgur.com/RpFVVYU.jpg)
bio: I’m a public health researcher, primary focus in sustainable development and community health. I love to play soccer and chess (play me on chess.com @lalumam).

<img src="https://i.imgur.com/RpFVVYU.jpg" height="100" width="100" alt="Alborz Mirzaie" />
