username: zkp
fid: 17498
display name: James
PFP: [https://i.imgur.com/nK7UYld.jpg](https://i.imgur.com/nK7UYld.jpg)
bio: cooler irl 

<img src="https://i.imgur.com/nK7UYld.jpg" height="100" width="100" alt="James" />
---
0x346240a8b47497c87cec082cd5ba88589893e0aa
0x8dd6b32d6229f640047ee1ec9e20ab61983082a7
0xff360f84db2df5548f1ad4b4f62c14524143f9f4