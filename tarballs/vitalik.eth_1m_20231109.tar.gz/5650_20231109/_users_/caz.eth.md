username: caz.eth
fid: 11720
display name: caz.eth
PFP: [https://i.imgur.com/eiV3XTt.png](https://i.imgur.com/eiV3XTt.png)
bio: Writing at caz.pub | Co-founder, partner, investor @ node.vc

<img src="https://i.imgur.com/eiV3XTt.png" height="100" width="100" alt="caz.eth" />
---
0x13279518b5541b50c099c790b67ea5956a277954
0x648b8ad47e540a71abae5c285ecc1e6d34eab8c3
0x2ac521461b8127438e8b4a2c6f7330caa0890c1c
0xf419458e46e7480b33e790e64509a966c1771e26