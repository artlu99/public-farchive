username: raz
fid: 656
display name: raz
PFP: [https://i.imgur.com/Sa2ORdL.jpg](https://i.imgur.com/Sa2ORdL.jpg)
bio: ceo at @guild

<img src="https://i.imgur.com/Sa2ORdL.jpg" height="100" width="100" alt="raz" />
---
0xf0ae4f60a4dc379ae25371a34b4b699dee8d530f