username: 4li
fid: 18481
display name: 0xAli
PFP: [https://i.imgur.com/ntOfEtW.jpg](https://i.imgur.com/ntOfEtW.jpg)
bio: Mobile App Developer | DeFi/Web3 Enthusiast

<img src="https://i.imgur.com/ntOfEtW.jpg" height="100" width="100" alt="0xAli" />
---
0xedb61a92de9d08874bdf2a9d1fdf8df9f111bf7d