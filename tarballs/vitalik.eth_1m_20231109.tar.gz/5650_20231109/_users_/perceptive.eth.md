username: perceptive.eth
fid: 108
display name: Nick Tomaino
PFP: [https://img.seadn.io/files/8f2c68f31100be736f04492fbe6a6b93.jpg?fit=max&h=1200&w=1200&auto=format](https://img.seadn.io/files/8f2c68f31100be736f04492fbe6a6b93.jpg?fit=max&h=1200&w=1200&auto=format)
bio: purist x tourist 🎯

<img src="https://img.seadn.io/files/8f2c68f31100be736f04492fbe6a6b93.jpg?fit=max&h=1200&w=1200&auto=format" height="100" width="100" alt="Nick Tomaino" />
---
0xeefec5734f649fd1a356894319d3d7393b6b0f8b