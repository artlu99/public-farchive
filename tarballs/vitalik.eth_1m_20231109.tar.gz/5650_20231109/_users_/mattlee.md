username: mattlee
fid: 6591
display name: Matt Lee 
PFP: [https://i.imgur.com/w3f0n6Y.png](https://i.imgur.com/w3f0n6Y.png)
bio: Builder of software and songs. CS grad student. co-founder of polp.app(development currently paused)

Music, Blog, Website: https://www.mattlee.world/links

<img src="https://i.imgur.com/w3f0n6Y.png" height="100" width="100" alt="Matt Lee " />
---
0x3ee75b599c076193b81885ca1838e560d268aad1