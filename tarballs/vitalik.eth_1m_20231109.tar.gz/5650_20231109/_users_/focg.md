username: focg
fid: 192134
display name: FOCG
PFP: [https://i.imgur.com/DF5JcsL.jpg](https://i.imgur.com/DF5JcsL.jpg)
bio: Something

<img src="https://i.imgur.com/DF5JcsL.jpg" height="100" width="100" alt="FOCG" />
---
0x55980f1ef0e64e08cc0b24c22a4709a000637f45