username: jamiew
fid: 336
display name: Jamie Dubs
PFP: [https://pbs.twimg.com/profile_images/1044934513871151109/TDjsKYZT_400x400.jpg](https://pbs.twimg.com/profile_images/1044934513871151109/TDjsKYZT_400x400.jpg)
bio: human bean

<img src="https://pbs.twimg.com/profile_images/1044934513871151109/TDjsKYZT_400x400.jpg" height="100" width="100" alt="Jamie Dubs" />
---
0xd9c4475e2dd89a9a0ad0c1e9a1e1bb28df7ba298