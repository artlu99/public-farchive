username: otismc09
fid: 193476
display name: Otis Mc.
PFP: [https://i.imgur.com/2jLjLJ5.jpg](https://i.imgur.com/2jLjLJ5.jpg)
bio: Deep researcher. Sometimes ghost writer.
Creator: https://twitter.com/0xMavelWeb3

<img src="https://i.imgur.com/2jLjLJ5.jpg" height="100" width="100" alt="Otis Mc." />
---
0xfcd16dfe976a19dd6140c64ea43e51f429e5f283
0x7113e54bb1aab1de05d907623a016461fa8d4027