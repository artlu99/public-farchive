username: speakup
fid: 13323
display name: Speakup 
PFP: [https://i.seadn.io/s/raw/files/2585ab82489e7d0625ba7adc4042f9fe.png?w=500&auto=format](https://i.seadn.io/s/raw/files/2585ab82489e7d0625ba7adc4042f9fe.png?w=500&auto=format)
bio: OG is many ways. Collaboration is the only way. Break all monopolies.
New.foundation
Release the kraken



<img src="https://i.seadn.io/s/raw/files/2585ab82489e7d0625ba7adc4042f9fe.png?w=500&auto=format" height="100" width="100" alt="Speakup " />
---
0xea32f2de0faf3a6926a9762a48a1fb27a4c95541
0x2040a831df5e8952eb0af8ecfdab59607683aff1