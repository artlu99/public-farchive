username: 0xlght
fid: 13121
display name: LGHT
PFP: [https://i.imgur.com/ICnFHvq.jpg](https://i.imgur.com/ICnFHvq.jpg)
bio: Cofounder Based Management. lght.mirror.xyz

<img src="https://i.imgur.com/ICnFHvq.jpg" height="100" width="100" alt="LGHT" />
---
0x547a2e8d97dc99be21e509fa93c4fa5dd76b8ed0