username: duongthuong
fid: 191790
display name: Duong Thuong 
PFP: [https://i.imgur.com/8AcqrVl.jpg](https://i.imgur.com/8AcqrVl.jpg)
bio: Cùng kết nối-cùng nhau phát triển cùng liên kết Nhóm Farcaster Việt Nam https://t.me/farcasterviet

<img src="https://i.imgur.com/8AcqrVl.jpg" height="100" width="100" alt="Duong Thuong " />
---
0xa25804dd33cd370b7e77a601e9d3f5c3e5fce132