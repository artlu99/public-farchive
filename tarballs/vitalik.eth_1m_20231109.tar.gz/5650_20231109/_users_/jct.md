username: jct
fid: 9846
display name: Jason Thane
PFP: [https://i.seadn.io/gae/w5w0UH8C-XBkUHBdmvyQC9FNPz4iW36J8j8G6U-QRqDMKKHYmVuECtv0lbkXGzlk0wBnbVo7U0kVJsbEjQqd8hmEq0DVQsAAnmeX_Q?w=500&auto=format](https://i.seadn.io/gae/w5w0UH8C-XBkUHBdmvyQC9FNPz4iW36J8j8G6U-QRqDMKKHYmVuECtv0lbkXGzlk0wBnbVo7U0kVJsbEjQqd8hmEq0DVQsAAnmeX_Q?w=500&auto=format)
bio: I’m a maker and a fan of future things. I think software should be tools, and tools should only work for their user, never against.

<img src="https://i.seadn.io/gae/w5w0UH8C-XBkUHBdmvyQC9FNPz4iW36J8j8G6U-QRqDMKKHYmVuECtv0lbkXGzlk0wBnbVo7U0kVJsbEjQqd8hmEq0DVQsAAnmeX_Q?w=500&auto=format" height="100" width="100" alt="Jason Thane" />
---
0xcd099e50e0abf41a53db26cd08e21dbcd223eeef