username: godspeeduck
fid: 188803
display name: Godspeeduck
PFP: [https://i.imgur.com/JmGRUra.jpg](https://i.imgur.com/JmGRUra.jpg)
bio: God speed 🦆～

<img src="https://i.imgur.com/JmGRUra.jpg" height="100" width="100" alt="Godspeeduck" />
