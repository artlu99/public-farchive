username: marzbal
fid: 16255
display name: Masoud
PFP: [https://i.imgur.com/LMolr54.jpg](https://i.imgur.com/LMolr54.jpg)
bio: I am from Marzbal.
I work in oil industry
I like crypto currency.

<img src="https://i.imgur.com/LMolr54.jpg" height="100" width="100" alt="Masoud" />
---
0x4ac8923ab14ca8082222e3c12e11aa9b3a9dfa74