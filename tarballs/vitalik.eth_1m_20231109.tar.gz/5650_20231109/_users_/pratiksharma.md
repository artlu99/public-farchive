username: pratiksharma
fid: 17652
display name: Pratik Sharma 
PFP: [https://i.imgur.com/mnjtft3.jpg](https://i.imgur.com/mnjtft3.jpg)
bio: 🪂Building :
https://t.me/Earn_With_Crypto_Looters

<img src="https://i.imgur.com/mnjtft3.jpg" height="100" width="100" alt="Pratik Sharma " />
---
0x76f980cfe17d4ff3e3f9ddce2129c17e55a1091d