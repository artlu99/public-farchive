username: megumii.eth
fid: 12254
display name: 𝄞 ar://megumii ⓐ🟪
PFP: [https://i.imgur.com/BFpcKT1.jpg](https://i.imgur.com/BFpcKT1.jpg)
bio: Part of @sarcophagus ⚰️

\ Part of KessokuDAO🪡 \ About me megumii.blessingway.xyz \ I Love $AR, Anime, Rhythm Game, and Classical Music \ KatouMegumii.telegram

<img src="https://i.imgur.com/BFpcKT1.jpg" height="100" width="100" alt="𝄞 ar://megumii ⓐ🟪" />
---
0x0d548b394f2d7be11f511606339a1e80a70a35a1
0x571f7567b4b6440af78b043e657c9d5013be250d