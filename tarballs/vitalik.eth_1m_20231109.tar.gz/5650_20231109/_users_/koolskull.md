username: koolskull
fid: 20572
display name: KOOL SKULL
PFP: [https://i.seadn.io/s/raw/files/78674a51be40556dd8ee5c7abd4b17ee.png?w=500&auto=format](https://i.seadn.io/s/raw/files/78674a51be40556dd8ee5c7abd4b17ee.png?w=500&auto=format)
bio: Chipthrash Shaman - Koolness Konsultant - Painter of Inter-dimensional Portals - Los Angeles Native

<img src="https://i.seadn.io/s/raw/files/78674a51be40556dd8ee5c7abd4b17ee.png?w=500&auto=format" height="100" width="100" alt="KOOL SKULL" />
---
0xf065f2a89683dd8cd76ab15c686a781f0b351eab