username: kmacb.eth
fid: 4163
display name: KMac🟪⏩🥝🧃
PFP: [https://openseauserdata.com/files/12cc9c02bf8d37d0a097745d9e39ae7b.svg](https://openseauserdata.com/files/12cc9c02bf8d37d0a097745d9e39ae7b.svg)
bio: Normalizing typos one cast at a time. 

<img src="https://openseauserdata.com/files/12cc9c02bf8d37d0a097745d9e39ae7b.svg" height="100" width="100" alt="KMac🟪⏩🥝🧃" />
---
0x8b80755c441d355405ca7571443bb9247b77ec16