username: gonna
fid: 17229
display name: Gonna
PFP: [https://i.imgur.com/MfKZcGY.jpg](https://i.imgur.com/MfKZcGY.jpg)
bio: EthernautDAO founder - Optimism Grants Council ops

<img src="https://i.imgur.com/MfKZcGY.jpg" height="100" width="100" alt="Gonna" />
