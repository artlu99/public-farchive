username: hailuavn1
fid: 192776
display name: Thang
PFP: [https://i.imgur.com/LE4RmiH.jpg](https://i.imgur.com/LE4RmiH.jpg)
bio: Fan Crypto, Vitalik, Cz, Gavin wood
Ethereum, Bitcoin

<img src="https://i.imgur.com/LE4RmiH.jpg" height="100" width="100" alt="Thang" />
