username: mmd
fid: 5263
display name: Mert from GodmodeHQ
PFP: [https://i.imgur.com/EZPnmLz.jpg](https://i.imgur.com/EZPnmLz.jpg)
bio: Founder of godmodehq.com | We match wallet addresses to social media handles for scalable user acquisition in Web3 📈

<img src="https://i.imgur.com/EZPnmLz.jpg" height="100" width="100" alt="Mert from GodmodeHQ" />
---
0x9ecd44cac562b1b0cdbafc704b1099ab3c3978fc