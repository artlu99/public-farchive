username: d0xm
fid: 189426
display name: dom
PFP: [https://i.imgur.com/uMdvL1w.jpg](https://i.imgur.com/uMdvL1w.jpg)
bio: autistic

<img src="https://i.imgur.com/uMdvL1w.jpg" height="100" width="100" alt="dom" />
