username: kepano
fid: 1321
display name: kepano
PFP: [https://openseauserdata.com/files/bcd4026d9d2fef636dbe8305b042b061.svg](https://openseauserdata.com/files/bcd4026d9d2fef636dbe8305b042b061.svg)
bio: making obsidian.md • writing stephango.com

<img src="https://openseauserdata.com/files/bcd4026d9d2fef636dbe8305b042b061.svg" height="100" width="100" alt="kepano" />
---
0x6a46d7a8a5d34aeb166bbbdeb496ff1c14e445ce