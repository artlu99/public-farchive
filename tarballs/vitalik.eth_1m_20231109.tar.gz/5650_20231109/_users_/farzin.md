username: farzin
fid: 15469
display name: Farzin
PFP: [https://i.imgur.com/dVSwPaU.jpg](https://i.imgur.com/dVSwPaU.jpg)
bio: Trader and investor

<img src="https://i.imgur.com/dVSwPaU.jpg" height="100" width="100" alt="Farzin" />
---
0x545425f9686b56078da3bfac5f9f25bb287b1291