username: jessepollak.eth
fid: 99
display name: Jesse Pollak 🔵
PFP: [https://i.seadn.io/gae/GFkg_668tE-YxTKPt_XcZdL_xKMQ2CitZKR2L7dJoLoMXH4hUFXHv3Tzes-2hZWiyTEACe6AvutNqBpNbN_WS3b25g?w=500&auto=format](https://i.seadn.io/gae/GFkg_668tE-YxTKPt_XcZdL_xKMQ2CitZKR2L7dJoLoMXH4hUFXHv3Tzes-2hZWiyTEACe6AvutNqBpNbN_WS3b25g?w=500&auto=format)
bio: @base contributor #001; onchain cities w/ OAK & city3

<img src="https://i.seadn.io/gae/GFkg_668tE-YxTKPt_XcZdL_xKMQ2CitZKR2L7dJoLoMXH4hUFXHv3Tzes-2hZWiyTEACe6AvutNqBpNbN_WS3b25g?w=500&auto=format" height="100" width="100" alt="Jesse Pollak 🔵" />
---
0x849151d7d0bf1f34b70d5cad5149d28cc2308bf1
0xe73f9c181b571cac2bf3173634d04a9921b7ffcf
0x6e0d9c6dd8a08509bb625caa35dc61a991406f62