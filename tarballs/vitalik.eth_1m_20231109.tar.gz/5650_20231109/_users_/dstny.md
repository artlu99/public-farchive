username: dstny
fid: 3731
display name: Tom ⌐◨-◨
PFP: [https://i.imgur.com/M1MQ8du.jpg](https://i.imgur.com/M1MQ8du.jpg)
bio: Existing — also doing join.cash & hanging out at DSTNYgroup.twitter

May post on here sporadically, but I promise I’m reading your casts 🫡 Checking DCs too!

<img src="https://i.imgur.com/M1MQ8du.jpg" height="100" width="100" alt="Tom ⌐◨-◨" />
---
0x074392f8e31a50c3f41376d47c59587b1890c4be