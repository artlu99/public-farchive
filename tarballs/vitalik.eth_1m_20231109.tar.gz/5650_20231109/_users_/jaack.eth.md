username: jaack.eth
fid: 16884
display name: Jaack
PFP: [https://i.seadn.io/gae/3i25PPuohOIffWIII3KKHhV7JVoFKFAuXQy9sWJezs89KRcYAq34HH6DPiGy6-DhCiB_Sll145WS-SqKBhKvoA4?w=500&auto=format](https://i.seadn.io/gae/3i25PPuohOIffWIII3KKHhV7JVoFKFAuXQy9sWJezs89KRcYAq34HH6DPiGy6-DhCiB_Sll145WS-SqKBhKvoA4?w=500&auto=format)
bio: Building Avascan. Bootstrapping Routescan, an EVM explorer focused on L2s.

<img src="https://i.seadn.io/gae/3i25PPuohOIffWIII3KKHhV7JVoFKFAuXQy9sWJezs89KRcYAq34HH6DPiGy6-DhCiB_Sll145WS-SqKBhKvoA4?w=500&auto=format" height="100" width="100" alt="Jaack" />
---
0x45cc2088e22fa1196d1fbfdbe3e539c76dc0bf22