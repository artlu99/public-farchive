username: makemake
fid: 17793
display name: makemake 
PFP: [https://i.imgur.com/hqNITBz.jpg](https://i.imgur.com/hqNITBz.jpg)
bio: Im 19, and I like it when people put blocks in a chain and turn that into a database. Love building useful programs and anything infra. https://makemake.site/

<img src="https://i.imgur.com/hqNITBz.jpg" height="100" width="100" alt="makemake " />
