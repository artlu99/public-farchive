username: mantej.eth
fid: 3306
display name: Mantej Rajpal
PFP: [https://i.imgur.com/9yTrj19.jpg](https://i.imgur.com/9yTrj19.jpg)
bio: security engineer at cash app / cat daddy 🐈 🐈‍⬛ interested in cryptography and technology

<img src="https://i.imgur.com/9yTrj19.jpg" height="100" width="100" alt="Mantej Rajpal" />
---
0x3c9d92a145b17b7df69d22eff292499b2849ee83