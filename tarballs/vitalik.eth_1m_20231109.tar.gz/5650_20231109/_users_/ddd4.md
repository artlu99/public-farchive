username: ddd4
fid: 758
display name: DDD4
PFP: [https://lh3.googleusercontent.com/MWP8EcGVhfG26vG-WjOjy4VwXZwmVPOuZNQ2xBSXrVzwFcLzHR-AkxN2ASz3tv8qLjyP-yePannB6Xrlj7fML7p6fO7wY2hNyvaM5Q](https://lh3.googleusercontent.com/MWP8EcGVhfG26vG-WjOjy4VwXZwmVPOuZNQ2xBSXrVzwFcLzHR-AkxN2ASz3tv8qLjyP-yePannB6Xrlj7fML7p6fO7wY2hNyvaM5Q)
bio: https://gallery.so/DDD4
/ Deep Digital Disruption /
/ Midas Flipping /
/ On & Off Line /
Design ~ Art ///
🕳

<img src="https://lh3.googleusercontent.com/MWP8EcGVhfG26vG-WjOjy4VwXZwmVPOuZNQ2xBSXrVzwFcLzHR-AkxN2ASz3tv8qLjyP-yePannB6Xrlj7fML7p6fO7wY2hNyvaM5Q" height="100" width="100" alt="DDD4" />
---
0x7e59dde2ee81595574ddd55c98300b81467a3618