username: yoru
fid: 16279
display name: Yoru
PFP: [https://i.imgur.com/GJ5aTt6.jpg](https://i.imgur.com/GJ5aTt6.jpg)
bio: 

<img src="https://i.imgur.com/GJ5aTt6.jpg" height="100" width="100" alt="Yoru" />
---
0xf42c2b956bcab51abb6555f5a06ee582e4581c71