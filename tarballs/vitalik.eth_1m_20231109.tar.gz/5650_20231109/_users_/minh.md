username: minh
fid: 999
display name: Minh Do
PFP: [https://i.seadn.io/gae/FXi4v168UT2zJoW-LPiXskuK3sgBj8I1U-a0HSgAKfRui8zoKa1HJE9lAtz6LR7vzxdK_ZZ_oybijNBty7syFTdZUXEeJ2-94voOlA?w=500&auto=format](https://i.seadn.io/gae/FXi4v168UT2zJoW-LPiXskuK3sgBj8I1U-a0HSgAKfRui8zoKa1HJE9lAtz6LR7vzxdK_ZZ_oybijNBty7syFTdZUXEeJ2-94voOlA?w=500&auto=format)
bio: Product strategy, Tech, Marketing, Content, and Building for ourselves and clients at Fantastic Day: Interactive Innovation Studio

https://fantastic.day

<img src="https://i.seadn.io/gae/FXi4v168UT2zJoW-LPiXskuK3sgBj8I1U-a0HSgAKfRui8zoKa1HJE9lAtz6LR7vzxdK_ZZ_oybijNBty7syFTdZUXEeJ2-94voOlA?w=500&auto=format" height="100" width="100" alt="Minh Do" />
---
0x80c008a7c9ec056158cb1f64024e710c8398048a