username: polkdot
fid: 24106
display name: Giang26
PFP: [https://i.imgur.com/EPX9qWD.png](https://i.imgur.com/EPX9qWD.png)
bio: ETH-L2

<img src="https://i.imgur.com/EPX9qWD.png" height="100" width="100" alt="Giang26" />
---
0xd9701bf62e33dc2aa68b3a30c87401b62589ea53