username: squirtle0x.eth
fid: 4022
display name: Squirtle0x
PFP: [https://i.imgur.com/O7W7iUL.jpg](https://i.imgur.com/O7W7iUL.jpg)
bio: Frontend Developer | Web3 builder | NFT collector | DeFi believer | Glass always half full | Staker | OtherPageHQ | BoredMediaGroup

<img src="https://i.imgur.com/O7W7iUL.jpg" height="100" width="100" alt="Squirtle0x" />
---
0x4644a9afe25b01405b9099c32fbf123f919d4838