username: fang
fid: 189088
display name: FanG
PFP: [https://i.seadn.io/s/raw/files/242d03504d0b03bdf37e6a5d816ef247.png?w=500&auto=format](https://i.seadn.io/s/raw/files/242d03504d0b03bdf37e6a5d816ef247.png?w=500&auto=format)
bio: A longtime holder in crypto since 2019. Mathematician with a fondness for puppies.
Ambassador $AIDOGE
#AI + #DOGE = #AIDOGE

<img src="https://i.seadn.io/s/raw/files/242d03504d0b03bdf37e6a5d816ef247.png?w=500&auto=format" height="100" width="100" alt="FanG" />
---
0x68a192d77befce9cfd7f494a12d7685b47b15a35