username: vanthuc
fid: 192959
display name: Ho Van thuc
PFP: [https://i.imgur.com/ZldjjrJ.jpg](https://i.imgur.com/ZldjjrJ.jpg)
bio: Crypto investor and forex trader.

<img src="https://i.imgur.com/ZldjjrJ.jpg" height="100" width="100" alt="Ho Van thuc" />
---
0x2b6b70858da4717ef297d2393f9918f28a70ff94