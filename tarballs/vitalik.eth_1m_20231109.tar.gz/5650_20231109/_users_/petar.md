username: petar
fid: 11213
display name: petar.base
PFP: [https://i.imgur.com/MaXqYjG.jpg](https://i.imgur.com/MaXqYjG.jpg)
bio: Social Media @ambirewallet • Web3 Explorer Newsletter petar.substack.com

<img src="https://i.imgur.com/MaXqYjG.jpg" height="100" width="100" alt="petar.base" />
---
0xb520930bf5529bdf6d42d76cd6f820145ba3ab6b