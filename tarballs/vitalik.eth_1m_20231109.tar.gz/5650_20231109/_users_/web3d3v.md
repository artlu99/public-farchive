username: web3d3v
fid: 9148
display name: web3d3v | sonsOfCrypto.com
PFP: [https://i.imgur.com/aCozBOX.jpg](https://i.imgur.com/aCozBOX.jpg)
bio: CTO sonsofcrypto.com 👨‍💻
- buidling revolutionary #web3wallet 🪙 
- embodiment of #crypto ideals 
- yield #ETH

Host linktr.ee/web3trenchespodcast

<img src="https://i.imgur.com/aCozBOX.jpg" height="100" width="100" alt="web3d3v | sonsOfCrypto.com" />
---
0xe6c97606be089a0455ef944b49588596f62136d3