username: richman
fid: 189184
display name: NGUYỄN VĂN MINH
PFP: [https://i.imgur.com/MaOXQEz.jpg](https://i.imgur.com/MaOXQEz.jpg)
bio: passion trading and crypto

<img src="https://i.imgur.com/MaOXQEz.jpg" height="100" width="100" alt="NGUYỄN VĂN MINH" />
