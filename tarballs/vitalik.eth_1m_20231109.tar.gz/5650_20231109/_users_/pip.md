username: pip
fid: 191593
display name: 60r9
PFP: [https://i.imgur.com/gA7ms36.jpg](https://i.imgur.com/gA7ms36.jpg)
bio: x.com/60r90

<img src="https://i.imgur.com/gA7ms36.jpg" height="100" width="100" alt="60r9" />
---
0xae4705dc0816ee6d8a13f1c72780ec5021915fed