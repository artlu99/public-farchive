username: vova
fid: 4370
display name: Vova
PFP: [https://lh3.googleusercontent.com/7lLUgsSMWE2sAtjMr0KjKdkwhurl35qXlq6U2pQ3NJtpy4XSZkQaxRXoqA2hN2TfNybl7lVfpFxNxaUXOlUmShVJrZS3ktuX6FJp0w](https://lh3.googleusercontent.com/7lLUgsSMWE2sAtjMr0KjKdkwhurl35qXlq6U2pQ3NJtpy4XSZkQaxRXoqA2hN2TfNybl7lVfpFxNxaUXOlUmShVJrZS3ktuX6FJp0w)
bio: Content at Zerion.io

<img src="https://lh3.googleusercontent.com/7lLUgsSMWE2sAtjMr0KjKdkwhurl35qXlq6U2pQ3NJtpy4XSZkQaxRXoqA2hN2TfNybl7lVfpFxNxaUXOlUmShVJrZS3ktuX6FJp0w" height="100" width="100" alt="Vova" />
---
0x977f3a4d006570943eea8c3ae23ea85982dfd95c