username: akira
fid: 11816
display name: Akira
PFP: [https://i.imgur.com/ExaHtnb.jpg](https://i.imgur.com/ExaHtnb.jpg)
bio: Working to make payments fast, cheap and private 

All casts are my own.

<img src="https://i.imgur.com/ExaHtnb.jpg" height="100" width="100" alt="Akira" />
