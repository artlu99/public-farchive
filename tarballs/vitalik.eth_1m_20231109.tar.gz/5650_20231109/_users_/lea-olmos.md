username: lea-olmos
fid: 10799
display name: LEA
PFP: [https://i.imgur.com/nfh2v3w.jpg](https://i.imgur.com/nfh2v3w.jpg)
bio: Fashion Designer & Japanese language student. WEB3 worker.

<img src="https://i.imgur.com/nfh2v3w.jpg" height="100" width="100" alt="LEA" />
---
0xf760e6b91f0d4430533acf0232f904ef3074ac2c