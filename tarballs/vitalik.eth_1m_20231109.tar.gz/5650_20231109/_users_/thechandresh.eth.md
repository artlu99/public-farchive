username: thechandresh.eth
fid: 4434
display name: chandresh 🪴 — q/dau
PFP: [https://i.imgur.com/ZA99OUh.jpg](https://i.imgur.com/ZA99OUh.jpg)
bio: f1, plants, colours, open spaces; building @shardeum @localpublic / chandresh.xyz

<img src="https://i.imgur.com/ZA99OUh.jpg" height="100" width="100" alt="chandresh 🪴 — q/dau" />
---
0xeada1e5b9f65cf52e61b304290d8f737117c6789
0x61da82d341141dbafc8b536eedb23e7d83496c7c