username: phil
fid: 129
display name: phil
PFP: [https://i.imgur.com/sx6qqM7.jpg](https://i.imgur.com/sx6qqM7.jpg)
bio: Building @brightmoments - an IRL NFT gallery DAO. https://brightmoments.io | @purple #15

<img src="https://i.imgur.com/sx6qqM7.jpg" height="100" width="100" alt="phil" />
---
0x18b7511938fbe2ee08adf3d4a24edb00a5c9b783
0x925afeb19355e289ed1346ede709633ca8788b25