username: jenna
fid: 4698
display name: ȷď𝐛𝐛🌳
PFP: [https://i.seadn.io/gae/gGMb9VRmeQXvHehApvMymBYVz99JDtUkJNgfUaKH12bslu4vNtPoVGg1i1fnAmjJe3pHQENIjZaMC8caBWvP17B99DUaAwyRMnh0?w=500&auto=format](https://i.seadn.io/gae/gGMb9VRmeQXvHehApvMymBYVz99JDtUkJNgfUaKH12bslu4vNtPoVGg1i1fnAmjJe3pHQENIjZaMC8caBWvP17B99DUaAwyRMnh0?w=500&auto=format)
bio: 🔎 scouting near and far 🔭

<img src="https://i.seadn.io/gae/gGMb9VRmeQXvHehApvMymBYVz99JDtUkJNgfUaKH12bslu4vNtPoVGg1i1fnAmjJe3pHQENIjZaMC8caBWvP17B99DUaAwyRMnh0?w=500&auto=format" height="100" width="100" alt="ȷď𝐛𝐛🌳" />
---
0xea1bf2a0b45ed328a52a4aa3744669f6ae525866