username: drinkbeerkillwar.eth
fid: 5253
display name: Kelly McCoy
PFP: [https://openseauserdata.com/files/6d9daa1237381c1bc89a1edd0c6e5b65.svg](https://openseauserdata.com/files/6d9daa1237381c1bc89a1edd0c6e5b65.svg)
bio: Revolutionizing the way we tell, share, and discover stories. US Army Veteran. Founder of HippoCanon. Husband and Dad. Regen. MT by way of marriage| nf.td/dbkw 

<img src="https://openseauserdata.com/files/6d9daa1237381c1bc89a1edd0c6e5b65.svg" height="100" width="100" alt="Kelly McCoy" />
---
0xdd1256d5c133f21be2a7c981fc83c8cb0f66e286