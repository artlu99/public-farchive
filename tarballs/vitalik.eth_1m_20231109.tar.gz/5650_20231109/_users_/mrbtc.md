username: mrbtc
fid: 19313
display name: Hamed
PFP: [https://i.imgur.com/C4gPMXJ.jpg](https://i.imgur.com/C4gPMXJ.jpg)
bio: A boy who love crypto

<img src="https://i.imgur.com/C4gPMXJ.jpg" height="100" width="100" alt="Hamed" />
---
0xa2dea8142aece195210b112f2301324adc8dca18