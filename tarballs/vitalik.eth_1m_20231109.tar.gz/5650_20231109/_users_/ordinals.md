username: ordinals
fid: 22117
display name: ordinals
PFP: [https://i.imgur.com/cJPyyY8.jpg](https://i.imgur.com/cJPyyY8.jpg)
bio: ＃BTC #Bitcoin #Ordinals #BitVM

<img src="https://i.imgur.com/cJPyyY8.jpg" height="100" width="100" alt="ordinals" />
---
0x9700ac67fd35ecb5e1c9d78e20099c5893051679