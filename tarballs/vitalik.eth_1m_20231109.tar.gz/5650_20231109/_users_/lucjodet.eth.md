username: lucjodet.eth
fid: 8711
display name: LucJodet.eth
PFP: [https://i.imgur.com/ABFG5NH.png](https://i.imgur.com/ABFG5NH.png)
bio: 💸 Investing @ XAnge.vc

🏗️ Co-founder @ Arianee and @ NFTFactory

<img src="https://i.imgur.com/ABFG5NH.png" height="100" width="100" alt="LucJodet.eth" />
---
0xfcfdf5cf7573cb8467a5d371419b024005bc70b2
0x14210914d6a65fa2c7747579a7aa287b027fd092