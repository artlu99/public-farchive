username: giu
fid: 124
display name: Giuliano Giacaglia
PFP: [https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://lh3.googleusercontent.com/5IBmao06AhDg3PqXjNi1vm6D-HXDGXtkK8qk9vASUqGuJ4AHo2_p23QmyREZJjfzD9MzzAaHSOE2MWGIAwXGZjYnmTwvaDyz57As](https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://lh3.googleusercontent.com/5IBmao06AhDg3PqXjNi1vm6D-HXDGXtkK8qk9vASUqGuJ4AHo2_p23QmyREZJjfzD9MzzAaHSOE2MWGIAwXGZjYnmTwvaDyz57As)
bio: 🇧🇷🇺🇸-  Book: Making Things Think: https://holloway.com/mtt. Investor in Wander, Ocho, Footprint, Merkle Manufactory, Dynamic, Yuzu Health, and more!

<img src="https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://lh3.googleusercontent.com/5IBmao06AhDg3PqXjNi1vm6D-HXDGXtkK8qk9vASUqGuJ4AHo2_p23QmyREZJjfzD9MzzAaHSOE2MWGIAwXGZjYnmTwvaDyz57As" height="100" width="100" alt="Giuliano Giacaglia" />
---
0xe7b25a8ab435c4f8a0d056edda7ba450a9999285