username: vercelabloh
fid: 324
display name: ST
PFP: [https://lh3.googleusercontent.com/u973wiOqX-VKywaSfvc0i_4NTeCvCtjSTsWFmAzzLmuziAuA0NlHWtf2JvAAm5MPlw5lcLjd4DI0LJzFw4FT0RsW7nG-aFEsestqIrw](https://lh3.googleusercontent.com/u973wiOqX-VKywaSfvc0i_4NTeCvCtjSTsWFmAzzLmuziAuA0NlHWtf2JvAAm5MPlw5lcLjd4DI0LJzFw4FT0RsW7nG-aFEsestqIrw)
bio: Front toward enemy. https://flink.fyi/seyitaylor

<img src="https://lh3.googleusercontent.com/u973wiOqX-VKywaSfvc0i_4NTeCvCtjSTsWFmAzzLmuziAuA0NlHWtf2JvAAm5MPlw5lcLjd4DI0LJzFw4FT0RsW7nG-aFEsestqIrw" height="100" width="100" alt="ST" />
---
0x744c28e52dbe6af8e68937d006323ee2b514ad4a