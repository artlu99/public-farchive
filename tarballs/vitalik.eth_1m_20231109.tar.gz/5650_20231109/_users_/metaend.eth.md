username: metaend.eth
fid: 17940
display name: 0𝕏ngmi
PFP: [https://i.seadn.io/s/raw/files/d964338c704fe7cd5918e934985254ec.png?w=500&auto=format](https://i.seadn.io/s/raw/files/d964338c704fe7cd5918e934985254ec.png?w=500&auto=format)
bio: Hi, follow me here https://nf.td/metaend

<img src="https://i.seadn.io/s/raw/files/d964338c704fe7cd5918e934985254ec.png?w=500&auto=format" height="100" width="100" alt="0𝕏ngmi" />
---
0xac1c4bed1c7c71fd3afde11e2bd4f18d969c843d