username: polynya
fid: 11188
display name: polynya
PFP: [https://i.imgur.com/7vUGwdo.png](https://i.imgur.com/7vUGwdo.png)
bio: Blog: https://polynya.mirror.xyz/

<img src="https://i.imgur.com/7vUGwdo.png" height="100" width="100" alt="polynya" />
---
0x429f9ada43e9f345cbb85ec88681bb70df808892