username: 0xdesigner.eth
fid: 1317
display name: 0xdesigner
PFP: [https://i.imgur.com/nRmGlYb.png](https://i.imgur.com/nRmGlYb.png)
bio: a new web3 design concept every day designeverydays.com

<img src="https://i.imgur.com/nRmGlYb.png" height="100" width="100" alt="0xdesigner" />
---
0x12cc729472c036b8d47882024077f61aa463d85b
0xabb485fdc925dc375b5d095a30fcae7f136fd007