username: billyshipp
fid: 19531
display name: billyTRILLions
PFP: [https://i.imgur.com/TlBX2ri.jpg](https://i.imgur.com/TlBX2ri.jpg)
bio: Standing on the shoulders of giants. Optimizing for signal

<img src="https://i.imgur.com/TlBX2ri.jpg" height="100" width="100" alt="billyTRILLions" />
---
0x2f5926896bc7f9432392099bbc66526cea300077