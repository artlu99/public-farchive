username: syed
fid: 1236
display name: Syed Shah 🏴‍☠️🌊
PFP: [https://i.imgur.com/miOebWM.gif](https://i.imgur.com/miOebWM.gif)
bio: 🏴‍☠️🌊 Bring me that Horizon 🍹 Nf.td/syed

<img src="https://i.imgur.com/miOebWM.gif" height="100" width="100" alt="Syed Shah 🏴‍☠️🌊" />
---
0xc3048079040c993818021e955b62102094cd4d03