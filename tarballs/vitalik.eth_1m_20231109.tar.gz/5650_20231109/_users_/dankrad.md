username: dankrad
fid: 7318
display name: Dankrad Feist
PFP: [https://i.imgur.com/Ihzz2m2.jpg](https://i.imgur.com/Ihzz2m2.jpg)
bio: Ethereum Researcher

<img src="https://i.imgur.com/Ihzz2m2.jpg" height="100" width="100" alt="Dankrad Feist" />
---
0x634c474a393e4498bc2f0c1dee16a50e9e0ebe2b