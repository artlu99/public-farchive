username: madhur
fid: 702
display name: Madhur Shrimal
PFP: [https://lh3.googleusercontent.com/s1m52bWTmLmw3lek72HPbbn5TtrLKdz6TPPPVi-x4L6iaiuD5bGsyyf77LIRrHRcqtBLbNzk3cYeNQkzC2cpOS-4neeKVIifDltj](https://lh3.googleusercontent.com/s1m52bWTmLmw3lek72HPbbn5TtrLKdz6TPPPVi-x4L6iaiuD5bGsyyf77LIRrHRcqtBLbNzk3cYeNQkzC2cpOS-4neeKVIifDltj)
bio: Engineer at EigenLayer, ex-Coinbase

<img src="https://lh3.googleusercontent.com/s1m52bWTmLmw3lek72HPbbn5TtrLKdz6TPPPVi-x4L6iaiuD5bGsyyf77LIRrHRcqtBLbNzk3cYeNQkzC2cpOS-4neeKVIifDltj" height="100" width="100" alt="Madhur Shrimal" />
---
0x9e366e32b067a15a359c2c63f961ac8405cb8e2f