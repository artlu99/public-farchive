username: ace
fid: 539
display name: Alex Kwon
PFP: [https://i.imgur.com/Km79vgl.jpg](https://i.imgur.com/Km79vgl.jpg)
bio: building^∞ • lounge (acq.) • south park commons • pollenround.com

<img src="https://i.imgur.com/Km79vgl.jpg" height="100" width="100" alt="Alex Kwon" />
---
0xe0f35f554937d21ddb9e0f83b1436053e33634b9