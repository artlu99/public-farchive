username: smokey-pete
fid: 190120
display name: Macademe
PFP: [https://i.imgur.com/RuL1tT6.jpg](https://i.imgur.com/RuL1tT6.jpg)
bio: Intellectual larper

<img src="https://i.imgur.com/RuL1tT6.jpg" height="100" width="100" alt="Macademe" />
