username: ciefa.eth
fid: 190968
display name: ciefa.eth
PFP: [https://i.imgur.com/n90D0dL.png](https://i.imgur.com/n90D0dL.png)
bio: Co-founder @ Chaineducation Labs // 

Council @ Nova DAO // 

Team @ DeFi Girls NFT // 

ciefa.eth & ciefa.btc // 

#LeXpunK

<img src="https://i.imgur.com/n90D0dL.png" height="100" width="100" alt="ciefa.eth" />
---
0xe06ce2ca5418f0763e9091f5bb348707a1b65bde