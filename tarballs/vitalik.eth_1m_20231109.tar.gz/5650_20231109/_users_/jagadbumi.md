username: jagadbumi
fid: 191277
display name: Jagad Bumi
PFP: [https://i.imgur.com/zlwWIQN.jpg](https://i.imgur.com/zlwWIQN.jpg)
bio: Much effort, much prosperity ~Euripides

<img src="https://i.imgur.com/zlwWIQN.jpg" height="100" width="100" alt="Jagad Bumi" />
---
0x97300791462d8acc2b7882726c2dcafe67a84e2d