username: eduassorted
fid: 193905
display name: Misterbull.beam.eco
PFP: [https://i.imgur.com/SVQi9C9.jpg](https://i.imgur.com/SVQi9C9.jpg)
bio: I am a Blockchain enthusiast and a lover of web3.
A CM and BD agent 🌴

<img src="https://i.imgur.com/SVQi9C9.jpg" height="100" width="100" alt="Misterbull.beam.eco" />
---
0xef0093c6c57018f781509b3efabb9902dbea30b8