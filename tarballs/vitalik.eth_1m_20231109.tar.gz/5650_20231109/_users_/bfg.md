username: bfg
fid: 11244
display name: BrightFutureGuy
PFP: [https://i.imgur.com/p8EqaSm.jpg](https://i.imgur.com/p8EqaSm.jpg)
bio: collector, amateur artist, blockchain use-cases promoter (🎙️ host), built 12 companies, BizDev & PM most of my life, slowly relocating to Web3

<img src="https://i.imgur.com/p8EqaSm.jpg" height="100" width="100" alt="BrightFutureGuy" />
---
0x9addd91874b08f6856bf6b4a2263665d2bc0d933