username: kuririn
fid: 7123
display name: Kuririn
PFP: [https://i.imgur.com/SnoWwgU.jpg](https://i.imgur.com/SnoWwgU.jpg)
bio: I’m a builder looking for the next challenge. 

<img src="https://i.imgur.com/SnoWwgU.jpg" height="100" width="100" alt="Kuririn" />
---
0x9538fd48f3c658cbd625c6fcb462926ced08e7a5