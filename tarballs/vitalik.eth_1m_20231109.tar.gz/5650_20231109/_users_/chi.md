username: chi
fid: 12335
display name: Brais.eth (🥝)
PFP: [https://i.seadn.io/gcs/files/9163cb16f0c8d1482f600edf8a457a31.jpg?w=500&auto=format](https://i.seadn.io/gcs/files/9163cb16f0c8d1482f600edf8a457a31.jpg?w=500&auto=format)
bio: Innovation in Criptan.
Background in Analytics, Consultancy, Operations and Payments

<img src="https://i.seadn.io/gcs/files/9163cb16f0c8d1482f600edf8a457a31.jpg?w=500&auto=format" height="100" width="100" alt="Brais.eth (🥝)" />
---
0x380604e85e772f51014636aa72b107f163609dde