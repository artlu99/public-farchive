username: dih
fid: 20806
display name: Donh
PFP: [https://i.imgur.com/ebmWWYP.jpg](https://i.imgur.com/ebmWWYP.jpg)
bio: ATx, Web 3 Degen since 2016 , took the Red and Blue pill 💊

<img src="https://i.imgur.com/ebmWWYP.jpg" height="100" width="100" alt="Donh" />
---
0xdcc8f181295cfcd9ce83f8be87cb16902c2e1aef