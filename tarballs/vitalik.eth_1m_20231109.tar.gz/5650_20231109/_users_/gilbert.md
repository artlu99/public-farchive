username: gilbert
fid: 11781
display name: Gilbert Again
PFP: [https://i.imgur.com/AVpguGB.jpg](https://i.imgur.com/AVpguGB.jpg)
bio: Head of Derivatives, AKA GBT-2 GHOST-writer. Transtextual graphic design commentator. CEO, Netmorf.

<img src="https://i.imgur.com/AVpguGB.jpg" height="100" width="100" alt="Gilbert Again" />
---
0x6e31d9d4ed8ed93c2871ffb320f68b3cb4e81a25