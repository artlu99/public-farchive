username: cate
fid: 10931
display name: Cate
PFP: [https://i.imgur.com/e5A6NGS.jpg](https://i.imgur.com/e5A6NGS.jpg)
bio: Blockchain Lead Engineer - Building the future for Economy of Things | ETHLisbon Team

<img src="https://i.imgur.com/e5A6NGS.jpg" height="100" width="100" alt="Cate" />
---
0x2205e881cfce328e8976ea0baea459eb6be241cb