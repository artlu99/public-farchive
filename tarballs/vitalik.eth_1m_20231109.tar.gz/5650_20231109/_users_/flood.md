username: flood
fid: 8353
display name: Francesco 🌊
PFP: [https://i.imgur.com/874PUvZ.jpg](https://i.imgur.com/874PUvZ.jpg)
bio: Chief Liquidity Officer @ Flood
prev at UMA

<img src="https://i.imgur.com/874PUvZ.jpg" height="100" width="100" alt="Francesco 🌊" />
