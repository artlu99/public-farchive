username: ashira
fid: 6112
display name: Ashira
PFP: [https://i.imgur.com/WsQghWB.jpg](https://i.imgur.com/WsQghWB.jpg)
bio: Experimental Artist • Color/Texture Maximalist • Fiber Based Collage • Scanography • Crypto late ‘17 + NFTs early ‘21 • Past @RobotosNFT & @ToyBoogers • Ze/She

<img src="https://i.imgur.com/WsQghWB.jpg" height="100" width="100" alt="Ashira" />
---
0x5faa31ea9a79a8e4fa391de7cae5adc9b4b02833