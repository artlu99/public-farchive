username: fishbiscuit
fid: 3615
display name: notqz
PFP: [https://lh3.googleusercontent.com/O_DaOISrzHF62N8QcwUIuJ-w0GwpW09ODzZtD5V9iEVGb3JZEF3f8tqmdf9J6N2rdRvXOu4O9mqU6_TiWMErEkWQHBsPOlWzUwnNCI4](https://lh3.googleusercontent.com/O_DaOISrzHF62N8QcwUIuJ-w0GwpW09ODzZtD5V9iEVGb3JZEF3f8tqmdf9J6N2rdRvXOu4O9mqU6_TiWMErEkWQHBsPOlWzUwnNCI4)
bio: Neither fish nor biscuit. I dont think I have to be who I am on Twitter here and I love it

<img src="https://lh3.googleusercontent.com/O_DaOISrzHF62N8QcwUIuJ-w0GwpW09ODzZtD5V9iEVGb3JZEF3f8tqmdf9J6N2rdRvXOu4O9mqU6_TiWMErEkWQHBsPOlWzUwnNCI4" height="100" width="100" alt="notqz" />
---
0x0cf30daf2fb962ed1d5d19c97f5f6651f3b691c1