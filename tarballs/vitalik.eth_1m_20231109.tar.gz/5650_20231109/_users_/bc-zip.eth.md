username: bc-zip.eth
fid: 14127
display name: 老娘舅 BC
PFP: [https://i.imgur.com/rEndCJs.jpg](https://i.imgur.com/rEndCJs.jpg)
bio: 最重要的東西是看不見、卻一直在身旁的 ● https://bcooney.info/

<img src="https://i.imgur.com/rEndCJs.jpg" height="100" width="100" alt="老娘舅 BC" />
---
0xd4c1f5f3d12373dcd9fd52dea6aba0d8461a3245