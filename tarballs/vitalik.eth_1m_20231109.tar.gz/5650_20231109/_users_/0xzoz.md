username: 0xzoz
fid: 1918
PFP: [https://i.imgur.com/t0HMNTm.jpg](https://i.imgur.com/t0HMNTm.jpg)
bio: zoz: A new slang term for "lol". More of a sarcastic way to say something isn't funny. 

@w3sc | https://github.com/0xZOZ

<img src="https://i.imgur.com/t0HMNTm.jpg" height="100" width="100" alt="0xzoz" />
