username: scav
fid: 3007
display name: Mattie Fairchild
PFP: [https://i.imgur.com/p6BZM7r.jpg](https://i.imgur.com/p6BZM7r.jpg)
bio: Head of DevRel at OP Labs (Optimism). Metaverse builder, esports expat, Boys Club core team member, and usually under attack by tiny leopards.

<img src="https://i.imgur.com/p6BZM7r.jpg" height="100" width="100" alt="Mattie Fairchild" />
---
0x30ac121ab722b8fdad82e6449e4d2a1dc08c280b