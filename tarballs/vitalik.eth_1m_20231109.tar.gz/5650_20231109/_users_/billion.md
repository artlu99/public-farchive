username: billion
fid: 12054
display name: Billion
PFP: [https://i.imgur.com/O1rIJMg.jpg](https://i.imgur.com/O1rIJMg.jpg)
bio: Now remember kids... Internet is $erious business 🫡

<img src="https://i.imgur.com/O1rIJMg.jpg" height="100" width="100" alt="Billion" />
---
0xd819c62dde216ef3b508d348542b59477efd606f