username: xoy
fid: 18169
display name: Amir
PFP: [https://i.imgur.com/cRRTYEt.jpg](https://i.imgur.com/cRRTYEt.jpg)
bio: A human from Earth

<img src="https://i.imgur.com/cRRTYEt.jpg" height="100" width="100" alt="Amir" />
