username: humpty
fid: 2480
display name: humpty ✨🪂
PFP: [https://i.imgur.com/PstVkPm.jpg](https://i.imgur.com/PstVkPm.jpg)
bio: Building @mosaic | Prev. Orange Protocol | Producer cryptosapiens.xyz

<img src="https://i.imgur.com/PstVkPm.jpg" height="100" width="100" alt="humpty ✨🪂" />
---
0xbe14b9950dc61642a084eab491fa516d8fe557e6