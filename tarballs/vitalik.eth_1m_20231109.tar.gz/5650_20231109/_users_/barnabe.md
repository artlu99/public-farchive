username: barnabe
fid: 5451
display name: Barnabé Monnot
PFP: [https://i.seadn.io/gcs/files/c96d616068088202ad5b3cc5dfadb372.png?w=500&auto=format](https://i.seadn.io/gcs/files/c96d616068088202ad5b3cc5dfadb372.png?w=500&auto=format)
bio: Robust Incentives Group @ Ethereum Foundation

https://tinyurl.com/ethrig

<img src="https://i.seadn.io/gcs/files/c96d616068088202ad5b3cc5dfadb372.png?w=500&auto=format" height="100" width="100" alt="Barnabé Monnot" />
---
0x915aa445720020eb1a59151e831111369b08e118