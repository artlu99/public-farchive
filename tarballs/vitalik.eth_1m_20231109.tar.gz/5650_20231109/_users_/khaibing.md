username: khaibing
fid: 189149
display name: Khai Nguyen
PFP: [https://i.imgur.com/kiaGCFA.jpg](https://i.imgur.com/kiaGCFA.jpg)
bio: Học để bản thân và gia đình hạnh phúc
Follow me and back

<img src="https://i.imgur.com/kiaGCFA.jpg" height="100" width="100" alt="Khai Nguyen" />
---
0x85a8fa966e15486c7532ebf06c5be197c7d24a79