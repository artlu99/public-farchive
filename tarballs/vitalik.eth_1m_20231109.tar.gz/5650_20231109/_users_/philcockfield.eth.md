username: philcockfield.eth
fid: 12567
display name: Phil
PFP: [https://i.seadn.io/gcs/files/3e92955b4b56afa756514e6a29ff55ad.jpg?w=500&auto=format](https://i.seadn.io/gcs/files/3e92955b4b56afa756514e6a29ff55ad.jpg?w=500&auto=format)
bio: 🐵 ← 🙈🙉🙊 → phil.cockfield.net, github.com/philcockfield, db.team →  ƒ( trust over time ) →  ƒ( open/commons ) → sys

<img src="https://i.seadn.io/gcs/files/3e92955b4b56afa756514e6a29ff55ad.jpg?w=500&auto=format" height="100" width="100" alt="Phil" />
---
0x1da44dc5bd3ccad7c9de272a58b5507f5bc251fa