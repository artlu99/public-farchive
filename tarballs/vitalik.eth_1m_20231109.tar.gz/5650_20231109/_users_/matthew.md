username: matthew
fid: 473
display name: Matthew
PFP: [https://openseauserdata.com/files/aa9c90abba9c5400076654477f2c08c9.svg](https://openseauserdata.com/files/aa9c90abba9c5400076654477f2c08c9.svg)
bio: Bringing communities together IRL. Built
@event, citycaster.xyz, and farchat.xyz.

<img src="https://openseauserdata.com/files/aa9c90abba9c5400076654477f2c08c9.svg" height="100" width="100" alt="Matthew" />
---
0x538527f3602acad78596f17b422fcf5613af1409