username: amitt
fid: 119
display name: Amitt Mahajan
PFP: [https://i.imgur.com/Zc3kYBl.png](https://i.imgur.com/Zc3kYBl.png)
bio: ceo, proofofplay.gg; building on-chain games starting with piratenation.game 

twitter.com/amittm

<img src="https://i.imgur.com/Zc3kYBl.png" height="100" width="100" alt="Amitt Mahajan" />
