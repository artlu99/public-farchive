username: atb
fid: 1345
display name: Alex Barry
PFP: [https://i.imgur.com/Hxi5KFd.jpg](https://i.imgur.com/Hxi5KFd.jpg)
bio: Protocols @Messari, ex-goldfinch, coinbase, UBS | SoCal & NYC

<img src="https://i.imgur.com/Hxi5KFd.jpg" height="100" width="100" alt="Alex Barry" />
