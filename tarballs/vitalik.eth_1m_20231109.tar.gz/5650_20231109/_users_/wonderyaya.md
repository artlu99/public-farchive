username: wonderyaya
fid: 11616
display name: WonderYaya
PFP: [https://i.imgur.com/2fVI0Xc.jpg](https://i.imgur.com/2fVI0Xc.jpg)
bio: Curious Learner

<img src="https://i.imgur.com/2fVI0Xc.jpg" height="100" width="100" alt="WonderYaya" />
---
0x852cee924d6ae1e8b9bd26675d714f4eed86f9ea