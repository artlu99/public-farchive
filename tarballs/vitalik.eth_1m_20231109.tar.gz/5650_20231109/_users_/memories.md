username: memories
fid: 189025
display name: Memories
PFP: [https://i.imgur.com/olQGdJH.jpg](https://i.imgur.com/olQGdJH.jpg)
bio: Memories of youth, do you remember?
I will follow you back if you follow me 😋

<img src="https://i.imgur.com/olQGdJH.jpg" height="100" width="100" alt="Memories" />
---
0x4b58d25f4ada08387ea4ba1fc98a5adc94f0ede2