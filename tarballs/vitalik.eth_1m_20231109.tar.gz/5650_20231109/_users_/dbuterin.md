username: dbuterin
fid: 188892
display name: Dima Buterin
PFP: [https://i.imgur.com/NT195pH.jpg](https://i.imgur.com/NT195pH.jpg)
bio: An unbound curious consciousness. a fountain of love, confusion, joy and silliness #Ethereum ♥️🇺🇦

<img src="https://i.imgur.com/NT195pH.jpg" height="100" width="100" alt="Dima Buterin" />
---
0xf013e5f697e84c6831220a21a96556242ee9ad86