username: nintynick.eth
fid: 3558
display name: nintynick 🧢
PFP: [https://openseauserdata.com/files/d4c8aaab780d11d25d45cc5ba958c75b.svg](https://openseauserdata.com/files/d4c8aaab780d11d25d45cc5ba958c75b.svg)
bio: wearing many hats @hatsprotocol. DAO maximalist. world peace is now a programming problem

<img src="https://openseauserdata.com/files/d4c8aaab780d11d25d45cc5ba958c75b.svg" height="100" width="100" alt="nintynick 🧢" />
---
0x516cafd745ec780d20f61c0d71fe258ea765222d