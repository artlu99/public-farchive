username: heavygweit
fid: 20270
display name: erica 
PFP: [https://i.imgur.com/qPAcvz9.jpg](https://i.imgur.com/qPAcvz9.jpg)
bio: web3 product designer @frenreviews 🖊️ occasional coder 👩🏻‍💻 community builder 🫂 permissionless identity 🤖  

<img src="https://i.imgur.com/qPAcvz9.jpg" height="100" width="100" alt="erica " />
---
0x18fc3c60a80ba26a076cf633c239df0e2e80a797