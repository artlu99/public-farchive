username: vassilis
fid: 841
display name: Vassilis
PFP: [https://lh3.googleusercontent.com/ow6CKn5IBsKkPLHecOSp5i9woIr-SEmVnD0JVjHxIclypW21xsqLhR0Nug7lll8_m8Fh0OJl3J_EvCS2IK4hPictqrhucBHmDc3Tals](https://lh3.googleusercontent.com/ow6CKn5IBsKkPLHecOSp5i9woIr-SEmVnD0JVjHxIclypW21xsqLhR0Nug7lll8_m8Fh0OJl3J_EvCS2IK4hPictqrhucBHmDc3Tals)
bio: Enterprise @zksync | Aspiring Generalist | Infovore | Writing at synapsesfest.substack.com

<img src="https://lh3.googleusercontent.com/ow6CKn5IBsKkPLHecOSp5i9woIr-SEmVnD0JVjHxIclypW21xsqLhR0Nug7lll8_m8Fh0OJl3J_EvCS2IK4hPictqrhucBHmDc3Tals" height="100" width="100" alt="Vassilis" />
---
0x85966c1fb6dc2182667e6b78022b03940580c9be