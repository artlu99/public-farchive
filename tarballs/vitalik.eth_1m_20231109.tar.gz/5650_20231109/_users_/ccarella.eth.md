username: ccarella.eth
fid: 472
display name: ccarella
PFP: [https://i.seadn.io/gcs/files/52d2586830c1b218d4586e079a1c5303.gif?w=500&auto=format](https://i.seadn.io/gcs/files/52d2586830c1b218d4586e079a1c5303.gif?w=500&auto=format)
bio: Techno-Optimist. Hyperpunk. Artist. Purple. Energy. Nouns. Product @CharmVerse.

<img src="https://i.seadn.io/gcs/files/52d2586830c1b218d4586e079a1c5303.gif?w=500&auto=format" height="100" width="100" alt="ccarella" />
---
0x3b60e31cfc48a9074cd5bebb26c9eaa77650a43f