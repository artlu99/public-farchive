username: andreolf
fid: 193551
display name: Francesco | andreolf.ethᵍᵐ
PFP: [https://i.imgur.com/H9pCqoF.jpg](https://i.imgur.com/H9pCqoF.jpg)
bio: DevRel @Consensys @MetaMask & Early Stage Investor @ouicapital 🦄 , Ex @digitalassetcom @angelHack, @ETH_en, kite🌊

<img src="https://i.imgur.com/H9pCqoF.jpg" height="100" width="100" alt="Francesco | andreolf.ethᵍᵐ" />
---
0x7020d15dd9ac18dc0701f14ae32ad100efbb8fd6