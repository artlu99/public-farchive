username: teleyinex.eth
fid: 5925
display name: Daniel Lombraña
PFP: [https://i.seadn.io/gcs/files/ec6e0a4285e832a50d74fc90575c96e5.png?w=500&auto=format](https://i.seadn.io/gcs/files/ec6e0a4285e832a50d74fc90575c96e5.png?w=500&auto=format)
bio: 🌷💀⏳

teleyinex.eth ▫️

teleyinex.lens ▫️

teleyine.x ▫️

daniellombrana.es  ▫️

@astaralabs ▫️

@obeygiant ▫️

@scifabric ▫️

dev

<img src="https://i.seadn.io/gcs/files/ec6e0a4285e832a50d74fc90575c96e5.png?w=500&auto=format" height="100" width="100" alt="Daniel Lombraña" />
---
0x12cba59f5a74db81a12ff63c349bd82cbf6007c2