username: hiteam
fid: 15946
display name: Shin
PFP: [https://i.imgur.com/JJ26WGC.jpg](https://i.imgur.com/JJ26WGC.jpg)
bio: In crypto space on and off for 9½ years. Trying to learn a monetizable skill now. Trying to make it.

<img src="https://i.imgur.com/JJ26WGC.jpg" height="100" width="100" alt="Shin" />
---
0xea599877e9acc44c53e7fc5a2ca8de5adca83400