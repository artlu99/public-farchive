username: keccers
fid: 4407
display name: Katherine
PFP: [https://i.seadn.io/gcs/files/1fdded3a19c64c8e69cefcbd061ca953.png?w=500&auto=format](https://i.seadn.io/gcs/files/1fdded3a19c64c8e69cefcbd061ca953.png?w=500&auto=format)
bio: The Farcaster formerly known as Kchamp. Books, beats, bodybuilding, bright ideas and beautiful things.

katherinechampagne.com 

<img src="https://i.seadn.io/gcs/files/1fdded3a19c64c8e69cefcbd061ca953.png?w=500&auto=format" height="100" width="100" alt="Katherine" />
---
0xa2fe1d4145443ebc027f15c9f7ca27f7e9fd5f33