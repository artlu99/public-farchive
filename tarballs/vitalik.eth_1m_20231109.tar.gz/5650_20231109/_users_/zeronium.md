username: zeronium
fid: 23563
display name: Zeronium
PFP: [https://i.imgur.com/p9g5EqB.jpg](https://i.imgur.com/p9g5EqB.jpg)
bio: I'm a little teapot who didn't fill out my bio

<img src="https://i.imgur.com/p9g5EqB.jpg" height="100" width="100" alt="Zeronium" />
---
0x02eb068e6c8cff0013e23d58b3b00b7e68f6959d