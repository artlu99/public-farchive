username: brittkim.eth
fid: 4665
display name: Britt Kim
PFP: [https://i.imgur.com/hPRGO9D.jpg](https://i.imgur.com/hPRGO9D.jpg)
bio: Programmer

<img src="https://i.imgur.com/hPRGO9D.jpg" height="100" width="100" alt="Britt Kim" />
---
0xa01258f7c15ee825fb2dc67db273edc89621268a
0x345ab03602369dd0b443b9b0a5df54db7bff708b