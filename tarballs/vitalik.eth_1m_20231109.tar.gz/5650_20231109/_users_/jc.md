username: jc
fid: 251
display name: jcdenton.cast
PFP: [https://i.imgur.com/VxvEKrw.jpg](https://i.imgur.com/VxvEKrw.jpg)
bio: Building @farquest, wield.co, investing @ miy.com. ex-Meta, ex-Coinbase // cryptojcdenton.twitter

<img src="https://i.imgur.com/VxvEKrw.jpg" height="100" width="100" alt="jcdenton.cast" />
---
0x997b0cced542b6d2a7e0bae5649afd9d0861cb4e