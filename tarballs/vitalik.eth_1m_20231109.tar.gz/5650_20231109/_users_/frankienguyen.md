username: frankienguyen
fid: 188857
display name: Frankie Nguyen
PFP: [https://i.imgur.com/zXc5Usz.jpg](https://i.imgur.com/zXc5Usz.jpg)
bio: Fulltime Crypto & Node Operator!!!

<img src="https://i.imgur.com/zXc5Usz.jpg" height="100" width="100" alt="Frankie Nguyen" />
---
0x3f49ecf4b7b57907d5644a941eb9c5b5be34e86f