username: oxb
fid: 20286
display name: Ox Bid
PFP: [https://i.imgur.com/5lTpsyy.jpg](https://i.imgur.com/5lTpsyy.jpg)
bio: Working on https://bolide.fi and Profiler ✅ 
Having fun https://depigz.tech 🐷
Passionate about simplified user experience 👩‍💻 ➡️oxbid.xyz 

<img src="https://i.imgur.com/5lTpsyy.jpg" height="100" width="100" alt="Ox Bid" />
---
0x93205bff8d090578e14fba9b97bd1505ec030670