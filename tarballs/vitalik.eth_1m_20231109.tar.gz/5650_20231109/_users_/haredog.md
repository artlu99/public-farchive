username: haredog
fid: 190528
display name: Jerry 
PFP: [https://i.imgur.com/7er3Kq2.jpg](https://i.imgur.com/7er3Kq2.jpg)
bio: Retired software developer for a used book company

<img src="https://i.imgur.com/7er3Kq2.jpg" height="100" width="100" alt="Jerry " />
---
0xfb9e5f5874565a6ef8fcf1debc4975501331a8ca