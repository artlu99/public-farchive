username: warrenbuffett
fid: 187741
display name: M. Yiğit Pazarcı
PFP: [https://i.seadn.io/gae/Nc1p8Z_Vygcp2icr99LpemMxl96FW9AWOu3K58Z-DNhAcCxX2-q2Vedl3OmJanyFWhWR_7ZsGOpRvUjw8sY4IfnxtUTGl2PCQKRIjA?w=500&auto=format](https://i.seadn.io/gae/Nc1p8Z_Vygcp2icr99LpemMxl96FW9AWOu3K58Z-DNhAcCxX2-q2Vedl3OmJanyFWhWR_7ZsGOpRvUjw8sY4IfnxtUTGl2PCQKRIjA?w=500&auto=format)
bio: Pharmacist 💊
Trader and Developer 💻

<img src="https://i.seadn.io/gae/Nc1p8Z_Vygcp2icr99LpemMxl96FW9AWOu3K58Z-DNhAcCxX2-q2Vedl3OmJanyFWhWR_7ZsGOpRvUjw8sY4IfnxtUTGl2PCQKRIjA?w=500&auto=format" height="100" width="100" alt="M. Yiğit Pazarcı" />
---
0x58ce8ca80e01543854a07cd9e86ce567272b82f8