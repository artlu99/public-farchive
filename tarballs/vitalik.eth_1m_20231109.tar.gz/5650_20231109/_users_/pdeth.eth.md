username: pdeth.eth
fid: 1379
display name: PD
PFP: [https://i.seadn.io/gcs/files/cea21bbf341f588ad50f9c348b3300e5.png?w=500&auto=format](https://i.seadn.io/gcs/files/cea21bbf341f588ad50f9c348b3300e5.png?w=500&auto=format)
bio: Helping start-ups to reach their potential growth ——— Life Lessons ——— Lord Krishna Quotes

<img src="https://i.seadn.io/gcs/files/cea21bbf341f588ad50f9c348b3300e5.png?w=500&auto=format" height="100" width="100" alt="PD" />
---
0x612ab7bfaf4f3414f071803d8b84b28430ca2e6d
0x9a0b3dcf26b7bc6d9844d6a37b8924cdfaa55a98