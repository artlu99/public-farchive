username: qsteak
fid: 9700
display name: Q
PFP: [https://i.seadn.io/gae/HAjootb773-pMQSOmYzrqph7n8pL_FHF3LG5fpXIwMQg0-dIAvxbM4MNOM4triUMiT_tuq2xxUlq6yEITwQdjOFpvifRas3cTcSoWQ?w=500&auto=format](https://i.seadn.io/gae/HAjootb773-pMQSOmYzrqph7n8pL_FHF3LG5fpXIwMQg0-dIAvxbM4MNOM4triUMiT_tuq2xxUlq6yEITwQdjOFpvifRas3cTcSoWQ?w=500&auto=format)
bio: Just trying to align humanity.

<img src="https://i.seadn.io/gae/HAjootb773-pMQSOmYzrqph7n8pL_FHF3LG5fpXIwMQg0-dIAvxbM4MNOM4triUMiT_tuq2xxUlq6yEITwQdjOFpvifRas3cTcSoWQ?w=500&auto=format" height="100" width="100" alt="Q" />
---
0x82d746d7d53515b22ad058937ee4d139ba09ff07