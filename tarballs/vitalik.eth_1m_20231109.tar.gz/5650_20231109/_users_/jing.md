username: jing
fid: 10765
display name: jing
PFP: [https://i.imgur.com/7pOoQa1.jpg](https://i.imgur.com/7pOoQa1.jpg)
bio: optimism contributor #001

<img src="https://i.imgur.com/7pOoQa1.jpg" height="100" width="100" alt="jing" />
---
0x81687d1cc42355572ef923f93dca88a50e7337f3