username: agcherepovskij.eth
fid: 11861
display name: Anatole
PFP: [https://i.imgur.com/YN5OEb9.gif](https://i.imgur.com/YN5OEb9.gif)
bio: Biochemist doctor 🧪

<img src="https://i.imgur.com/YN5OEb9.gif" height="100" width="100" alt="Anatole" />
---
0xfd4520753366d35e5dc2f76d52dc58a5261ed263