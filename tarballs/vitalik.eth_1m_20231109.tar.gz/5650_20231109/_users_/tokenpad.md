username: tokenpad
fid: 13952
display name: Tokenpad
PFP: [https://i.imgur.com/fMEejd5.jpg](https://i.imgur.com/fMEejd5.jpg)
bio: Helping you become a smarter investor. Track your performance: tokenpad.io

<img src="https://i.imgur.com/fMEejd5.jpg" height="100" width="100" alt="Tokenpad" />
---
0x89b5052d41cde44d7bcdfa0f7ee32f80abee21f5