username: yverta
fid: 193751
display name: Y.
PFP: [https://i.imgur.com/6saqgC2.jpg](https://i.imgur.com/6saqgC2.jpg)
bio: (●'◡'●)

<img src="https://i.imgur.com/6saqgC2.jpg" height="100" width="100" alt="Y." />
