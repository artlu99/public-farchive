username: tarun
fid: 3435
display name: Tarun Sachdeva
PFP: [https://openseauserdata.com/files/0350abacda7fca89fb424c2dacd42879.svg](https://openseauserdata.com/files/0350abacda7fca89fb424c2dacd42879.svg)
bio: Maker of round.space / gitwallet.co / fresco.lol / detour.chat. Always building.

<img src="https://openseauserdata.com/files/0350abacda7fca89fb424c2dacd42879.svg" height="100" width="100" alt="Tarun Sachdeva" />
---
0xb3d1a413968f7133ef644e720f74e216090c51a8