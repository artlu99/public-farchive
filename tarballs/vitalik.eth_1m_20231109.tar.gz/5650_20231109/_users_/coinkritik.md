username: coinkritik
fid: 188189
display name: Coinkritik
PFP: [https://i.imgur.com/5J0B8C4.jpg](https://i.imgur.com/5J0B8C4.jpg)
bio: https://twitter.com/coinkritik

<img src="https://i.imgur.com/5J0B8C4.jpg" height="100" width="100" alt="Coinkritik" />
---
0xf93063f19f893bfaad1d194f635bd467e5c2adfe