username: henrylove
fid: 189365
display name: Henry Love
PFP: [https://i.imgur.com/gThCDbB.jpg](https://i.imgur.com/gThCDbB.jpg)
bio: Building multi-ecosystem things. 

Partner at Fundamental Labs

<img src="https://i.imgur.com/gThCDbB.jpg" height="100" width="100" alt="Henry Love" />
