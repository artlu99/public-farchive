username: audio
fid: 188208
display name: Igor Smailov 
PFP: [https://i.imgur.com/ws2y6Xl.jpg](https://i.imgur.com/ws2y6Xl.jpg)
bio: Crypto enthusiast | Principal Engineer from Kyiv 🇺🇦

Forbes 100 Under 100 (c)
"Live in the future, and build what’s missing"



Founder and CEO

<img src="https://i.imgur.com/ws2y6Xl.jpg" height="100" width="100" alt="Igor Smailov " />
---
0xc25560e513de24d927fd1779fdce848e3d1a9907