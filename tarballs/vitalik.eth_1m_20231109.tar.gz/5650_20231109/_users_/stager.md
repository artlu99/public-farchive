username: stager
fid: 18108
display name: Mohsen
PFP: [https://i.imgur.com/Z7Ad0cr.jpg](https://i.imgur.com/Z7Ad0cr.jpg)
bio: Crypto pupil and NFT lover

<img src="https://i.imgur.com/Z7Ad0cr.jpg" height="100" width="100" alt="Mohsen" />
---
0x347d683494c38204a4ff686630351375446a8dc8