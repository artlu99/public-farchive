username: maxp.eth
fid: 4373
display name: max⚡️
PFP: [https://i.seadn.io/gae/A10YjnNN-BMTphahCFyIGQD7dIZ5O3zYK9SIyQd9UJK-kVz6IGgMj8PNePOoV7KUdJ5nU_Q6ZyUUOQfkwECL3o_a0As9F-j7zE7qHg?w=500&auto=format](https://i.seadn.io/gae/A10YjnNN-BMTphahCFyIGQD7dIZ5O3zYK9SIyQd9UJK-kVz6IGgMj8PNePOoV7KUdJ5nU_Q6ZyUUOQfkwECL3o_a0As9F-j7zE7qHg?w=500&auto=format)
bio: BUILDING: @nilli, @quickcast, nf.td/maxp

<img src="https://i.seadn.io/gae/A10YjnNN-BMTphahCFyIGQD7dIZ5O3zYK9SIyQd9UJK-kVz6IGgMj8PNePOoV7KUdJ5nU_Q6ZyUUOQfkwECL3o_a0As9F-j7zE7qHg?w=500&auto=format" height="100" width="100" alt="max⚡️" />
---
0x0a2f3020d266a54fa8f0f72fd448969f74602222