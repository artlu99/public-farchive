username: px
fid: 4989
display name: pourteaux
PFP: [https://i.seadn.io/gae/ewDuLKfFEhzCELDH5OrDqDDqWPQfPff80JxvMLH5YQM5hZKUGxhz6opSciorbPCQO9SVKuBlZyLIeX1tJTUI0TKu29zKrsuyr9TKIw?w=500&auto=format](https://i.seadn.io/gae/ewDuLKfFEhzCELDH5OrDqDDqWPQfPff80JxvMLH5YQM5hZKUGxhz6opSciorbPCQO9SVKuBlZyLIeX1tJTUI0TKu29zKrsuyr9TKIw?w=500&auto=format)
bio: surgeon, technologist, writer, humanist. read.pourteaux.xyz 

<img src="https://i.seadn.io/gae/ewDuLKfFEhzCELDH5OrDqDDqWPQfPff80JxvMLH5YQM5hZKUGxhz6opSciorbPCQO9SVKuBlZyLIeX1tJTUI0TKu29zKrsuyr9TKIw?w=500&auto=format" height="100" width="100" alt="pourteaux" />
---
0xead28e25ad83ee78f12e4188ae7f8743aa761f7c
0xd22b71a95abff967fb35c380e5d5e0f894ca132b