username: matallo.eth
fid: 626
display name: Carlos Matallín
PFP: [https://live.staticflickr.com/1391/1363306686_bb2d491d1a_o.png](https://live.staticflickr.com/1391/1363306686_bb2d491d1a_o.png)
bio: Explorer. Code, design, and mountains. flink.fyi/matallo.eth Building: pincaster.xyz

<img src="https://live.staticflickr.com/1391/1363306686_bb2d491d1a_o.png" height="100" width="100" alt="Carlos Matallín" />
---
0xcf7eca52de76e72e562adddb513cef4c609f1fd2