username: readondao
fid: 188810
display name: ReadOn
PFP: [https://i.imgur.com/VjtdsVH.jpg](https://i.imgur.com/VjtdsVH.jpg)
bio: ReadON App is a Web3 content aggregator aiming to gather and integrate Web’3 excellent articles to combine with users’ social portraits, push the content that u

<img src="https://i.imgur.com/VjtdsVH.jpg" height="100" width="100" alt="ReadOn" />
---
0x7caa59d048d3f64654914972403ae810e7c05e7b