username: snibb123
fid: 21039
display name: JMoney
PFP: [https://i.imgur.com/j3fnz0e.jpg](https://i.imgur.com/j3fnz0e.jpg)
bio: The Champagne of Friends.

<img src="https://i.imgur.com/j3fnz0e.jpg" height="100" width="100" alt="JMoney" />
