username: meluhian.eth
fid: 6878
display name: Mayank 🗯️
PFP: [https://i.imgur.com/SlGHApP.jpg](https://i.imgur.com/SlGHApP.jpg)
bio: Mech. Design Engg. || Tinkering IOT + Blockchain, Strolling & Exploring the Web3 Verse.


https://linktr.ee/meluhian

<img src="https://i.imgur.com/SlGHApP.jpg" height="100" width="100" alt="Mayank 🗯️" />
---
0xc3902d565bbcb20e6e947b9657df3b0a56875585