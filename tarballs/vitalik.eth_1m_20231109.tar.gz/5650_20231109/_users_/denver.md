username: denver
fid: 18245
display name: Denver
PFP: [https://i.imgur.com/0L9q5U9.jpg](https://i.imgur.com/0L9q5U9.jpg)
bio: I am crypto lover and on-chain researcher my moat is finding potential project and keep aping on a very early stage

<img src="https://i.imgur.com/0L9q5U9.jpg" height="100" width="100" alt="Denver" />
---
0x68aad5a5cfd7f899b90cefb38451463a1ce4f883