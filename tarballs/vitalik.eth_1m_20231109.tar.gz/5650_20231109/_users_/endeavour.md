username: endeavour
fid: 7781
display name: Endeavour
PFP: [https://warpcast.com/avatar.png?t=1697926235287](https://warpcast.com/avatar.png?t=1697926235287)
bio: Ethereum | zkrollups | DeFi | web3

<img src="https://warpcast.com/avatar.png?t=1697926235287" height="100" width="100" alt="Endeavour" />
