username: kyxoan17
fid: 189062
display name: kyxoan17
PFP: [https://i.imgur.com/k2p3qBf.jpg](https://i.imgur.com/k2p3qBf.jpg)
bio: Crypto Researcher | DID | KYC |OG | "Better me is what I'm workin' towards"

<img src="https://i.imgur.com/k2p3qBf.jpg" height="100" width="100" alt="kyxoan17" />
---
0xfa68640b8110cd98671d359492f940cc6957e6e9