username: whatsgood-al
fid: 6945
display name: Alex Arias
PFP: [https://i.imgur.com/alA1u4u.jpg](https://i.imgur.com/alA1u4u.jpg)
bio: Moderator for @yup discord server feel free to join link down below, also I’m a crypto enthusiast, web3 dude, NFT Curator, https://discord.gg/qtjT5ktd

<img src="https://i.imgur.com/alA1u4u.jpg" height="100" width="100" alt="Alex Arias" />
---
0x9cf7036aef81df2c0e48de0bb2e32270ee3283d5