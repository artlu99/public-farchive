username: coopahtroopa
fid: 206
display name: Coop
PFP: [https://i.imgur.com/UT9Q7Fl.jpg](https://i.imgur.com/UT9Q7Fl.jpg)
bio: Onchain in the new online

<img src="https://i.imgur.com/UT9Q7Fl.jpg" height="100" width="100" alt="Coop" />
---
0x5b93ff82faaf241c15997ea3975419dddd8362c5
0x46301f7e700be9cffce3e5e142a2244df3f2d4f2