username: dwiss
fid: 20416
display name: DWISS
PFP: [https://i.imgur.com/GXPnyRP.jpg](https://i.imgur.com/GXPnyRP.jpg)
bio: Funded in 2011, DWISS embodies a legacy of innovation, crafting exquisite watches that have garnered acclaim through numerous prestigious design awards.

<img src="https://i.imgur.com/GXPnyRP.jpg" height="100" width="100" alt="DWISS" />
---
0xfe226bcaf9bb70e41681e614c7f8997c51c7c5b4