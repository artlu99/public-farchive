username: tayyab
fid: 66
display name: Tayyab
PFP: [https://i.imgur.com/oTU7pmn.jpg](https://i.imgur.com/oTU7pmn.jpg)
bio: Chasing Curiosity. Prev. CTO @ Casama. YC S16, KB7. Hacking, pontificating, connecting.
https://nf.td/tayyab

<img src="https://i.imgur.com/oTU7pmn.jpg" height="100" width="100" alt="Tayyab" />
---
0x794cec5ee2659859050d29d858cf46191649e1fa