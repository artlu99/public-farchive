username: nth-order-gideon
fid: 192058
display name: Nth Order Gideon
PFP: [https://i.imgur.com/Q4jKDnj.jpg](https://i.imgur.com/Q4jKDnj.jpg)
bio: Psyops philosopher.  Building societies, razing temples, claiming galaxies.

<img src="https://i.imgur.com/Q4jKDnj.jpg" height="100" width="100" alt="Nth Order Gideon" />
