username: theclash
fid: 18458
display name: theclash ⌐◨-◨
PFP: [https://i.imgur.com/3FywJlR.jpg](https://i.imgur.com/3FywJlR.jpg)
bio: Building at the intersection of web3 and social | social media power user ⛓️ gen-art enjoyer

<img src="https://i.imgur.com/3FywJlR.jpg" height="100" width="100" alt="theclash ⌐◨-◨" />
---
0x98db764d115badcde1a035df94b8118016c53057
0x9471f70f2518846f7a076636d64e5a22787da105