username: violet
fid: 15129
display name: Nazii
PFP: [https://i.imgur.com/CZAnFmU.jpg](https://i.imgur.com/CZAnFmU.jpg)
bio: Live like a tourist, look for the wonders around you..

<img src="https://i.imgur.com/CZAnFmU.jpg" height="100" width="100" alt="Nazii" />
---
0xa3aaa3150281b7608b58139afd3b12a961abcd45