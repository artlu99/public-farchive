username: bd
fid: 17520
display name: bd
PFP: [https://i.imgur.com/tIgtv1C.jpg](https://i.imgur.com/tIgtv1C.jpg)
bio: GM,
Web3  >>>>> Web2

<img src="https://i.imgur.com/tIgtv1C.jpg" height="100" width="100" alt="bd" />
---
0xe1002d17736f398aa28ad8c921930436ed3c158e