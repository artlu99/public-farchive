username: aaina
fid: 2042
display name: Aaina 
PFP: [https://i.seadn.io/gae/fsvfDJy20kVFk87uOISBFmP6dNklzxh1Dg4lJIsg7bhNyYSbL87YzzHvuDYZEoJ8xXovLC-vlUTkC-_j-nrY0SWdAkDt-Vg1wakl1w?w=500&auto=format](https://i.seadn.io/gae/fsvfDJy20kVFk87uOISBFmP6dNklzxh1Dg4lJIsg7bhNyYSbL87YzzHvuDYZEoJ8xXovLC-vlUTkC-_j-nrY0SWdAkDt-Vg1wakl1w?w=500&auto=format)
bio: cypherpunk | human rights lawyer | queen • indivisible.fm • https://nf.td/aaina 

<img src="https://i.seadn.io/gae/fsvfDJy20kVFk87uOISBFmP6dNklzxh1Dg4lJIsg7bhNyYSbL87YzzHvuDYZEoJ8xXovLC-vlUTkC-_j-nrY0SWdAkDt-Vg1wakl1w?w=500&auto=format" height="100" width="100" alt="Aaina " />
---
0xd3d70afe29beced2eb2ac1e407a2007150e2312e