username: nakcrypto
fid: 190153
display name: Nak Crypto
PFP: [https://i.imgur.com/GOYIXmz.jpg](https://i.imgur.com/GOYIXmz.jpg)
bio: I am a crypto man

<img src="https://i.imgur.com/GOYIXmz.jpg" height="100" width="100" alt="Nak Crypto" />
---
0x19dbb0e0fb374a8280fedefc454c490f2528234a