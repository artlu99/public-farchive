username: pugson
fid: 557
display name: pugson
PFP: [https://i.seadn.io/gae/5hjYfRyqiRJV4EQ7ieSJrmb1LtO_vcAvREXSqnlY4HXXBsvgh1vumOwj5e4GwGhppEU2jLC9qJHEgEkaJ9V_B02jIFY9XmzgK1_F?w=500&auto=format](https://i.seadn.io/gae/5hjYfRyqiRJV4EQ7ieSJrmb1LtO_vcAvREXSqnlY4HXXBsvgh1vumOwj5e4GwGhppEU2jLC9qJHEgEkaJ9V_B02jIFY9XmzgK1_F?w=500&auto=format)
bio: ✦ 𝚆𝙸𝙿: @vision 👁️ ✦ ensdata.net ✦ abidata.net ✦ 𝙿𝚁𝙴𝚅: ui engineer @ rainbow  🌈  ✦ pug.eth

<img src="https://i.seadn.io/gae/5hjYfRyqiRJV4EQ7ieSJrmb1LtO_vcAvREXSqnlY4HXXBsvgh1vumOwj5e4GwGhppEU2jLC9qJHEgEkaJ9V_B02jIFY9XmzgK1_F?w=500&auto=format" height="100" width="100" alt="pugson" />
---
0x96a77560146501eaeb5e6d5b7d8dd1ed23defa23