username: thinhblock
fid: 188134
display name: Thinh BLock
PFP: [https://i.imgur.com/EvKL2RV.jpg](https://i.imgur.com/EvKL2RV.jpg)
bio: $BASE

<img src="https://i.imgur.com/EvKL2RV.jpg" height="100" width="100" alt="Thinh BLock" />
---
0x0feed474c73310e5ae8ae335b160cc151daaf35c