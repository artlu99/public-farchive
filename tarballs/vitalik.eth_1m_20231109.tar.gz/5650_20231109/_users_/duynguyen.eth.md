username: duynguyen.eth
fid: 21700
display name: Duy Nguyen
PFP: [https://i.imgur.com/T2s8b28.jpg](https://i.imgur.com/T2s8b28.jpg)
bio: Crypto $ETH, $DYDX, $MKR
Software engineer

<img src="https://i.imgur.com/T2s8b28.jpg" height="100" width="100" alt="Duy Nguyen" />
---
0x5bf6681a73a33a076c5569a4e729f41ae20bd901