username: lior
fid: 7589
display name: Lior
PFP: [https://i.imgur.com/lJgoSQq.jpg](https://i.imgur.com/lJgoSQq.jpg)
bio: Building Covariance| D2D hacker | biz dev | Growth | web3 social | Future of Work is here & it's tokenized.

Season 1 application open soon:
Covariance.network

<img src="https://i.imgur.com/lJgoSQq.jpg" height="100" width="100" alt="Lior" />
---
0xd5aefe935dfc9360945115dde8da98b596dfbb9f