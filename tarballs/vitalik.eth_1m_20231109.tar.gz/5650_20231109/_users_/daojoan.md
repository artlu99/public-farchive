username: daojoan
fid: 3305
display name: Joan Westenberg
PFP: [https://i.imgur.com/IXFjfKc.jpg](https://i.imgur.com/IXFjfKc.jpg)
bio: 🍕 I write about tech + humans + economics.

https://www.joanwestenberg.com

<img src="https://i.imgur.com/IXFjfKc.jpg" height="100" width="100" alt="Joan Westenberg" />
---
0xaa451dcc2b100d9bc1d6bd0b482b0904f679a3cf
0x983e39ce1302bf95161335d8afb3091f42c20624