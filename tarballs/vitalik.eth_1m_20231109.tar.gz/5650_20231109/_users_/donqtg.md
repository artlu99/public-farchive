username: donqtg
fid: 23676
display name: DonQTG
PFP: [https://i.imgur.com/0HBRTPN.jpg](https://i.imgur.com/0HBRTPN.jpg)
bio: Dogs, swimming, crypto.

<img src="https://i.imgur.com/0HBRTPN.jpg" height="100" width="100" alt="DonQTG" />
---
0x085da37496d8622a53057f7519addcea3f73cbd4