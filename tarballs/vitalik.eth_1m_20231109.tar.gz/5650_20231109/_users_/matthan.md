username: matthan
fid: 6565
display name: Rahul Matthan
PFP: [https://i.seadn.io/gcs/files/bdb0491ad15651bc9c9f94544ebd5907.jpg?w=500&auto=format](https://i.seadn.io/gcs/files/bdb0491ad15651bc9c9f94544ebd5907.jpg?w=500&auto=format)
bio: Law. Tech Policy. 
nf.td/matthan

<img src="https://i.seadn.io/gcs/files/bdb0491ad15651bc9c9f94544ebd5907.jpg?w=500&auto=format" height="100" width="100" alt="Rahul Matthan" />
---
0xbc0eac584827ec112037ec57e7a35cac1e572d46