username: pbui68
fid: 189076
display name: Phong Bui
PFP: [https://i.seadn.io/s/raw/files/3ccbf492fc88304a75ff10781fcc4daa.gif?w=500&auto=format](https://i.seadn.io/s/raw/files/3ccbf492fc88304a75ff10781fcc4daa.gif?w=500&auto=format)
bio: Cryoto

<img src="https://i.seadn.io/s/raw/files/3ccbf492fc88304a75ff10781fcc4daa.gif?w=500&auto=format" height="100" width="100" alt="Phong Bui" />
---
0x2ce2ccd29f67f5f482b9dd5589eb1201678f99aa