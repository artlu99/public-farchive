username: madrid
fid: 23432
display name: imbitcoin.eth
PFP: [https://i.imgur.com/e6nLDSH.jpg](https://i.imgur.com/e6nLDSH.jpg)
bio: Environmental Engineer, Re-Fi, Blockchain, NFT

<img src="https://i.imgur.com/e6nLDSH.jpg" height="100" width="100" alt="imbitcoin.eth" />
---
0x6e100a3d94ef3c96676ad42f0c28bb2ff99600c0