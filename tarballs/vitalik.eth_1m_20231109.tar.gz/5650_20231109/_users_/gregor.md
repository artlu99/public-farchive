username: gregor
fid: 13166
display name: Gregor
PFP: [https://i.imgur.com/e7v5ghv.jpg](https://i.imgur.com/e7v5ghv.jpg)
bio: Unlicensed doctor & lawyer

<img src="https://i.imgur.com/e7v5ghv.jpg" height="100" width="100" alt="Gregor" />
