username: mints
fid: 755
display name: Jordan
PFP: [https://i.imgur.com/dBaVJoH.jpg](https://i.imgur.com/dBaVJoH.jpg)
bio: Building things in web3 at Atomic

<img src="https://i.imgur.com/dBaVJoH.jpg" height="100" width="100" alt="Jordan" />
---
0x290a90c4f766325ec6b1ef147cfd655f88d329a9