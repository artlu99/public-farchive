username: skeeboo
fid: 189567
display name: Skeeboo
PFP: [https://i.imgur.com/Aq6NWKq.jpg](https://i.imgur.com/Aq6NWKq.jpg)
bio: Melody maker. Crafting instrumental sketches since 2018.

<img src="https://i.imgur.com/Aq6NWKq.jpg" height="100" width="100" alt="Skeeboo" />
---
0x98de8db421c0822393dc9197dca5aba7efae0814