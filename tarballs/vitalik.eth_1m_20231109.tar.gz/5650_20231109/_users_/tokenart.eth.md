username: tokenart.eth
fid: 4905
display name: Max Jackson : mxjxn
PFP: [https://i.seadn.io/gae/PNdgRmOHiLEG8ivbBBa9EJyX70y_uJhBvbfLk52j2UULqV5xJeC7VvI_j6EPkgl7bQY6UXAn9c_MYNgL3quj7IzRc_2ySDDov9Qj?w=500&auto=format](https://i.seadn.io/gae/PNdgRmOHiLEG8ivbBBa9EJyX70y_uJhBvbfLk52j2UULqV5xJeC7VvI_j6EPkgl7bQY6UXAn9c_MYNgL3quj7IzRc_2ySDDov9Qj?w=500&auto=format)
bio: Cryptoartist moving between forms.
Developer looking for work. 
Rogue Pedicab in Boston.

@maxjackson on telegram

<img src="https://i.seadn.io/gae/PNdgRmOHiLEG8ivbBBa9EJyX70y_uJhBvbfLk52j2UULqV5xJeC7VvI_j6EPkgl7bQY6UXAn9c_MYNgL3quj7IzRc_2ySDDov9Qj?w=500&auto=format" height="100" width="100" alt="Max Jackson : mxjxn" />
---
0x6da0a1784de1abdde1734ba37eca3d560bf044c0