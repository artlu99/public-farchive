username: metafren
fid: 15820
display name: Metafren
PFP: [https://i.imgur.com/qBrtvFw.jpg](https://i.imgur.com/qBrtvFw.jpg)
bio: Internet Nerd | Operations | Startup Tech | Blockchain Tech | Crypto & NFTs

<img src="https://i.imgur.com/qBrtvFw.jpg" height="100" width="100" alt="Metafren" />
