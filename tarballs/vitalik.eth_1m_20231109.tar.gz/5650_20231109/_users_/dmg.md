username: dmg
fid: 6830
display name: Daniel Grigsby
PFP: [https://i.imgur.com/5Trn6ig.jpg](https://i.imgur.com/5Trn6ig.jpg)
bio: Healthy tech Pyrrhonist. Maker of arbtr.com. Écoconceptionsplainer.

<img src="https://i.imgur.com/5Trn6ig.jpg" height="100" width="100" alt="Daniel Grigsby" />
