username: metopiamoon
fid: 20067
display name: Moon
PFP: [https://i.imgur.com/stSCUVx.jpg](https://i.imgur.com/stSCUVx.jpg)
bio: Founder of @Metopia_xyz, an onchain contribution & incentive platform • $BTC and $ETH since 2017 • Cat lover 🐈 • Foodie #StepN G #Sandbox Holder

<img src="https://i.imgur.com/stSCUVx.jpg" height="100" width="100" alt="Moon" />
