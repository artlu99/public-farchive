username: tranthanh
fid: 22221
display name: Trấn Thành
PFP: [https://i.imgur.com/yoAja45.jpg](https://i.imgur.com/yoAja45.jpg)
bio: Retroactive Viet Nam | Gem Infinity Viet Nam 

Researcher | Builder https://twitter.com/tanthanhbk

<img src="https://i.imgur.com/yoAja45.jpg" height="100" width="100" alt="Trấn Thành" />
---
0xc83c8916a1b9414de7f42deef4eb01917ec74451