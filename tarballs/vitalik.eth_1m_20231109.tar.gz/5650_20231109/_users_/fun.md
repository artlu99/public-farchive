username: fun
fid: 5620
display name: welter.eth — q/dau
PFP: [https://i.imgur.com/LE5osyF.jpg](https://i.imgur.com/LE5osyF.jpg)
bio: building farcaster apps like FarcasterUserStats.com and Hatecast.xyz

<img src="https://i.imgur.com/LE5osyF.jpg" height="100" width="100" alt="welter.eth — q/dau" />
---
0x02ac33835070d0c90bef87c273514e67aea36ef8