username: adrienne
fid: 5818
display name: Adrienne
PFP: [https://i.seadn.io/gae/fHFhEyRAWUv3GGEhSdD9fMQ8D9mdNcSPh2CrhTIqqQuXM62gAGclA5co44eUB-p-WP7zOC9opPTCtZYPvr4C9joBLVxMhhLFdjUH?w=500&auto=format](https://i.seadn.io/gae/fHFhEyRAWUv3GGEhSdD9fMQ8D9mdNcSPh2CrhTIqqQuXM62gAGclA5co44eUB-p-WP7zOC9opPTCtZYPvr4C9joBLVxMhhLFdjUH?w=500&auto=format)
bio: completionist word person and conversational liquidity provider☑️ mom x 3😻cohost gm Farcaster morning talk show 🎙️spread compassion 🌎❤️

<img src="https://i.seadn.io/gae/fHFhEyRAWUv3GGEhSdD9fMQ8D9mdNcSPh2CrhTIqqQuXM62gAGclA5co44eUB-p-WP7zOC9opPTCtZYPvr4C9joBLVxMhhLFdjUH?w=500&auto=format" height="100" width="100" alt="Adrienne" />
---
0xaea4a0dedb94ba5b2b8ed9477a8a54379c584542