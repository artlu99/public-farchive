username: july
fid: 1287
display name: July
PFP: [https://i.seadn.io/gcs/files/ed56e6b9a1b22720ce7490524db333e0.jpg?w=500&auto=format](https://i.seadn.io/gcs/files/ed56e6b9a1b22720ce7490524db333e0.jpg?w=500&auto=format)
bio: mostly creating and destroying; used to build flying cars & autonomous vehicles, now working on @faust

<img src="https://i.seadn.io/gcs/files/ed56e6b9a1b22720ce7490524db333e0.jpg?w=500&auto=format" height="100" width="100" alt="July" />
---
0xdd3bf199e65bba74144a9a1c0dfaeda32b911121