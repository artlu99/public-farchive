username: kia-ki-asian
fid: 24175
display name: KIA (Ki-Asian)
PFP: [https://i.imgur.com/Sxv7uh9.jpg](https://i.imgur.com/Sxv7uh9.jpg)
bio: 100% flow back! #BTC, #ETH

<img src="https://i.imgur.com/Sxv7uh9.jpg" height="100" width="100" alt="KIA (Ki-Asian)" />
---
0x20d9bf896e2f2fcaffc5865e5cd56ae3997e24cf