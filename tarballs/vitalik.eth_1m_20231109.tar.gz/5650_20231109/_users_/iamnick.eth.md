username: iamnick.eth
fid: 3647
display name: Nick Smith
PFP: [https://i.seadn.io/gcs/files/8583feea8a3465788d84367a92d80512.png?w=500&auto=format](https://i.seadn.io/gcs/files/8583feea8a3465788d84367a92d80512.png?w=500&auto=format)
bio: Building withfam.xyz Prev. Co-founder @ talisman.xyz ✴︎ Member @ FWB, Builder DAO, The Park ✷

<img src="https://i.seadn.io/gcs/files/8583feea8a3465788d84367a92d80512.png?w=500&auto=format" height="100" width="100" alt="Nick Smith" />
---
0x0f9b1b68f848cb65f532bc12825357201726d3d2