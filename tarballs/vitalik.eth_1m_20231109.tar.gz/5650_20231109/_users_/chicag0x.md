username: chicag0x
fid: 3395
display name: Chicag0x
PFP: [https://i.seadn.io/gae/4KUmcNu67nCpjjKhrvCWrOEW2oeZ7LApzsA8Mt8XmQJ5fJAGzKU6d0U-IrFYEOM_Iy9YX9xU9lVnPZ_mjzE5dpxmq4e35j41k6Jp?w=500&auto=format](https://i.seadn.io/gae/4KUmcNu67nCpjjKhrvCWrOEW2oeZ7LApzsA8Mt8XmQJ5fJAGzKU6d0U-IrFYEOM_Iy9YX9xU9lVnPZ_mjzE5dpxmq4e35j41k6Jp?w=500&auto=format)
bio: Host of Decentralized Dawn. https://decentralpod.com/ 
nf.td/chicag0x

<img src="https://i.seadn.io/gae/4KUmcNu67nCpjjKhrvCWrOEW2oeZ7LApzsA8Mt8XmQJ5fJAGzKU6d0U-IrFYEOM_Iy9YX9xU9lVnPZ_mjzE5dpxmq4e35j41k6Jp?w=500&auto=format" height="100" width="100" alt="Chicag0x" />
---
0x465f189d082f999c47e5e5aea9c05ab78f39a77d