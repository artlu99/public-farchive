username: nettra
fid: 11123
display name: nettra.eth
PFP: [https://i.imgur.com/TJig6Zm.jpg](https://i.imgur.com/TJig6Zm.jpg)
bio: 𝙸𝚖𝚊𝚐𝚒𝚗𝚊𝚝𝚒𝚘𝚗 𝚃𝚛𝚊𝚒𝚗𝚎𝚛 in training. I study how shared identities form around new technology. In my spare time, I create and collect jpegs.

<img src="https://i.imgur.com/TJig6Zm.jpg" height="100" width="100" alt="nettra.eth" />
---
0xb7f4e738bb0b85ad1ecef26a2a733dc899da500e
0x59bd99198e0b4f08dbb9ce49b48303d894253999
0xf105b0c2747caa177d9e27117a599e4a7ac67374