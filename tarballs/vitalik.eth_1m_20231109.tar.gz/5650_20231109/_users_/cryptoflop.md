username: cryptoflop
fid: 191164
display name: Arthur Shoppy
PFP: [https://i.imgur.com/35sQfLY.jpg](https://i.imgur.com/35sQfLY.jpg)
bio: his excellency

<img src="https://i.imgur.com/35sQfLY.jpg" height="100" width="100" alt="Arthur Shoppy" />
