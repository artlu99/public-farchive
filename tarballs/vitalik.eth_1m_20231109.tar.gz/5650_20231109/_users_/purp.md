username: purp
fid: 14364
display name: PurpLeTariat 
PFP: [https://i.seadn.io/gae/joTFXxgr8h__GTwtx7fT3s6cYS6Nn0HQbQWOTbJjI0IbF3Z0MBAfRCkl-EW4PIz-nKlTxCUtiGR7sBMWURlG5efmCVXKxeGXQt2JZ3Y?w=500&auto=format](https://i.seadn.io/gae/joTFXxgr8h__GTwtx7fT3s6cYS6Nn0HQbQWOTbJjI0IbF3Z0MBAfRCkl-EW4PIz-nKlTxCUtiGR7sBMWURlG5efmCVXKxeGXQt2JZ3Y?w=500&auto=format)
bio: Dj, producer, nice at ping pong

https://audius.co/TipYourDjDotEth/2525

<img src="https://i.seadn.io/gae/joTFXxgr8h__GTwtx7fT3s6cYS6Nn0HQbQWOTbJjI0IbF3Z0MBAfRCkl-EW4PIz-nKlTxCUtiGR7sBMWURlG5efmCVXKxeGXQt2JZ3Y?w=500&auto=format" height="100" width="100" alt="PurpLeTariat " />
---
0xa58b4a80de82b889ff40e487c58208a429c77f88