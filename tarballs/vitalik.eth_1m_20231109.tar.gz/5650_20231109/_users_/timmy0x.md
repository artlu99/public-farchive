username: timmy0x
fid: 189516
display name: Timmy0x
PFP: [https://i.imgur.com/bpkzx0N.jpg](https://i.imgur.com/bpkzx0N.jpg)
bio: Entrepreneur and crypto buidler.

Currently working on a crypto education platform for teens.

<img src="https://i.imgur.com/bpkzx0N.jpg" height="100" width="100" alt="Timmy0x" />
---
0x2dba91c342a7d8db0f957d03aa263d26e47a88f9