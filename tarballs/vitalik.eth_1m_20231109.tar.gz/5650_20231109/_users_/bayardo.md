username: bayardo
fid: 6394
display name: Roberto Bayardo
PFP: [https://i.imgur.com/UCPDIwN.jpg](https://i.imgur.com/UCPDIwN.jpg)
bio: Eng @ Coinbase
https://bayardo.org

<img src="https://i.imgur.com/UCPDIwN.jpg" height="100" width="100" alt="Roberto Bayardo" />
---
0x1e474b50bdc2b39dccaa2b8ddf37b3f022b128a8