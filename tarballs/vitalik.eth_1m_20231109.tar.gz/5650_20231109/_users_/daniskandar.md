username: daniskandar
fid: 3236
display name: danny iskandar
PFP: [https://i.imgur.com/ZUhJC3o.jpg](https://i.imgur.com/ZUhJC3o.jpg)
bio: Web3, tech, dead lift, shit post + awareness, Dad of 3 amazing kids … recovering from attachments, stuck in between realm of digital and analog

<img src="https://i.imgur.com/ZUhJC3o.jpg" height="100" width="100" alt="danny iskandar" />
---
0xc383eca4e6d5112b45ab13d691539911e4493ebe
0xbc948ce88f583f133f86fe8beecb172dccb1765c
0xa4a381864c03bdbd624acb190c3fd4fb00e4923d