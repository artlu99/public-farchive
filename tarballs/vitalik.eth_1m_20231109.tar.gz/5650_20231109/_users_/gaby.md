username: gaby
fid: 83
display name: Gaby Goldberg
PFP: [https://lh3.googleusercontent.com/7kZfysFMzyB_r1kJVXFXZ6S2skYNzPYlfFoVJTIt-7_dm5mJAy-xVsD1CijVUrAEBuXHDi8Ewu07qBRz8Le5NjShzvtCyHIr6tkc](https://lh3.googleusercontent.com/7kZfysFMzyB_r1kJVXFXZ6S2skYNzPYlfFoVJTIt-7_dm5mJAy-xVsD1CijVUrAEBuXHDi8Ewu07qBRz8Le5NjShzvtCyHIr6tkc)
bio: Investor at TCG Crypto. Farcaster power user. Posting half-baked thoughts here on digital identity & internet culture. nf.td/gaby

<img src="https://lh3.googleusercontent.com/7kZfysFMzyB_r1kJVXFXZ6S2skYNzPYlfFoVJTIt-7_dm5mJAy-xVsD1CijVUrAEBuXHDi8Ewu07qBRz8Le5NjShzvtCyHIr6tkc" height="100" width="100" alt="Gaby Goldberg" />
---
0x01b7baa7baa864fef3cd1c7bc118cc97cedcb33f