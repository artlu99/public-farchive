username: iamnickelsteel1
fid: 189607
display name: IamNickelSteel1.eth
PFP: [https://i.imgur.com/Krtt0rj.jpg](https://i.imgur.com/Krtt0rj.jpg)
bio: Solidity and Smart Contracts

<img src="https://i.imgur.com/Krtt0rj.jpg" height="100" width="100" alt="IamNickelSteel1.eth" />
---
0xa49caa841768ec5098eaf43d5ff4b5e918a5e5ec