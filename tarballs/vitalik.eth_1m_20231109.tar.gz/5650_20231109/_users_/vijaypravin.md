username: vijaypravin
fid: 144075
display name: Vijay Pravin
PFP: [https://i.seadn.io/gcs/files/e66d78751830fcc6cc871a23dbcecdb1.png?w=500&auto=format](https://i.seadn.io/gcs/files/e66d78751830fcc6cc871a23dbcecdb1.png?w=500&auto=format)
bio: Founder and CEO - bitsCrunch | Blockchain and NFTs. 

Living in Munich, Germany.

<img src="https://i.seadn.io/gcs/files/e66d78751830fcc6cc871a23dbcecdb1.png?w=500&auto=format" height="100" width="100" alt="Vijay Pravin" />
---
0x27f3a27540a1d6d2398bdbd458d62403f481f7c6