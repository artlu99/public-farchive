username: amg
fid: 21582
display name: AMG
PFP: [https://i.imgur.com/N6jfZ1I.jpg](https://i.imgur.com/N6jfZ1I.jpg)
bio: No money

<img src="https://i.imgur.com/N6jfZ1I.jpg" height="100" width="100" alt="AMG" />
---
0x11cd7d3c9411dfb5373bd902707efe100322082a