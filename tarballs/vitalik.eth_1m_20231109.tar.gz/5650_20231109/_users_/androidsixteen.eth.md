username: androidsixteen.eth
fid: 3635
display name: android 16
PFP: [https://i.imgur.com/wurbZlI.png](https://i.imgur.com/wurbZlI.png)
bio: software engineer... tinkering in crypto

<img src="https://i.imgur.com/wurbZlI.png" height="100" width="100" alt="android 16" />
---
0xfc8bfa5d9b87e75541ecb2750319c20717744967
0xfecbbfec931a06c0cf7b008cf3c013457f610a22