username: tuka419
fid: 190902
display name: Tuka419.eth
PFP: [https://i.seadn.io/s/raw/files/893b944131e71e801a56bfb86cdb550b.png?w=500&auto=format](https://i.seadn.io/s/raw/files/893b944131e71e801a56bfb86cdb550b.png?w=500&auto=format)
bio: Crypto Researcher - Airdrop Hunter 👀

Follow and back 💯💯💯

https://x.com/tuka419

<img src="https://i.seadn.io/s/raw/files/893b944131e71e801a56bfb86cdb550b.png?w=500&auto=format" height="100" width="100" alt="Tuka419.eth" />
---
0xeb2146a01bb7ff39ab912e6156d8f565e37c9a8e