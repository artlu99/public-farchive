username: vijaypatel
fid: 17747
display name: Vijay
PFP: [https://i.imgur.com/YVhNwcj.jpg](https://i.imgur.com/YVhNwcj.jpg)
bio: Market Structure Trader

<img src="https://i.imgur.com/YVhNwcj.jpg" height="100" width="100" alt="Vijay" />
---
0xeb04ee956b3aa60977542e084e38c60be7fd69a5