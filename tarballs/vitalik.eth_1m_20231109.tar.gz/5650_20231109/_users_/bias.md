username: bias
fid: 1355
display name: Bias 🫧
PFP: [https://i.seadn.io/gcs/files/1456619b5ea90a6b26e8d7f0838eb6b3.png?w=500&auto=format](https://i.seadn.io/gcs/files/1456619b5ea90a6b26e8d7f0838eb6b3.png?w=500&auto=format)
bio: 𝙱𝙴𝙶𝙶𝙰𝚁 𝙰𝙵𝚃𝙴𝚁 𝙺𝙽𝙾𝚆𝙻𝙴𝙳𝙶𝙴 
Decentralized dimensional designer, autodidact. 🗿 UX & AI/ML  • Channeling @punk • 
mendicantbias.xyz 🫧

<img src="https://i.seadn.io/gcs/files/1456619b5ea90a6b26e8d7f0838eb6b3.png?w=500&auto=format" height="100" width="100" alt="Bias 🫧" />
---
0x58d205f9d265399f5e68b783162d9508c0469bdf