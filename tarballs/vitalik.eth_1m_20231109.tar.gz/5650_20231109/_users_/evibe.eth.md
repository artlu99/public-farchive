username: evibe.eth
fid: 16815
display name: evibe.eth
PFP: [https://i.seadn.io/gcs/files/f63a9acae88d5e4a0b0f5b69bdcfa894.png?w=500&auto=format](https://i.seadn.io/gcs/files/f63a9acae88d5e4a0b0f5b69bdcfa894.png?w=500&auto=format)
bio: I am a generative artist that is fascinated with the future of ENS and it’s utility. I believe it is a magical gateway into web3.

<img src="https://i.seadn.io/gcs/files/f63a9acae88d5e4a0b0f5b69bdcfa894.png?w=500&auto=format" height="100" width="100" alt="evibe.eth" />
---
0x080b62ceaedd748329222e3bb823bf75cfafaa89