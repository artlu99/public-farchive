username: tina
fid: 189920
display name: Tina
PFP: [https://i.imgur.com/7Kba980.jpg](https://i.imgur.com/7Kba980.jpg)
bio: I love the nature！Follow me！I will follow you back!

<img src="https://i.imgur.com/7Kba980.jpg" height="100" width="100" alt="Tina" />
