username: kbc
fid: 12021
display name: kbc
PFP: [https://i.seadn.io/gcs/files/8433bb792723068a3599714e2000715b.png?w=500&auto=format](https://i.seadn.io/gcs/files/8433bb792723068a3599714e2000715b.png?w=500&auto=format)
bio: Building TogetherCrew.com | Analyst of human coordination | single parent x 4 | seeker of adventure | survivor of chaos

<img src="https://i.seadn.io/gcs/files/8433bb792723068a3599714e2000715b.png?w=500&auto=format" height="100" width="100" alt="kbc" />
---
0xe372cf77187e27b15805803cf331f6b7330f223b
0xe052b2fcf0343ba2cc6a42ef5626c64e9b15f984
0x6d5e5c19c360b4bce6ba312aa19d1c14ac1e38a5