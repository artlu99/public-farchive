username: ducktape
fid: 8824
display name: DuckTape
PFP: [https://i.imgur.com/M2DGW31.png](https://i.imgur.com/M2DGW31.png)
bio: Building absurd.finance 

<img src="https://i.imgur.com/M2DGW31.png" height="100" width="100" alt="DuckTape" />
---
0xb65e5c84b3ac82bc4e76ed20aabb6edd24fe4f23