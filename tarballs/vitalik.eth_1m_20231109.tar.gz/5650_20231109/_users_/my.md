username: my
fid: 5306
display name: Myke Mnemonic
PFP: [https://i.imgur.com/K0HhHYw.jpg](https://i.imgur.com/K0HhHYw.jpg)
bio: All in on AI and community. 🚴‍♂️💨

<img src="https://i.imgur.com/K0HhHYw.jpg" height="100" width="100" alt="Myke Mnemonic" />
