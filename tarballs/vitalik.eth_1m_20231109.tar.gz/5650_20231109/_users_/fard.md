username: fard
fid: 17542
display name: Kourosh
PFP: [https://i.imgur.com/hI0f1aO.jpg](https://i.imgur.com/hI0f1aO.jpg)
bio: Freedom

<img src="https://i.imgur.com/hI0f1aO.jpg" height="100" width="100" alt="Kourosh" />
---
0xe3f1a9201d84aad668b669d3949bb5640b4476ae