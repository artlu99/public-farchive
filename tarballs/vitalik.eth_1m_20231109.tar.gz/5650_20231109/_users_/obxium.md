username: obxium
fid: 12457
display name: obxium
PFP: [https://i.imgur.com/grUdS4l.png](https://i.imgur.com/grUdS4l.png)
bio: Artist #cryptoart since 2018 — art on 6 blockchains — chaotic neutral w/ a PhD in chaos — https://obxium.com

<img src="https://i.imgur.com/grUdS4l.png" height="100" width="100" alt="obxium" />
---
0xf65db13b5ee031cb0ebba525ef21aa6c586681b3