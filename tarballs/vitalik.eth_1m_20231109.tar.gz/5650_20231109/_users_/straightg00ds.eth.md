username: straightg00ds.eth
fid: 14449
display name: KDB
PFP: [https://i.seadn.io/gae/lQuYV19yJ6eXG_ojhS7YZFF2aAtiqWGE8icd9y_JHBeBl7aKpQWrZItt86_ZKymQra9AfctWHTpkJyiE4jooGZpr_hwcln-mohadUg?w=500&auto=format](https://i.seadn.io/gae/lQuYV19yJ6eXG_ojhS7YZFF2aAtiqWGE8icd9y_JHBeBl7aKpQWrZItt86_ZKymQra9AfctWHTpkJyiE4jooGZpr_hwcln-mohadUg?w=500&auto=format)
bio: Crypto Bro 

<img src="https://i.seadn.io/gae/lQuYV19yJ6eXG_ojhS7YZFF2aAtiqWGE8icd9y_JHBeBl7aKpQWrZItt86_ZKymQra9AfctWHTpkJyiE4jooGZpr_hwcln-mohadUg?w=500&auto=format" height="100" width="100" alt="KDB" />
---
0x470d235ca1caff614abee02d98ac3aa89a6758bd