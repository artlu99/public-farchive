username: kugusha.eth
fid: 9135
display name: q/dau
PFP: [https://i.seadn.io/gcs/files/3ff11a59b890452429efe84e33af424f.png?w=500&auto=format](https://i.seadn.io/gcs/files/3ff11a59b890452429efe84e33af424f.png?w=500&auto=format)
bio: consistently curious | community at Sismo.io 

<img src="https://i.seadn.io/gcs/files/3ff11a59b890452429efe84e33af424f.png?w=500&auto=format" height="100" width="100" alt="q/dau" />
---
0x8379bd16381620914d8fa3d535f6ca9ef23ece53