username: dcposch.eth
fid: 56
display name: dcposch.eth
PFP: [https://i.seadn.io/gae/JUbGP1Idb08BeW4f7PQ3hp5PVk8DRCqzlh5ygxHdoSCUWMSNplJxoZBUJkMlPXx7FacPo3V2GA0SwD9NmBzekGejaNpCr9HJ_cwUlZI?w=500&auto=format](https://i.seadn.io/gae/JUbGP1Idb08BeW4f7PQ3hp5PVk8DRCqzlh5ygxHdoSCUWMSNplJxoZBUJkMlPXx7FacPo3V2GA0SwD9NmBzekGejaNpCr9HJ_cwUlZI?w=500&auto=format)
bio: Etherean. Working on @daimo

<img src="https://i.seadn.io/gae/JUbGP1Idb08BeW4f7PQ3hp5PVk8DRCqzlh5ygxHdoSCUWMSNplJxoZBUJkMlPXx7FacPo3V2GA0SwD9NmBzekGejaNpCr9HJ_cwUlZI?w=500&auto=format" height="100" width="100" alt="dcposch.eth" />
---
0xc60a0a0e8bbc32dac2e03030989ad6bee45a874d