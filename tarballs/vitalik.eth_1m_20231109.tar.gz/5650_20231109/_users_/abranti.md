username: abranti
fid: 1513
display name: abranti
PFP: [https://pbs.twimg.com/profile_images/1541062227175825408/xJnwjn_m_400x400.jpg](https://pbs.twimg.com/profile_images/1541062227175825408/xJnwjn_m_400x400.jpg)
bio: gathering wisdom from the crowd with prediction markets  @ writingmonks.com

<img src="https://pbs.twimg.com/profile_images/1541062227175825408/xJnwjn_m_400x400.jpg" height="100" width="100" alt="abranti" />
---
0x15d2d027c8e2ccd5295e35659b76e61def483ee7