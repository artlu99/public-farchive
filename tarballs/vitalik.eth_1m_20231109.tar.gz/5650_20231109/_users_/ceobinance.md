username: ceobinance
fid: 23299
display name: Ceobinance
PFP: [https://i.imgur.com/iHlbyyE.jpg](https://i.imgur.com/iHlbyyE.jpg)
bio: Defi, Web3,Meme,AI

<img src="https://i.imgur.com/iHlbyyE.jpg" height="100" width="100" alt="Ceobinance" />
---
0x34f0431bec239c0828fbcf96c32092e5c926df21