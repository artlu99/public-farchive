username: ted
fid: 239
display name: ted (not lasso)
PFP: [https://openseauserdata.com/files/fd28c65d9b5192168fb259009a3afd36.png](https://openseauserdata.com/files/fd28c65d9b5192168fb259009a3afd36.png)
bio: biz ops @goldfinch | dao ops @boysclub | surfing @venice, ca | eating @gjusta / gjelina | former molecular biologist

<img src="https://openseauserdata.com/files/fd28c65d9b5192168fb259009a3afd36.png" height="100" width="100" alt="ted (not lasso)" />
---
0x0aa34eb615ab330b64060ff9fa994e72a7a95b59