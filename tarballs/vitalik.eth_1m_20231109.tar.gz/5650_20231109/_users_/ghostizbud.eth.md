username: ghostizbud.eth
fid: 24190
display name: ghostizbud
PFP: [https://i.seadn.io/s/raw/files/87249fcba664253c744b84c762505635.jpg?w=500&auto=format](https://i.seadn.io/s/raw/files/87249fcba664253c744b84c762505635.jpg?w=500&auto=format)
bio: Was rekt by UST, then was involved in UST restitution mess, now explore L2 lol let’s waste some more

<img src="https://i.seadn.io/s/raw/files/87249fcba664253c744b84c762505635.jpg?w=500&auto=format" height="100" width="100" alt="ghostizbud" />
---
0x0aac011058e332bab220c42ffae2164894e04dbf