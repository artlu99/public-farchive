username: aida
fid: 14560
display name: Aida
PFP: [https://i.imgur.com/lPVnuTS.jpg](https://i.imgur.com/lPVnuTS.jpg)
bio: My hobby is baking 🎂.  and crypto 

<img src="https://i.imgur.com/lPVnuTS.jpg" height="100" width="100" alt="Aida" />
---
0x7f730efd6bf10c3a6aec489665ad4dde978c9175