username: nicholas
fid: 1237
display name: nicholas
PFP: [https://i.imgur.com/griJWts.png](https://i.imgur.com/griJWts.png)
bio: solidity dev. i interview crypto devs on web3galaxybrain.com. aka x.com/nnnnicholas

<img src="https://i.imgur.com/griJWts.png" height="100" width="100" alt="nicholas" />
---
0x6877be9e00d0bc5886c28419901e8cc98c1c2739