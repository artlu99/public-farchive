username: kevinoconnell
fid: 4564
display name: Kevin
PFP: [https://i.imgur.com/lzrAYhT.jpg](https://i.imgur.com/lzrAYhT.jpg)
bio: Founding engineer @hypeshot, bad chess player. 
GH: MrKevinOConnell.github

TG: KWOETH.telegram

@chessbot

<img src="https://i.imgur.com/lzrAYhT.jpg" height="100" width="100" alt="Kevin" />
---
0xedd3783e8c7c52b80cfbd026a63c207edc9cbee7