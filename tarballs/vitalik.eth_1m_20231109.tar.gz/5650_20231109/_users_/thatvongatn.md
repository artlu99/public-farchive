username: thatvongatn
fid: 189097
display name: Phạm Việt Hùng
PFP: [https://i.imgur.com/gevB5Ab.jpg](https://i.imgur.com/gevB5Ab.jpg)
bio: Sâu béo là tình yêu to lớn của cuộc đời tôi

<img src="https://i.imgur.com/gevB5Ab.jpg" height="100" width="100" alt="Phạm Việt Hùng" />
---
0xbb15f7e206830bc5a026973d2d01fc1c81b0915f