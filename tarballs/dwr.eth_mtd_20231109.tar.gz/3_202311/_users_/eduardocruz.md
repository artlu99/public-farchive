username: eduardocruz
fid: 6379
display name: Eduardo Cruz
PFP: [https://i.seadn.io/gcs/files/80dd137bc68cfe5d17b534409864f5e9.png?w=500&auto=format](https://i.seadn.io/gcs/files/80dd137bc68cfe5d17b534409864f5e9.png?w=500&auto=format)
bio: Created https://HOurNouns.wtf

<img src="https://i.seadn.io/gcs/files/80dd137bc68cfe5d17b534409864f5e9.png?w=500&auto=format" height="100" width="100" alt="Eduardo Cruz" />
