username: eyeshuuh
fid: 3063
display name: Aysha
PFP: [https://i.imgur.com/y2vutYq.jpg](https://i.imgur.com/y2vutYq.jpg)
bio: @She__Fi SZN 8 | Scientist | Researcher | DeSci | web3

<img src="https://i.imgur.com/y2vutYq.jpg" height="100" width="100" alt="Aysha" />
