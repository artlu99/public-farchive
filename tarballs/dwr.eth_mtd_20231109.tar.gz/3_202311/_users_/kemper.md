username: kemper
fid: 6289
display name: kemper
PFP: [https://i.imgur.com/aNtF0Bo.jpg](https://i.imgur.com/aNtF0Bo.jpg)
bio: code is speech.
inflation is a policy decision.

<img src="https://i.imgur.com/aNtF0Bo.jpg" height="100" width="100" alt="kemper" />
---
0x39a1a91945b5fe939362b410bfff3c9cebdb38d1