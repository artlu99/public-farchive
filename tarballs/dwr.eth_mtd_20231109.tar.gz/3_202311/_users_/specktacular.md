username: specktacular
fid: 8636
display name: Specktacular 🔵
PFP: [https://i.seadn.io/gcs/files/c5c4092adcb19cd770e35788066e49c2.png?w=500&auto=format](https://i.seadn.io/gcs/files/c5c4092adcb19cd770e35788066e49c2.png?w=500&auto=format)
bio: Wandering a Wonderful Web3 🚀
Husband in ❤️. Lifelong Learner. Italian, at 💙!
Specktacularly ready to cast far & wide! 
Maintaining hope in Humanity 🌍

<img src="https://i.seadn.io/gcs/files/c5c4092adcb19cd770e35788066e49c2.png?w=500&auto=format" height="100" width="100" alt="Specktacular 🔵" />
---
0xbbfd3fc1402963f61191190401e76957c6e02e83