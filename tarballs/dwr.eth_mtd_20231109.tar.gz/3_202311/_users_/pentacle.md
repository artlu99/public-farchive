username: pentacle
fid: 1068
display name: pentacle
PFP: [https://static.wikia.nocookie.net/howlscastle/images/7/79/Sophie_7552.jpg](https://static.wikia.nocookie.net/howlscastle/images/7/79/Sophie_7552.jpg)
bio: tea lady 
pentacle.xyz

<img src="https://static.wikia.nocookie.net/howlscastle/images/7/79/Sophie_7552.jpg" height="100" width="100" alt="pentacle" />
