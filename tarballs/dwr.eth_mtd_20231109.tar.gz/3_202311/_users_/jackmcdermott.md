username: jackmcdermott
fid: 3966
display name: Jack McDermott☁️🟣🐦🧵
PFP: [https://i.imgur.com/8AZtD9q.jpg](https://i.imgur.com/8AZtD9q.jpg)
bio: Growth Lead at @yup, an app where you can crosspost to Farcaster, Twitter, Lens and Bluesky at once and enjoy their aggregated content

<img src="https://i.imgur.com/8AZtD9q.jpg" height="100" width="100" alt="Jack McDermott☁️🟣🐦🧵" />
---
0xb9447ca592c68d56ee481d5d12adf11db1008a72