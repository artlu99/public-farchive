username: pher
fid: 192391
display name: Pher
PFP: [https://i.imgur.com/eDQikO4.jpg](https://i.imgur.com/eDQikO4.jpg)
bio: I'm a little teapot who didn't fill out my bio

<img src="https://i.imgur.com/eDQikO4.jpg" height="100" width="100" alt="Pher" />
