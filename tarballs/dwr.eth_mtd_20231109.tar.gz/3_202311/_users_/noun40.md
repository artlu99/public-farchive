username: noun40
fid: 1097
display name: Noun 40
PFP: [https://openseauserdata.com/files/faa77932343776d1237e5dd82aa12e76.svg](https://openseauserdata.com/files/faa77932343776d1237e5dd82aa12e76.svg)
bio: cofounder/cto @ bitwise

<img src="https://openseauserdata.com/files/faa77932343776d1237e5dd82aa12e76.svg" height="100" width="100" alt="Noun 40" />
---
0xae65e700f3f8904ac1007d47a5309dd26f8146c0