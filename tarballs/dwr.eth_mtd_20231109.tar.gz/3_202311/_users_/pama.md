username: pama
fid: 13806
display name: Paul
PFP: [https://i.imgur.com/BiMIrbt.jpg](https://i.imgur.com/BiMIrbt.jpg)
bio: i <3 the internet, markets, machine learning, blockchains, geopolitics, music and open-source software

⌐◨-◨  …

<img src="https://i.imgur.com/BiMIrbt.jpg" height="100" width="100" alt="Paul" />
