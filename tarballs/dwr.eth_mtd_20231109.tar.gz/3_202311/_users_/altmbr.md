username: altmbr
fid: 1277
display name: altmbr
PFP: [https://lh3.googleusercontent.com/L0QK2v6VPpuLzrRAngWi4zoLpM9LWX88Ec-rlExJcSWSBZZXW1t1SA-hZky9qcROIvxJs7RMx2vjYh9CgZ5AS0qKpVb2tjKrWv4dxhw](https://lh3.googleusercontent.com/L0QK2v6VPpuLzrRAngWi4zoLpM9LWX88Ec-rlExJcSWSBZZXW1t1SA-hZky9qcROIvxJs7RMx2vjYh9CgZ5AS0qKpVb2tjKrWv4dxhw)
bio: Founder Ziggy

Casting about web3 growth, startups, and health & wellness

<img src="https://lh3.googleusercontent.com/L0QK2v6VPpuLzrRAngWi4zoLpM9LWX88Ec-rlExJcSWSBZZXW1t1SA-hZky9qcROIvxJs7RMx2vjYh9CgZ5AS0qKpVb2tjKrWv4dxhw" height="100" width="100" alt="altmbr" />
---
0xd342f616a504cbd471b0405b70bf991c1d6fe72b