username: gabe
fid: 2339
display name: gabe
PFP: [https://lh3.googleusercontent.com/tlP8YEegH4gC2k-68Y5-_U7Xr3H2QgO417QeF83dUb4ILACeVBSxjQtjzO-BP0xE1kpxrRHovS-iE_-EYDBF0HFktP6vh3jzXpfg1w](https://lh3.googleusercontent.com/tlP8YEegH4gC2k-68Y5-_U7Xr3H2QgO417QeF83dUb4ILACeVBSxjQtjzO-BP0xE1kpxrRHovS-iE_-EYDBF0HFktP6vh3jzXpfg1w)
bio: decentralization enthusiast. dev @ TBD, focused on decentralized identity & individual privacy

<img src="https://lh3.googleusercontent.com/tlP8YEegH4gC2k-68Y5-_U7Xr3H2QgO417QeF83dUb4ILACeVBSxjQtjzO-BP0xE1kpxrRHovS-iE_-EYDBF0HFktP6vh3jzXpfg1w" height="100" width="100" alt="gabe" />
---
0x8e91b6aed2eb316ee54e6646e027229a328c0ac2