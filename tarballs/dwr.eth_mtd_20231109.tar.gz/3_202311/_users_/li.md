username: li
fid: 30
display name: Li Jin
PFP: [https://i.seadn.io/gcs/files/ff633ddaca08bec34a71e921e5ecee66.png?w=500&auto=format](https://i.seadn.io/gcs/files/ff633ddaca08bec34a71e921e5ecee66.png?w=500&auto=format)
bio: 

<img src="https://i.seadn.io/gcs/files/ff633ddaca08bec34a71e921e5ecee66.png?w=500&auto=format" height="100" width="100" alt="Li Jin" />
