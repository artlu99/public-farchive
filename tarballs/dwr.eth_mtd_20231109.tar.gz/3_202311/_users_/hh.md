username: hh
fid: 5186
display name: henry
PFP: [https://i.seadn.io/gcs/files/759b83eb1664bac6dc7a40d26369a9c0.png?w=500&auto=format](https://i.seadn.io/gcs/files/759b83eb1664bac6dc7a40d26369a9c0.png?w=500&auto=format)
bio: founding squad openux.xyz

<img src="https://i.seadn.io/gcs/files/759b83eb1664bac6dc7a40d26369a9c0.png?w=500&auto=format" height="100" width="100" alt="henry" />
---
0x9799b8f76aac136aabf6510e40043213351246c6