username: joalavedra
fid: 3504
display name: Joan
PFP: [https://i.seadn.io/gae/VWK1O8FoU-eKlvfH3qv8O87i9H7TNYniJnmXiMNmVKP6VOJX71jxaDiyVmSW7VrXP37Q0ZKT8twz_g4jqo4TsZGh__WD1zANCGImnQw?w=500&auto=format](https://i.seadn.io/gae/VWK1O8FoU-eKlvfH3qv8O87i9H7TNYniJnmXiMNmVKP6VOJX71jxaDiyVmSW7VrXP37Q0ZKT8twz_g4jqo4TsZGh__WD1zANCGImnQw?w=500&auto=format)
bio: building openfort.xyz

<img src="https://i.seadn.io/gae/VWK1O8FoU-eKlvfH3qv8O87i9H7TNYniJnmXiMNmVKP6VOJX71jxaDiyVmSW7VrXP37Q0ZKT8twz_g4jqo4TsZGh__WD1zANCGImnQw?w=500&auto=format" height="100" width="100" alt="Joan" />
