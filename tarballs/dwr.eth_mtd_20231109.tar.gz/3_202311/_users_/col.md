username: col
fid: 8017
display name: Col
PFP: [https://i.imgur.com/4sBqser.jpg](https://i.imgur.com/4sBqser.jpg)
bio: Building web0.club

<img src="https://i.imgur.com/4sBqser.jpg" height="100" width="100" alt="Col" />
---
0x8a7ca06479993930557afa306dafa671c7962f54