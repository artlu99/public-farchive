username: sams
fid: 11500
display name: Sam ⌐///-///
PFP: [https://i.imgur.com/vywncde.jpg](https://i.imgur.com/vywncde.jpg)
bio: Developer & Designer / nounish.af / Building @esports @federation

<img src="https://i.imgur.com/vywncde.jpg" height="100" width="100" alt="Sam ⌐///-///" />
---
0xe3ff24a97bfb65cadef30f6ad19a6ea7e6f6149d