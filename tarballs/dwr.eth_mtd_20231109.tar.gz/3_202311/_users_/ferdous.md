username: ferdous
fid: 2009
display name: Ferdous Bhai
PFP: [https://i.imgur.com/M3MLMdy.jpg](https://i.imgur.com/M3MLMdy.jpg)
bio: ☀️🌳🏙💡🌻🏞️🌤🏢🌿🏡🔭🌌✨🍃

<img src="https://i.imgur.com/M3MLMdy.jpg" height="100" width="100" alt="Ferdous Bhai" />
