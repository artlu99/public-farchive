username: mint
fid: 6724
display name: peachmint
PFP: [https://i.seadn.io/gcs/files/9d1369cae715dde1b608eff72ae23129.png?w=500&auto=format](https://i.seadn.io/gcs/files/9d1369cae715dde1b608eff72ae23129.png?w=500&auto=format)
bio: Fulltime bitcoin loser

<img src="https://i.seadn.io/gcs/files/9d1369cae715dde1b608eff72ae23129.png?w=500&auto=format" height="100" width="100" alt="peachmint" />
---
0x14b889b25e70f60d8dc0aa5f10c83680add61351