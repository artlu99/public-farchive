username: cr
fid: 4853
display name: CBobRobison
PFP: [https://i.seadn.io/gae/5BGNFAH2rDKK2cIlbvDUd7amr8XT2fRA03uRuJ7_jZuP0ltZBKACGpA5ANc5QoUu5rKZEX6gubql2SNgm66jA49k?w=500&auto=format](https://i.seadn.io/gae/5BGNFAH2rDKK2cIlbvDUd7amr8XT2fRA03uRuJ7_jZuP0ltZBKACGpA5ANc5QoUu5rKZEX6gubql2SNgm66jA49k?w=500&auto=format)
bio: Founder of meTokens.com social token protocol. Former Golem, OMG Network, Hoard. Speaker at & contributor to ETHGlobal, NFT NYC, Ethereum Community Fund, DevCon

<img src="https://i.seadn.io/gae/5BGNFAH2rDKK2cIlbvDUd7amr8XT2fRA03uRuJ7_jZuP0ltZBKACGpA5ANc5QoUu5rKZEX6gubql2SNgm66jA49k?w=500&auto=format" height="100" width="100" alt="CBobRobison" />
