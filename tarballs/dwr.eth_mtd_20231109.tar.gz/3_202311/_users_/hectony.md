username: hectony
fid: 15095
display name: HecTony
PFP: [https://i.imgur.com/giUD67v.jpg](https://i.imgur.com/giUD67v.jpg)
bio: Halo Reach OG gamer
Call of Duty Black Ops 2 ranked player
Streetwear fashion 📈
Consistent learner 

<img src="https://i.imgur.com/giUD67v.jpg" height="100" width="100" alt="HecTony" />
---
0x2be60b0fb138479f7333086cc2460620436a110e