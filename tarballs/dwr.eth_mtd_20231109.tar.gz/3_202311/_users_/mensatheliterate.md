username: mensatheliterate
fid: 4521
display name: mensa
PFP: [https://i.seadn.io/gae/818oWNA6vWES-BWOYlRU0U5Hx6f4J48XrRFMtwOI_bxNqPZJ4H8-fgkRcRcjSQCRU0SUEju_1RXDQvC1lLPskhVscTKS_JahEkcMmg?w=500&auto=format](https://i.seadn.io/gae/818oWNA6vWES-BWOYlRU0U5Hx6f4J48XrRFMtwOI_bxNqPZJ4H8-fgkRcRcjSQCRU0SUEju_1RXDQvC1lLPskhVscTKS_JahEkcMmg?w=500&auto=format)
bio: mensa the literate, mage of the woods

<img src="https://i.seadn.io/gae/818oWNA6vWES-BWOYlRU0U5Hx6f4J48XrRFMtwOI_bxNqPZJ4H8-fgkRcRcjSQCRU0SUEju_1RXDQvC1lLPskhVscTKS_JahEkcMmg?w=500&auto=format" height="100" width="100" alt="mensa" />
