username: alex
fid: 2777
display name: Alex Bruno
PFP: [https://i.seadn.io/gae/znCn-R3dtl-CrlAcZjIpJrJHI0ExJo6BXkzUpb_QY9vo1SI66UHb8Dm6xNQRfZ01XjDfjkDvGq6IHJPNOcEPeetQZVGzcqk7SZUW?w=500&auto=format](https://i.seadn.io/gae/znCn-R3dtl-CrlAcZjIpJrJHI0ExJo6BXkzUpb_QY9vo1SI66UHb8Dm6xNQRfZ01XjDfjkDvGq6IHJPNOcEPeetQZVGzcqk7SZUW?w=500&auto=format)
bio: Rest in Fluorescence ⟡ Designer ⟡ He/Him

<img src="https://i.seadn.io/gae/znCn-R3dtl-CrlAcZjIpJrJHI0ExJo6BXkzUpb_QY9vo1SI66UHb8Dm6xNQRfZ01XjDfjkDvGq6IHJPNOcEPeetQZVGzcqk7SZUW?w=500&auto=format" height="100" width="100" alt="Alex Bruno" />
---
0x472723a705b7fdf72c92b97696f26df545ec11f1