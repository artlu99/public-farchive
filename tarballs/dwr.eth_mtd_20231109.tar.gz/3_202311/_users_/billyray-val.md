username: billyray-val
fid: 2290
display name: Billy Ray Valentine
PFP: [https://lh3.googleusercontent.com/-rGn1sWa8xrIYFPrcW1am6eLpdbGPtotT3-VdnDuG7sJjQpunMMpeC_X8rZbWxlEtnyKDdg8py6RpVkiuggI0qybamt0osGJE15exgs](https://lh3.googleusercontent.com/-rGn1sWa8xrIYFPrcW1am6eLpdbGPtotT3-VdnDuG7sJjQpunMMpeC_X8rZbWxlEtnyKDdg8py6RpVkiuggI0qybamt0osGJE15exgs)
bio: Im a Web3 analyst, researcher and Investooor

<img src="https://lh3.googleusercontent.com/-rGn1sWa8xrIYFPrcW1am6eLpdbGPtotT3-VdnDuG7sJjQpunMMpeC_X8rZbWxlEtnyKDdg8py6RpVkiuggI0qybamt0osGJE15exgs" height="100" width="100" alt="Billy Ray Valentine" />
