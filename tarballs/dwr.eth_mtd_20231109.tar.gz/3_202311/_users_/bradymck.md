username: bradymck
fid: 21229
display name: Brady
PFP: [https://i.imgur.com/yvLORH7.jpg](https://i.imgur.com/yvLORH7.jpg)
bio: Counterculture movements, Musical moments, Patronage, and Dad jokes

<img src="https://i.imgur.com/yvLORH7.jpg" height="100" width="100" alt="Brady" />
