username: probe155
fid: 2779
display name: Parth Chopra
PFP: [https://lh3.googleusercontent.com/sCYlAUm3vdbu1Fc_hu_I3VRBfFTJNgDSdvGxSL2PmqIOrgIsjpzpKFAktA7aeFiS2AbBH7vx-fRP0ueh9uVJacdq5v4JmYUAjFWJ1YQ](https://lh3.googleusercontent.com/sCYlAUm3vdbu1Fc_hu_I3VRBfFTJNgDSdvGxSL2PmqIOrgIsjpzpKFAktA7aeFiS2AbBH7vx-fRP0ueh9uVJacdq5v4JmYUAjFWJ1YQ)
bio: Vibing on-chain

<img src="https://lh3.googleusercontent.com/sCYlAUm3vdbu1Fc_hu_I3VRBfFTJNgDSdvGxSL2PmqIOrgIsjpzpKFAktA7aeFiS2AbBH7vx-fRP0ueh9uVJacdq5v4JmYUAjFWJ1YQ" height="100" width="100" alt="Parth Chopra" />
