username: outricked
fid: 9802
display name: Rick
PFP: [https://i.seadn.io/gcs/files/8b5f7e2d8e1bc4d1561a708117d2a707.png?w=500&auto=format](https://i.seadn.io/gcs/files/8b5f7e2d8e1bc4d1561a708117d2a707.png?w=500&auto=format)
bio: Code monkey at Coinbase. 
building web3 onramp

<img src="https://i.seadn.io/gcs/files/8b5f7e2d8e1bc4d1561a708117d2a707.png?w=500&auto=format" height="100" width="100" alt="Rick" />
---
0xc62cddc27ae3a5719d15e164d7d3fe5f257f2617