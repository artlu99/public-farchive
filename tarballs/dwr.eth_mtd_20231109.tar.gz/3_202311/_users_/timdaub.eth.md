username: timdaub.eth
fid: 5708
display name: timdaub 🥝/🫦
PFP: [https://openseauserdata.com/files/78d14379f8a84f6dddb48b58c8809849.svg](https://openseauserdata.com/files/78d14379f8a84f6dddb48b58c8809849.svg)
bio: Founder @kiwi, a decentralized HN

<img src="https://openseauserdata.com/files/78d14379f8a84f6dddb48b58c8809849.svg" height="100" width="100" alt="timdaub 🥝/🫦" />
---
0xee324c588cef1bf1c1360883e4318834af66366d