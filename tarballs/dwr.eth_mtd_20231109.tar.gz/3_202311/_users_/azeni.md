username: azeni
fid: 2536
display name: Alessandro ⏩
PFP: [https://lh3.googleusercontent.com/lmNP8W0RHu35iuvqKP6t6winTk9Ww_1QNPNI1DhMtAwQ532f0MWUaJPBo_wK3nEq0tyNI3JQLf4wiwvQjpBbraKiZz4jjD64XfmG1g](https://lh3.googleusercontent.com/lmNP8W0RHu35iuvqKP6t6winTk9Ww_1QNPNI1DhMtAwQ532f0MWUaJPBo_wK3nEq0tyNI3JQLf4wiwvQjpBbraKiZz4jjD64XfmG1g)
bio: Ars longa, vita brevis. AI at perisphere.io // alessandroseni.twitter

<img src="https://lh3.googleusercontent.com/lmNP8W0RHu35iuvqKP6t6winTk9Ww_1QNPNI1DhMtAwQ532f0MWUaJPBo_wK3nEq0tyNI3JQLf4wiwvQjpBbraKiZz4jjD64XfmG1g" height="100" width="100" alt="Alessandro ⏩" />
---
0x2a937a6acd819631bfc79553ae7ccc5ca05e23ac