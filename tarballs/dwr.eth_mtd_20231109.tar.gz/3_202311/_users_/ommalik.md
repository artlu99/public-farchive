username: ommalik
fid: 7556
display name: Om Malik
PFP: [https://i.imgur.com/j3NxxnO.jpg](https://i.imgur.com/j3NxxnO.jpg)
bio: Investor, Writer & Photographer. Partner emeritus @ True Ventures. Past life: Started GigaOm. I have written about tech for 3+ decades. Visit: Om.co

<img src="https://i.imgur.com/j3NxxnO.jpg" height="100" width="100" alt="Om Malik" />
---
0x490d6fb8b52b7d79963c1ecb123bc1ffae47cd1b