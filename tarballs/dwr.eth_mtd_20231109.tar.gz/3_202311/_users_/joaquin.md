username: joaquin
fid: 860
display name: Joaquin
PFP: [https://openseauserdata.com/files/ba0f8622ed3b64322749e7e6bc09f0c7.svg](https://openseauserdata.com/files/ba0f8622ed3b64322749e7e6bc09f0c7.svg)
bio: Chileno into dad’ing, gardening, golf, soccer, and the outdoors

<img src="https://openseauserdata.com/files/ba0f8622ed3b64322749e7e6bc09f0c7.svg" height="100" width="100" alt="Joaquin" />
---
0x7adbbea375f5e6ecaf28631bed702c4422f10d03