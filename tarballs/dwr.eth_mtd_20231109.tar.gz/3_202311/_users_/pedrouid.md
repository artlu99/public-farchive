username: pedrouid
fid: 8413
display name: Pedro Gomes
PFP: [https://i.seadn.io/gae/oM2WR7hiUl2Gq42SuoztItgO_DVPC37bLVZV3CLkn3gP3Ij-lD4NRD1OK0VIHI3s3JTkFUsNlsVxjaarEyVjsm1eIgvVqKhnFo27Kg?w=500&auto=format](https://i.seadn.io/gae/oM2WR7hiUl2Gq42SuoztItgO_DVPC37bLVZV3CLkn3gP3Ij-lD4NRD1OK0VIHI3s3JTkFUsNlsVxjaarEyVjsm1eIgvVqKhnFo27Kg?w=500&auto=format)
bio: Building WalletConnect 📲

<img src="https://i.seadn.io/gae/oM2WR7hiUl2Gq42SuoztItgO_DVPC37bLVZV3CLkn3gP3Ij-lD4NRD1OK0VIHI3s3JTkFUsNlsVxjaarEyVjsm1eIgvVqKhnFo27Kg?w=500&auto=format" height="100" width="100" alt="Pedro Gomes" />
---
0x9b7b2b4f7a391b6f14a81221ae0920a9735b67fb