username: todd
fid: 18
display name: Todd Goldberg
PFP: [https://i.imgur.com/zec0Sib.jpg](https://i.imgur.com/zec0Sib.jpg)
bio: Co-founder @curated | Startup investor at todd.capital | Fan of running, lifting, ramen, and Farcaster

<img src="https://i.imgur.com/zec0Sib.jpg" height="100" width="100" alt="Todd Goldberg" />
---
0x769e89e63eeeb94c4e80c3609cc4bbcecf30735e