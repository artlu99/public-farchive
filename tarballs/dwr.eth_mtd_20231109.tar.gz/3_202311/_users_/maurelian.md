username: maurelian
fid: 4179
display name: maurelian
PFP: [https://i.imgur.com/2VldpN3.jpg](https://i.imgur.com/2VldpN3.jpg)
bio: Pragmatism (Security) at Optimism. 




<img src="https://i.imgur.com/2VldpN3.jpg" height="100" width="100" alt="maurelian" />
---
0x13489a7f09ea0dfe9fdc41390cfbb57f4b6ff0b3