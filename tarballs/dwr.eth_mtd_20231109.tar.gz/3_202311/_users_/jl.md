username: jl
fid: 5525
display name: jake
PFP: [https://i.imgur.com/AoanADY.jpg](https://i.imgur.com/AoanADY.jpg)
bio: product leader @walmart • leading AI/ML initiatives in the retail space • former submariner/nuclear engineer • tech, AI, general aviation 

<img src="https://i.imgur.com/AoanADY.jpg" height="100" width="100" alt="jake" />
---
0x4430c8310ebe9ba864682790127e1f0417fe9dac