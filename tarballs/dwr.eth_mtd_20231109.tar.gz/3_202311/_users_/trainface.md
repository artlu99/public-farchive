username: trainface
fid: 2497
display name: trainface
PFP: [https://openseauserdata.com/files/271302e33170d232d69e4a71dd21a587.svg](https://openseauserdata.com/files/271302e33170d232d69e4a71dd21a587.svg)
bio: r&d @ decent

<img src="https://openseauserdata.com/files/271302e33170d232d69e4a71dd21a587.svg" height="100" width="100" alt="trainface" />
