username: emodi
fid: 604
display name: Nat Emodi
PFP: [https://i.imgur.com/CWetR9Z.jpg](https://i.imgur.com/CWetR9Z.jpg)
bio: founder @ highlight.xyz // natemodi on Twitter/Telegram 

<img src="https://i.imgur.com/CWetR9Z.jpg" height="100" width="100" alt="Nat Emodi" />
---
0xa49958fa14309f3720159c83cd92c5f38b1e3306