username: chaskin.eth
fid: 7479
display name: Chaskin OnChain
PFP: [https://i.imgur.com/FVrWTNP.png](https://i.imgur.com/FVrWTNP.png)
bio: Control the memes control the minds
https://linktr.ee/chaskinonchain
📍 Ethereum Channel

<img src="https://i.imgur.com/FVrWTNP.png" height="100" width="100" alt="Chaskin OnChain" />
---
0xee0b53ac9578cbc6e0cee0ac6e18cfb7118b5cb3