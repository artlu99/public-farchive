username: efdot
fid: 10766
display name: Efdot
PFP: [https://i.imgur.com/MX1X87d.jpg](https://i.imgur.com/MX1X87d.jpg)
bio: artist & creative director. making abstract meets figurative art

<img src="https://i.imgur.com/MX1X87d.jpg" height="100" width="100" alt="Efdot" />
---
0xcdd99ee657a33b1da6802f4117d7e5cb2ffa5d79