username: ajs
fid: 1121
display name: aj solimine
PFP: [https://lh3.googleusercontent.com/3mGHwnCPXoGrcDYnn8_W7HgHAyBpHWyrGYlTtSF8XUQlKQpa2-MmEHFf5FJF-Hoqs--OgyPwQdYM82pYpl0ZFWdD](https://lh3.googleusercontent.com/3mGHwnCPXoGrcDYnn8_W7HgHAyBpHWyrGYlTtSF8XUQlKQpa2-MmEHFf5FJF-Hoqs--OgyPwQdYM82pYpl0ZFWdD)
bio: building communitydata.io

investing script.capital

<img src="https://lh3.googleusercontent.com/3mGHwnCPXoGrcDYnn8_W7HgHAyBpHWyrGYlTtSF8XUQlKQpa2-MmEHFf5FJF-Hoqs--OgyPwQdYM82pYpl0ZFWdD" height="100" width="100" alt="aj solimine" />
