username: alexcomeau
fid: 11161
display name: Alex Comeau 
PFP: [https://i.imgur.com/QLPKaO7.jpg](https://i.imgur.com/QLPKaO7.jpg)
bio: 3 x Founder - Prev 3DShowing (acq.) Building Sales @ Airstack 👷🚀

Click here to connect https://minglee.io/a

<img src="https://i.imgur.com/QLPKaO7.jpg" height="100" width="100" alt="Alex Comeau " />
---
0xe0235804378c31948e81441f656d826ee5998bc6