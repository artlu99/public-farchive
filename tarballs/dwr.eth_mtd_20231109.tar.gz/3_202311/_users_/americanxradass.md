username: americanxradass
fid: 386
display name: americanxradass
PFP: [https://lh3.googleusercontent.com/vb-pGGuMsALEVBhu6_aSotsOfGZg2n22crO2bxuYw3_6S4X6O0NoV6WPiKfEXQl_VV5KUtQ6Z-0bNqu--UmRDl_uLiXEqOySjya-QA](https://lh3.googleusercontent.com/vb-pGGuMsALEVBhu6_aSotsOfGZg2n22crO2bxuYw3_6S4X6O0NoV6WPiKfEXQl_VV5KUtQ6Z-0bNqu--UmRDl_uLiXEqOySjya-QA)
bio: Founder of 0xCareers.io, a Job Board for Web3 and a free and weekly NFT newsletter called AlphaSchedule.io - Marketeer - Publishing memes and jokes as I go.

<img src="https://lh3.googleusercontent.com/vb-pGGuMsALEVBhu6_aSotsOfGZg2n22crO2bxuYw3_6S4X6O0NoV6WPiKfEXQl_VV5KUtQ6Z-0bNqu--UmRDl_uLiXEqOySjya-QA" height="100" width="100" alt="americanxradass" />
