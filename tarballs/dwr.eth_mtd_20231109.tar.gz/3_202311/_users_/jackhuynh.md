username: jackhuynh
fid: 189121
display name: Jack Huynh
PFP: [https://i.seadn.io/gcs/files/0965bf1213dfd78a76085c76834af055.png?w=500&auto=format](https://i.seadn.io/gcs/files/0965bf1213dfd78a76085c76834af055.png?w=500&auto=format)
bio: Web3+ Builder

linktr.ee/cryptovietinfo

<img src="https://i.seadn.io/gcs/files/0965bf1213dfd78a76085c76834af055.png?w=500&auto=format" height="100" width="100" alt="Jack Huynh" />
---
0x8faa461047ba94bceb3e095dfc702a587e7ff8ba