username: jaimin
fid: 6821
display name: Jaimin
PFP: [https://i.imgur.com/JlSVupc.png](https://i.imgur.com/JlSVupc.png)
bio: I like building, Founder - CEO Caddi

<img src="https://i.imgur.com/JlSVupc.png" height="100" width="100" alt="Jaimin" />
