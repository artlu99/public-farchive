username: shifke
fid: 3202
display name: David Shifke
PFP: [https://lh3.googleusercontent.com/RAB-X5wbo1NQzVsibScJSDI3FDYBU1vRizxZFDBWoDMOQhKdKdSfd5rliH017JgmNOR3fNMjpqNpLx5cU0AddgjVYYMs08Wu86xtAA](https://lh3.googleusercontent.com/RAB-X5wbo1NQzVsibScJSDI3FDYBU1vRizxZFDBWoDMOQhKdKdSfd5rliH017JgmNOR3fNMjpqNpLx5cU0AddgjVYYMs08Wu86xtAA)
bio: Ops, Data & Analytics @RTFKT

<img src="https://lh3.googleusercontent.com/RAB-X5wbo1NQzVsibScJSDI3FDYBU1vRizxZFDBWoDMOQhKdKdSfd5rliH017JgmNOR3fNMjpqNpLx5cU0AddgjVYYMs08Wu86xtAA" height="100" width="100" alt="David Shifke" />
