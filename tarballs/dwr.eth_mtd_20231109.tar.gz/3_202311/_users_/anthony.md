username: anthony
fid: 3447
display name: Anthony Sal
PFP: [https://i.imgur.com/fK8YrF3.jpg](https://i.imgur.com/fK8YrF3.jpg)
bio: I like to paint & create digital art anthonysal.eth.co

<img src="https://i.imgur.com/fK8YrF3.jpg" height="100" width="100" alt="Anthony Sal" />
