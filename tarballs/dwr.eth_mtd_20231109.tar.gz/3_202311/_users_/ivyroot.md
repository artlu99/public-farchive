username: ivyroot
fid: 2766
display name: Ivyroot
PFP: [https://i.imgur.com/KEhmr6y.jpg](https://i.imgur.com/KEhmr6y.jpg)
bio: Web3 / 3D / EVM dev
🍃  https://www.ivyroot.io
🍃 Open to contract projects.

<img src="https://i.imgur.com/KEhmr6y.jpg" height="100" width="100" alt="Ivyroot" />
---
0xebe4b33f9e2abb47a042a2cb9f45698dcae91e17