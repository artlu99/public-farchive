username: mihai
fid: 87
display name: Mihai Anca
PFP: [https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://openseauserdata.com/files/d5d652ed260e8c7891f731cad05805d4.svg](https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://openseauserdata.com/files/d5d652ed260e8c7891f731cad05805d4.svg)
bio: Leading eng @MoonPay prev Coinbase https://nf.td/mihai

<img src="https://res.cloudinary.com/merkle-manufactory/image/fetch/c_fill,f_png,w_256/https://openseauserdata.com/files/d5d652ed260e8c7891f731cad05805d4.svg" height="100" width="100" alt="Mihai Anca" />
---
0x190c442947588ac6e35758ad27988febf007ad9f