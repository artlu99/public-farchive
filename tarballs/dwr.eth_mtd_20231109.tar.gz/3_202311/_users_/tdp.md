username: tdp
fid: 4069
display name: Tony
PFP: [https://lh3.googleusercontent.com/X_STCWKMU0t_nlOkpuReen_aZkdMcsLX16nUFF0WXrM4zJu9zam42_X6-_ZzQOBjWwlvbLqQHoeoBUWl1xKDrqUs2xXnajWfiM5aww](https://lh3.googleusercontent.com/X_STCWKMU0t_nlOkpuReen_aZkdMcsLX16nUFF0WXrM4zJu9zam42_X6-_ZzQOBjWwlvbLqQHoeoBUWl1xKDrqUs2xXnajWfiM5aww)
bio: building something new | prev ✺ eng 
@ SyndicateDAO
 ✺, edge ai @ palantir | gnosis majority whip 
@ DAOgruppen
 | probably outside | tunadip.eth

<img src="https://lh3.googleusercontent.com/X_STCWKMU0t_nlOkpuReen_aZkdMcsLX16nUFF0WXrM4zJu9zam42_X6-_ZzQOBjWwlvbLqQHoeoBUWl1xKDrqUs2xXnajWfiM5aww" height="100" width="100" alt="Tony" />
