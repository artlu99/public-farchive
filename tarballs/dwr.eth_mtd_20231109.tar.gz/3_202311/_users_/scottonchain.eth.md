username: scottonchain.eth
fid: 187688
display name: Scott On Chain
PFP: [https://i.imgur.com/ZwsGs2y.jpg](https://i.imgur.com/ZwsGs2y.jpg)
bio: Data scientist for ethereum ecosystem

<img src="https://i.imgur.com/ZwsGs2y.jpg" height="100" width="100" alt="Scott On Chain" />
---
0x05246f743f1a7a3bbc4290a978d4cecb84cf0685