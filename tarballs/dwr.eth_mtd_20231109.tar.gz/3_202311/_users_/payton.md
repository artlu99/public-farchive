username: payton
fid: 4423
display name: payton
PFP: [https://img.seadn.io/files/c7c43174eb1979c829fcbe24030310e5.png](https://img.seadn.io/files/c7c43174eb1979c829fcbe24030310e5.png)
bio: building pixelpool.xyz, the first Farcaster video client. engineer. nyc. data infra & identity. 👨‍💻🍎🏳️‍🌈  nf.td/payton

<img src="https://img.seadn.io/files/c7c43174eb1979c829fcbe24030310e5.png" height="100" width="100" alt="payton" />
---
0x0b81418147df37155d643b5cb65ba6c8cb7aba76