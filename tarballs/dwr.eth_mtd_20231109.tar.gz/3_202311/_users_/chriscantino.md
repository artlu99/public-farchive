username: chriscantino
fid: 342
display name: chriscantino
PFP: [https://pbs.twimg.com/profile_images/1456020595225726976/ab18bvlS_400x400.jpg](https://pbs.twimg.com/profile_images/1456020595225726976/ab18bvlS_400x400.jpg)
bio: 

<img src="https://pbs.twimg.com/profile_images/1456020595225726976/ab18bvlS_400x400.jpg" height="100" width="100" alt="chriscantino" />
