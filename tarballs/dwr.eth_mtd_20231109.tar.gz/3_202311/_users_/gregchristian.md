username: gregchristian
fid: 1057
display name: gregchristian.eth
PFP: [https://i.seadn.io/gae/k69iatInxmavB7igwl02nNGh4lqXbu67LK77m6qim_B3a3H5HRSFGM62fwxmxLrCF2WxYPXK8Sdv3whaNFVxQ3nqCtKSzB5rq5Q5?w=500&auto=format](https://i.seadn.io/gae/k69iatInxmavB7igwl02nNGh4lqXbu67LK77m6qim_B3a3H5HRSFGM62fwxmxLrCF2WxYPXK8Sdv3whaNFVxQ3nqCtKSzB5rq5Q5?w=500&auto=format)
bio: Head of Design @ dispatch.co

<img src="https://i.seadn.io/gae/k69iatInxmavB7igwl02nNGh4lqXbu67LK77m6qim_B3a3H5HRSFGM62fwxmxLrCF2WxYPXK8Sdv3whaNFVxQ3nqCtKSzB5rq5Q5?w=500&auto=format" height="100" width="100" alt="gregchristian.eth" />
---
0xc9b1131c0f76d0a54d788fa580d80485cb0fd153