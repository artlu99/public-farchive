username: samagram
fid: 2756
display name: Samstevens.eth
PFP: [https://i.imgur.com/ao3zcIx.jpg](https://i.imgur.com/ao3zcIx.jpg)
bio: Web3 builder | Boys Club Crypto core team | ex-Google

<img src="https://i.imgur.com/ao3zcIx.jpg" height="100" width="100" alt="Samstevens.eth" />
