username: hasu
fid: 19037
display name: Hasu
PFP: [https://i.imgur.com/c1csCsY.jpg](https://i.imgur.com/c1csCsY.jpg)
bio: Strategy lead flashbots.net

Advisor LidoDAO and Steakhouse.financial

<img src="https://i.imgur.com/c1csCsY.jpg" height="100" width="100" alt="Hasu" />
