username: giuseppe
fid: 18989
display name: Joseph Maggio 🌊 🫶
PFP: [https://i.imgur.com/bNTkyaN.jpg](https://i.imgur.com/bNTkyaN.jpg)
bio: 
It’s all about community.

I cook for a living, in LA for now….Usually posting on the food channel 🍱 

Learning from everyone, willing to help anyone 


<img src="https://i.imgur.com/bNTkyaN.jpg" height="100" width="100" alt="Joseph Maggio 🌊 🫶" />
---
0x7ecdf3fd56d3b9f512fa70a68734ce871e36be96