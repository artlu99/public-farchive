username: gold
fid: 3960
display name: Michael Gold
PFP: [https://i.imgur.com/PfdHbNh.jpg](https://i.imgur.com/PfdHbNh.jpg)
bio: Working on generative art. 

Building: @shaderverse
Teaching: @sva_news
Investing: @redbeardvc

<img src="https://i.imgur.com/PfdHbNh.jpg" height="100" width="100" alt="Michael Gold" />
