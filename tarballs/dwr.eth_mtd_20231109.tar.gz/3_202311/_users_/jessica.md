username: jessica
fid: 2010
display name: jelca
PFP: [https://openseauserdata.com/files/92e536270e20fa3d2774f23aa0f5ddc6.svg](https://openseauserdata.com/files/92e536270e20fa3d2774f23aa0f5ddc6.svg)
bio: Paragraph.xyz/@jess VC in NYC 💕my pfp is CORN

<img src="https://openseauserdata.com/files/92e536270e20fa3d2774f23aa0f5ddc6.svg" height="100" width="100" alt="jelca" />
