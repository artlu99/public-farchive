username: ishverduzco
fid: 1602
display name: Ish
PFP: [https://i.imgur.com/Hxe3V4p.jpg](https://i.imgur.com/Hxe3V4p.jpg)
bio: community lead @a16zcrypto // ex linkedin, snap 👻 // twitter.com/ishverduzco

<img src="https://i.imgur.com/Hxe3V4p.jpg" height="100" width="100" alt="Ish" />
