username: annoushka.eth
fid: 2736
display name: annoushka
PFP: [https://i.imgur.com/BkV3LHY.jpg](https://i.imgur.com/BkV3LHY.jpg)
bio: building @interface

<img src="https://i.imgur.com/BkV3LHY.jpg" height="100" width="100" alt="annoushka" />
---
0x7e07064e5a921a57eb29c22f179b20513e8a3485