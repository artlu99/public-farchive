username: schwittlick
fid: 4967
display name: Marcel Schwittlick
PFP: [https://i.imgur.com/ZW0wvez.jpg](https://i.imgur.com/ZW0wvez.jpg)
bio: ↜ artist working with computers, algorithms, and plotters.  〰️ installations, sculptures and works on paper ↝

<img src="https://i.imgur.com/ZW0wvez.jpg" height="100" width="100" alt="Marcel Schwittlick" />
---
0x2c2690038daf35b6217a8115a0b5e191b4ed1de8