username: octant
fid: 18203
display name: Octant ZuConnect + DevConnect
PFP: [https://i.imgur.com/jbZeQTc.jpg](https://i.imgur.com/jbZeQTc.jpg)
bio: 100,000 ETH staked. Sustainably empowering the public goods funding ecosystem & amplifying your influence to use web3 to regenerate the world. discord.gg/octant

<img src="https://i.imgur.com/jbZeQTc.jpg" height="100" width="100" alt="Octant ZuConnect + DevConnect" />
---
0x4f80ce44afab1e5e940574f135802e12ad2a5ef0