username: tagga
fid: 1452
display name: tagga
PFP: [https://i.imgur.com/yMbx7Na.jpg](https://i.imgur.com/yMbx7Na.jpg)
bio: building oyl.gg find me at bc1CEO.twitter

<img src="https://i.imgur.com/yMbx7Na.jpg" height="100" width="100" alt="tagga" />
---
0xd8595ac2836b7a8040f046e751b42088436b6365