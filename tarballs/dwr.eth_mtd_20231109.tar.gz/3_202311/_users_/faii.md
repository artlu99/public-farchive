username: faii
fid: 8101
display name: Fai
PFP: [https://i.imgur.com/RbdOlvM.jpg](https://i.imgur.com/RbdOlvM.jpg)
bio: Banker turned web3 builder. Massively excited about SSI and its subsequent social graph!

<img src="https://i.imgur.com/RbdOlvM.jpg" height="100" width="100" alt="Fai" />
---
0xc24d14244986a9fae830200ff221b1eeca2289c9