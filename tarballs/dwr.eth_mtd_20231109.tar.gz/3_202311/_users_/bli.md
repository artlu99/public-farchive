username: bli
fid: 1338
display name: Brian Li
PFP: [https://i.imgur.com/84EUSLS.jpg](https://i.imgur.com/84EUSLS.jpg)
bio: Building @frens | @orangedao | @a16zcrypto CSS

<img src="https://i.imgur.com/84EUSLS.jpg" height="100" width="100" alt="Brian Li" />
---
0x88f667664e61221160ddc0414868ef2f40e83324