username: diyiyaoyi
fid: 22622
display name: diyiyaoyi
PFP: [https://i.imgur.com/rqovFZW.jpg](https://i.imgur.com/rqovFZW.jpg)
bio: 持续学习，终身成长

<img src="https://i.imgur.com/rqovFZW.jpg" height="100" width="100" alt="diyiyaoyi" />
