username: laurashin
fid: 7535
display name: Laura Shin
PFP: [https://i.imgur.com/uPMxo3j.jpg](https://i.imgur.com/uPMxo3j.jpg)
bio: Crypto journalist http://laurashin.com 🎧 Host http://unchainedpodcast.com 📚 Author, The Cryptopians, bit.ly/cryptopians 💌 http://unchainedcrypto.substack.com

<img src="https://i.imgur.com/uPMxo3j.jpg" height="100" width="100" alt="Laura Shin" />
