username: elliotcsmith
fid: 2442
display name: Elliot
PFP: [https://i.imgur.com/Xj8HYm1.jpg](https://i.imgur.com/Xj8HYm1.jpg)
bio: Tech nerd | biomed eng PhD | Using AI to solve big problems

<img src="https://i.imgur.com/Xj8HYm1.jpg" height="100" width="100" alt="Elliot" />
