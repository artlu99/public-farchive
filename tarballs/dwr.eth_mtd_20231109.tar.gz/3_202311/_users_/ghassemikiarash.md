username: ghassemikiarash
fid: 16760
display name: Kiarash Ghassemi
PFP: [https://i.imgur.com/JihinKj.jpg](https://i.imgur.com/JihinKj.jpg)
bio: 
نشسته ام به پروژه ها نگاه میکنم
ایری که آه میکشد

<img src="https://i.imgur.com/JihinKj.jpg" height="100" width="100" alt="Kiarash Ghassemi" />
---
0x337cfb6e0466977c6419d5dca8fa8b82904787b1