username: cole
fid: 3572
display name: Cole Kennelly
PFP: [https://i.imgur.com/AdhQyEN.jpg](https://i.imgur.com/AdhQyEN.jpg)
bio: @volmex https://volmex.finance/

<img src="https://i.imgur.com/AdhQyEN.jpg" height="100" width="100" alt="Cole Kennelly" />
