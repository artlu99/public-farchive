username: spencermac101
fid: 3625
display name: spencermacdonald.xyz
PFP: [https://openseauserdata.com/files/5c94eebbfa1383205a065f654a50b160.svg](https://openseauserdata.com/files/5c94eebbfa1383205a065f654a50b160.svg)
bio: cofounder @SpearbitDAO, advisor @joinlincoln
Miami, FL

<img src="https://openseauserdata.com/files/5c94eebbfa1383205a065f654a50b160.svg" height="100" width="100" alt="spencermacdonald.xyz" />
