username: alexios
fid: 192347
display name: Alexios Konstantinidis
PFP: [https://i.seadn.io/s/raw/files/4ad72b7bc707136006bb6478e1fb065a.png?w=500&auto=format](https://i.seadn.io/s/raw/files/4ad72b7bc707136006bb6478e1fb065a.png?w=500&auto=format)
bio: A crypto enthusiast who loves to learn all the time!

<img src="https://i.seadn.io/s/raw/files/4ad72b7bc707136006bb6478e1fb065a.png?w=500&auto=format" height="100" width="100" alt="Alexios Konstantinidis" />
---
0xed38ff1efb8207cfdfed75fad5004077819afc3a