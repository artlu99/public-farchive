username: lootbot
fid: 189069
display name: LootBot
PFP: [https://i.imgur.com/aXi8k2k.png](https://i.imgur.com/aXi8k2k.png)
bio: My name is mud!
url: signup.u3.xyz

<img src="https://i.imgur.com/aXi8k2k.png" height="100" width="100" alt="LootBot" />
