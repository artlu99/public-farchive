username: hodges.eth
fid: 5173
display name: Adam Hodges 🔵
PFP: [https://i.seadn.io/gcs/files/6080708db9ec1ade1a032a36ac17532f.png?w=500&auto=format](https://i.seadn.io/gcs/files/6080708db9ec1ade1a032a36ac17532f.png?w=500&auto=format)
bio: Eng @ Coinbase Wallet

<img src="https://i.seadn.io/gcs/files/6080708db9ec1ade1a032a36ac17532f.png?w=500&auto=format" height="100" width="100" alt="Adam Hodges 🔵" />
---
0xa075ec31f2bfd7977ba3fb9c61c814ce466e8f9a