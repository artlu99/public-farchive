username: markmarroc
fid: 7586
display name: Mark
PFP: [https://i.imgur.com/NdbxN4N.jpg](https://i.imgur.com/NdbxN4N.jpg)
bio: 📸  I freeze emotions, compress time, show the colors of life, plain black and white, and even invisible light💡 markmarroc.com | linktr.ee/markmarroc

<img src="https://i.imgur.com/NdbxN4N.jpg" height="100" width="100" alt="Mark" />
