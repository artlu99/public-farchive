username: bhaumik
fid: 848
display name: Bhaumik Patel
PFP: [https://i.imgur.com/iDsYtQV.jpg](https://i.imgur.com/iDsYtQV.jpg)
bio: Short-term skeptic, long-term optimist

<img src="https://i.imgur.com/iDsYtQV.jpg" height="100" width="100" alt="Bhaumik Patel" />
