username: homocryptus
fid: 6711
display name: Homocryptus 
PFP: [https://i.seadn.io/gae/zjf5Zd-JrQ7zDBiICp8M7gokyNqg_dNdk35pgC8SvXJLBA4TkqmGExsFYnRP8GPN9-cFvgQ1jxlw3Rvde7itORv2pjfMMZ3BXbVzMU4?w=500&auto=format](https://i.seadn.io/gae/zjf5Zd-JrQ7zDBiICp8M7gokyNqg_dNdk35pgC8SvXJLBA4TkqmGExsFYnRP8GPN9-cFvgQ1jxlw3Rvde7itORv2pjfMMZ3BXbVzMU4?w=500&auto=format)
bio: Purpose first🤝Built “FashTime”, #1 on App Store in 2019, & many viral communities | Now Astra Ventures & anotemusic.io | Ch.artist https://shorturl.at/bHZ36

<img src="https://i.seadn.io/gae/zjf5Zd-JrQ7zDBiICp8M7gokyNqg_dNdk35pgC8SvXJLBA4TkqmGExsFYnRP8GPN9-cFvgQ1jxlw3Rvde7itORv2pjfMMZ3BXbVzMU4?w=500&auto=format" height="100" width="100" alt="Homocryptus " />
---
0x14f6fcddaf37ba8d45e56a0d65692bbb3ba1ee1e