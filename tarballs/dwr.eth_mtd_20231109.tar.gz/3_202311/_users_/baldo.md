username: baldo
fid: 13137
display name: Baldo
PFP: [https://i.seadn.io/gcs/files/aadfbf3a4ab9fd71abd8285c89ec66c5.png?w=500&auto=format](https://i.seadn.io/gcs/files/aadfbf3a4ab9fd71abd8285c89ec66c5.png?w=500&auto=format)
bio: College student interested in esoteric tech and finance.

<img src="https://i.seadn.io/gcs/files/aadfbf3a4ab9fd71abd8285c89ec66c5.png?w=500&auto=format" height="100" width="100" alt="Baldo" />
---
0x16c9eb1d329cdb5fd7d3c4701f253639d4149db1