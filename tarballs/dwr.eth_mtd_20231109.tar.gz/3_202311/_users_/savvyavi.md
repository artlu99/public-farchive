username: savvyavi
fid: 4168
display name: Avi 💙
PFP: [https://i.imgur.com/trc2YCN.jpg](https://i.imgur.com/trc2YCN.jpg)
bio: Recovering Film Studio Exec l Psychology Nerd l Strategy Muse l Brand Builder l Also, “Culture eats strategy for breakfast.” - Peter Drucker   JoinSavvyAvi.com

<img src="https://i.imgur.com/trc2YCN.jpg" height="100" width="100" alt="Avi 💙" />
---
0x481da6d98d9562347dea2972639f3e92cfee597f