username: akhil-bvs
fid: 1265
display name: Akhil BVS
PFP: [https://lh3.googleusercontent.com/JJ4cLAru5YtZZ8ce4ppz3V1FsfmIjlAiY0DZp7LUkgvPEviKr7PHHUotOVYLiUJ6HsSLuyorkYA4izd1_lJiiyyeA0hWqV3F_bQ6nQ](https://lh3.googleusercontent.com/JJ4cLAru5YtZZ8ce4ppz3V1FsfmIjlAiY0DZp7LUkgvPEviKr7PHHUotOVYLiUJ6HsSLuyorkYA4izd1_lJiiyyeA0hWqV3F_bQ6nQ)
bio: Casts around NFTs, Product & Design | Building asset.money | DM @ https://twitter.com/akhil_bvs

<img src="https://lh3.googleusercontent.com/JJ4cLAru5YtZZ8ce4ppz3V1FsfmIjlAiY0DZp7LUkgvPEviKr7PHHUotOVYLiUJ6HsSLuyorkYA4izd1_lJiiyyeA0hWqV3F_bQ6nQ" height="100" width="100" alt="Akhil BVS" />
